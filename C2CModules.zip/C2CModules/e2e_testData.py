import glob
import inspect
import os
import os.path
import sys

import openpyxl

# from axiom_framework.tests.base import Test as Base
# from axiom_framework.results.base import TestResults

current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

sys.path.insert(1, 'C:\Car2Cloud_E2ETesting')
adb_path = r'C:\ADB\adb.exe'
logcat_pid = None

# ===============================
# Test folder Path
# ===============================
folderPath = r'C:\Car2Cloud_E2ETesting' + '\\'
C2CtestData_batchPath = folderPath + r'C2CtestData\usr\local\C2Cbat' + '\\'
C2CtestData_jsonPath = folderPath + r'C2CtestData\usr\local\json' + '\\'
C2CtestData_c2c2Path = folderPath + r'C2CtestData\usr\local\c2c' + '\\'
C2CtestData_certsPath = folderPath + r'C2CtestData\usr\local\certs' + '\\'
C2CtestData_DepPackagePath = folderPath + r'C2CtestData\usr\local\deploymentPackages' + '\\'
C2CtestData_iviconfNewPath = folderPath + r'C2CtestData\usr\local\iviconfNew' + '\\'
C2CtestData_vtconfNewPath = folderPath + r'C2CtestData\usr\local\vtconfNew' + '\\'
C2CtestData_vtconfNew_c2cPath = C2CtestData_vtconfNewPath + r'c2c'
C2CtestReport_exeBackupPath = folderPath + r'C2CtestReport\e2eExecution_Backup' + '\\'

C2CtestReport_APIresponsesPath = C2CtestReport_exeBackupPath + r'API_responses' + '\\'
C2CtestReport_c2cLogsPath = C2CtestReport_exeBackupPath + r'c2cLogs' + '\\'
C2CtestReport_DeviceOnbrdng_backupPath = C2CtestReport_exeBackupPath + r'DeviceOnboarding_backup' + '\\'
C2CtestReport_otaPath = C2CtestReport_exeBackupPath + r'OTA' + '\\'
C2CtestReport_OTA_backupPath = C2CtestReport_exeBackupPath + r'OTA_backup' + '\\'
C2CtestReport_backupPath = C2CtestReport_exeBackupPath + r'DeviceOnboarding_Pos_backup' + '\\'
C2CtestReport_NetworkStatusPath = C2CtestReport_exeBackupPath + r'NetworkStatus' + '\\'
C2CtestReport_SKUupdateByGroupPath = C2CtestReport_exeBackupPath + r'SKUupdateByGroup' + '\\'
C2CtestReport_FeatureUpdateByGroupPath = C2CtestReport_exeBackupPath + r'FeatureUpdateByGroup' + '\\'
C2CtestReport_SKUupdateByVINPath = C2CtestReport_exeBackupPath + r'SKUupdateByVIN' + '\\'
# ===============================
# Test Data File Path
# ===============================
data_file = folderPath + r'C2CtestData\c2cTestData.xlsx'


# ===============================
# Read folder path
# ===============================
def commonFolderPath():
    path = folderPath
    return path


# ===============================
# Read test data from excel file
# ===============================

def testData(sheetname, rowNo, colNo):
    files = glob.glob(data_file)
    max_file = max(files, key=os.path.getctime)
    wb_obj = openpyxl.load_workbook(max_file)
    sheet_obj = wb_obj[sheetname]
    cell_obj = sheet_obj.cell(row=rowNo, column=colNo)
    return cell_obj.value


# ===================================
# Valid Test Data for test execution
# ===================================

BaseUrl_gbl = testData("DeviceOnboardingData", 18, 2)
BaseUrl_reg = testData("DeviceOnboardingData", 19, 2)

carota_backend_url = testData("DeviceOnboardingData", 21, 2)

drimaes_firm_reg = testData("FotaData_Drimaes_IVI", 2, 3)
drimaes_sota_reg = testData("SotaData_Drimaes_IVI", 2, 3)

pickDeviceId = testData("DeviceSerialNo", 2, 2)
tcu_adbSerialNo = str(testData("DeviceSerialNo", 3, 2))
ivi_adbSerialNo = str(testData("DeviceSerialNo", 4, 2))
vt_adbSerialNo = str(testData("DeviceSerialNo", 5, 2))

# SP validation flag
spvalidationFlag = testData("DeviceSetup", 2, 2)

pushBinariesLibrariesOnTCU = testData("DeviceSetup", 3, 2)
pushBinariesLibrariesOnIVI = testData("DeviceSetup", 4, 2)
pushBinariesLibrariesOnVT = testData("DeviceSetup", 5, 2)
pushBinariesLibrariesOnTCU_fusion = testData("DeviceSetup", 6, 2)

# Stability details
stability_intervalTime_flag_TCU = testData("DeviceSetup", 7, 2)
stability_intervalTime_TCU = testData("DeviceSetup", 7, 3)

# Device onboarding details
onboardingTypeFlag = testData("DeviceOnboardingData", 2, 2)
onboardingEnv = testData("DeviceOnboardingData", 18, 3)
tcuDevice_NAD = testData("DeviceOnboardingData", 8, 2)
deviceIdFlag = testData("DeviceOnboardingData", 9, 2)
reqDeviceId_tcu = testData("DeviceOnboardingData", 10, 2)
reqDeviceId_ivi = testData("DeviceOnboardingData", 11, 2)
vinNoFlag = testData("DeviceOnboardingData", 12, 2)
reqVinNo = testData("DeviceOnboardingData", 13, 2)
OTA_ModelFlag = testData("DeviceOnboardingData", 14, 2)
reqModelNameFlag = testData("DeviceOnboardingData", 15, 2)
reqModelName = testData("DeviceOnboardingData", 16, 2)
filepath = testData("DeviceOnboardingData", 17, 2)
tcu_brokerAddress_flag = testData("DeviceOnboardingData", 22, 2)

# SkU license Flag
skuLicenseFlag = testData("DeviceOnboardingData", 20, 2)

ex_singleDeviceOnboarding_TCU = testData("DeviceOnboardingData", 3, 2)
ex_singleDeviceOnboarding_IVI = testData("DeviceOnboardingData", 3, 2)
ex_comboDeviceOnboarding_TCUVT_fusion = testData("DeviceOnboardingData", 4, 2)
ex_comboDeviceOnboarding_TCUIVI = testData("DeviceOnboardingData", 5, 2)
ex_comboDeviceOnboarding_TCUVT = testData("DeviceOnboardingData", 6, 2)
ex_comboDeviceOnboarding_TCUIVIVT = testData("DeviceOnboardingData", 7, 2)
ex_comboDeviceOnboarding_TCUVTIVI_fusion = "No"

# Connectivity
ethernet = "Ethernet"
wifi = "WiFi"

# device combo options
DeviceOnboarding_option = "DeviceOnboarding"
DeviceOnboarding_ivi_option = 'DeviceOnboarding_ivi'
DeviceOnboarding_tcuvt_fusion_option = "DeviceOnboarding_tcuvt_fusion"
DeviceOnboarding_tcuvt_option = "DeviceOnboarding_tcuvt"
SKUupdateByVIN_option = "SKUupdateByVIN"
SKUupdateByGroup_option = "SKUupdateByGroup"
FeatureUpdateByGroup_option = "FeatureUpdateByGroup"
SKUupdateByVIN_vt_option = "SKUupdateByVIN_vt"
SKUupdateByGroup_vt_option = "SKUupdateByGroup_vt"
FeatureUpdateByGroup_vt_option = "FeatureUpdateByGroup_vt"
DeviceOnboarding_tcuvt_fusion_skuVIN_option = "DeviceOnboarding_tcuvt_fusion_skuVIN"
DeviceOnboarding_tcuvt_fusion_skuGrp_option = "DeviceOnboarding_tcuvt_fusion_skuGrp"
DeviceOnboarding_tcuvt_fusion_FeatUp_option = "DeviceOnboarding_tcuvt_fusion_FeatUp"

##Enter TCU device program details
PrgmSkuId = testData("TCUConfFileDetails", 2, 4)
SkuId = testData("TCUConfFileDetails", 3, 4)
PrgmId = testData("TCUConfFileDetails", 4, 4)
chipsetType = str(testData("TCUConfFileDetails", 5, 4)).split('=')[1]
chipsetSpVer = str(testData("TCUConfFileDetails", 6, 4)).split('=')[1]

##Enter IVI device program details
IVI_PrgmSkuId = testData("IVIConfFileDetails", 2, 4)
IVI_SkuId = testData("IVIConfFileDetails", 3, 4)
IVI_PrgmId = testData("IVIConfFileDetails", 4, 4)
IVI_chipsetType = str(testData("IVIConfFileDetails", 5, 4)).split('=')[1]
IVI_chipsetSpVer = str(testData("IVIConfFileDetails", 6, 4)).split('=')[1]

##Enter VT device program details
VT_PrgmSkuId = testData("VTConfFileDetails", 2, 4)
VT_SkuId = testData("VTConfFileDetails", 3, 4)
VT_PrgmId = testData("VTConfFileDetails", 4, 4)
VT_chipsetType = str(testData("VTConfFileDetails", 5, 4)).split('=')[1]
VT_chipsetSpVer = str(testData("VTConfFileDetails", 6, 4)).split('=')[1]

##Default mandatory conf details for text replace
defaultVIN = testData("DefaultConfFileDetails", 2, 2)
defaultSystemID = testData("DefaultConfFileDetails", 3, 2)
defaultSubSystemId = testData("DefaultConfFileDetails", 4, 2)
defaultDeviceId = testData("DefaultConfFileDetails", 5, 2)
ivi_defaultDeviceId = testData("DefaultConfFileDetails", 6, 2)
dm_defaultDeviceId = testData("DefaultConfFileDetails", 7, 2)

##Default TCU device program details for text replace
defaultPrgmSkuId = testData("TCUConfFileDetails", 2, 3)
defaultSkuId = testData("TCUConfFileDetails", 3, 3)
defaultPrgmId = testData("TCUConfFileDetails", 4, 3)
defaultchipsetType = testData("TCUConfFileDetails", 5, 3)
defaultchipsetSpVer = testData("TCUConfFileDetails", 6, 3)
defaultchipsetName = testData("TCUConfFileDetails", 7, 3)

##Default IVI device program details
defaultIVI_PrgmSkuId = testData("IVIConfFileDetails", 2, 3)
defaultIVI_SkuId = testData("IVIConfFileDetails", 3, 3)
defaultIVI_PrgmId = testData("IVIConfFileDetails", 4, 3)
defaultIVI_chipsetType = testData("IVIConfFileDetails", 5, 3)
defaultIVI_chipsetSpVer = testData("IVIConfFileDetails", 6, 3)
defaultIVI_chipsetName = testData("IVIConfFileDetails", 7, 3)

##Default VT device program details
defaultVT_PrgmSkuId = testData("VTConfFileDetails", 2, 3)
defaultVT_SkuId = testData("VTConfFileDetails", 3, 3)
defaultVT_PrgmId = testData("VTConfFileDetails", 4, 3)
defaultVT_chipsetType = testData("VTConfFileDetails", 5, 3)
defaultVT_chipsetSpVer = testData("VTConfFileDetails", 6, 3)
defaultVT_chipsetName = testData("VTConfFileDetails", 7, 3)

# TCU device Configuration ->  File Paths

sideloadedFile = C2CtestData_c2c2Path + r'side_loaded.conf'
c2cvehicleFile = C2CtestData_c2c2Path + r'c2c_vehicle.json'
car2cloudFile = C2CtestData_c2c2Path + r'car2cloud.conf'
dmconfFile = C2CtestData_c2c2Path + r'dm.conf'

# IVI device Configuration ->  File Paths
ivi_car2cloudFile = C2CtestData_iviconfNewPath + 'car2cloud.conf'
ivi_dmconfFile = C2CtestData_iviconfNewPath + 'dm.conf'

# VT device Configuration ->  File Paths
vt_car2cloudFile = C2CtestData_vtconfNew_c2cPath + '\\' + 'car2cloud.conf'
vt_dmconfFile = C2CtestData_vtconfNew_c2cPath + '\\' + 'dm.conf'

# ========================================
# Invalid Test Data for negative scenarios
# ========================================

invalidVIN_lessCharLen = testData("InvalidData", 2, 2)
invalidVIN_grtrCharLen = testData("InvalidData", 2, 4)
invalidVIN_withSpace = testData("InvalidData", 2, 6)
invalidVIN_withSplchar = testData("InvalidData", 2, 8)

duplicateVIN = testData("InvalidData", 3, 2)

invalidDeviceId_lessCharLen = testData("InvalidData", 4, 2)
invalidDeviceId_grtrCharLen = testData("InvalidData", 4, 4)
invalidDeviceId_withSpace = testData("InvalidData", 4, 6)
invalidDeviceId_withSplchar = testData("InvalidData", 4, 8)

invalid_systemId = testData("InvalidData", 5, 2)

invalidSubSysId_lessCharLen = testData("InvalidData", 6, 2)
invalidSubSysId_grtrCharLen = testData("InvalidData", 6, 4)
invalidSubSysId_withSpace = testData("InvalidData", 6, 6)
invalidSubSysId_withSplchar = testData("InvalidData", 6, 8)

invalidGlbUrl = testData("InvalidData", 7, 2)

devOnbrdWithRegionalUrl = testData("InvalidData", 8, 2)

dupDeviceId = testData("InvalidData", 9, 2)  # device onboarding with device id doesnot match with system id and certs

emptyVIN = emptyDeviceID = emptySystemID = emptySubSystemID = emptyUrl = emptyPrgmSkuId = emptySkuId = emptyPrgmId = emptyChipsetType = emptyChipsetName = emptychipsetSp = ""

invalidPrgmSkuId = testData("InvalidData", 15, 2)
invalidSkuId = testData("InvalidData", 16, 2)
invalidPrgmId = testData("InvalidData", 17, 2)
invalidchipsetType = testData("InvalidData", 18, 2)
invalidchipsetSp = testData("InvalidData", 19, 2)
invalidChipsetName = testData("InvalidData", 20, 2)

invalidSystemState = testData("InvalidData", 33, 2)
invalidChipsetState = testData("InvalidData", 34, 2)
invalidChipsetsCount = testData("InvalidData", 35, 2)
invalidRegionCode = testData("InvalidData", 36, 2)
invalidCountryCode = testData("InvalidData", 37, 2)
invalidDeviceState = testData("InvalidData", 38, 2)
invalidBrokerName = testData("InvalidData", 39, 2)
invalidBrokerPort = testData("InvalidData", 40, 2)

# Test Folder Path

# ===============================
# Drimaes Test folder Path
# ===============================
drimaes_batchPath = C2CtestData_batchPath + 'drimaes' + '\\'
drimaes_defaultConfNew = folderPath + r'C2CtestData\usr\local\drimaes_defaultConfNew' + '\\'

# ===============================
# B2C Test folder Path
# ===============================
b2c_batchPath = C2CtestData_batchPath + 'b2c' + '\\'
b2c_defaultConfNew = folderPath + r'C2CtestData\usr\local\b2c_defaultConfNew' + '\\'

# ===============================
# C2C Primary IVI Test folder Path
# ===============================
c2c_ivi_batchPath = C2CtestData_batchPath + 'c2c_ivi' + '\\'
c2c_ivi_defaultConfNew = folderPath + r'C2CtestData\usr\local\c2c_ivi_defaultConfNew' + '\\'

# ===================================
# Valid Test Data for test execution
# ===================================

drimaes_ivi_adbSerialNo = str(testData("DeviceSerialNo", 6, 2))
b2c_ivi_adbSerialNo = str(testData("DeviceSerialNo", 7, 2))
c2c_ivi_adbSerialNo = str(testData("DeviceSerialNo", 4, 2))

drimaes_pushBinariesLibrariesOnIVI = testData("DeviceSerialNo", 7, 2)
b2c_pushBinariesLibrariesOnIVI = testData("DeviceSetup", 8, 2)
c2c_pushBinariesLibrariesOnIVI = testData("DeviceSetup", 4, 2)

# ===================================
# Devices
# ===================================
deviceType_TCU = "TCU"
deviceType_IVI = "IVI"
deviceType_VT = "VT"
deviceType_IVI_nonPrimary = "IVI"

c2c_ivi_chipset1 = "SA8195"
c2c_ivi_chipset = "SA8295"
c2c_tcu_chipset = "SA515"
c2c_vt_chipset = "SA2150"

drimaes_ivi_chipset = "6155"
b2c_ivi_chipset = "2290"

# ===================================
# Folder names
# ===================================
tcu_files = "tcu_files"
vt_files = "vt_files"
ivi_files = "ivi_files"

##Enter IVI device program details
drimaes_IVI_PrgmSkuId = testData("IVIConfFileDetails_Drimaes", 2, 4)
drimaes_IVI_SkuId = testData("IVIConfFileDetails_Drimaes", 3, 4)
drimaes_IVI_PrgmId = testData("IVIConfFileDetails_Drimaes", 4, 4)
drimaes_IVI_chipsetType = str(testData("IVIConfFileDetails_Drimaes", 5, 4)).split('=')[1]
drimaes_IVI_chipsetSpVer = str(testData("IVIConfFileDetails_Drimaes", 6, 4)).split('=')[1]

##Enter IVI device program details
b2c_IVI_PrgmSkuId = testData("IVIConfFileDetails_B2C", 2, 4)
b2c_IVI_SkuId = testData("IVIConfFileDetails_B2C", 3, 4)
b2c_IVI_PrgmId = testData("IVIConfFileDetails_B2C", 4, 4)
b2c_IVI_chipsetType = str(testData("IVIConfFileDetails_B2C", 5, 4)).split('=')[1]
b2c_IVI_chipsetSpVer = str(testData("IVIConfFileDetails_B2C", 6, 4)).split('=')[1]

##Enter IVI device program details
C2C_IVI_PrgmSkuId = testData("IVIConfFileDetails_Primary", 2, 4)
C2C_IVI_SkuId = testData("IVIConfFileDetails_Primary", 3, 4)
C2C_IVI_PrgmId = testData("IVIConfFileDetails_Primary", 4, 4)
C2C_IVI_chipsetType = str(testData("IVIConfFileDetails_Primary", 5, 4)).split('=')[1]
C2C_IVI_chipsetSpVer = str(testData("IVIConfFileDetails_Primary", 6, 4)).split('=')[1]

# ===================================
# Valid Test Data for test execution
# ===================================

# payload file path
payloadPath = folderPath + r'C2CtestData\usr\local\json\OTA_Payload' + '\\'
otaPackagePath = str(folderPath) + r'C2CtestData\usr\local\OTApackages' + '\\'
otaExecutionPath = str(folderPath) + r'C2CtestReport\e2eExecution_Backup\OTA' + '\\'

# ===================================
# Valid Test Data for test execution
# ===================================

firm_reg = testData("FotaData", 2, 3)
sota_reg = testData("SotaData", 2, 3)

# Device states
ACTIVE_State = "ACTIVE"

# telemetry, Command & Control & FMS test data
telemetry_msg_id_published2Cloud = '"message_id": "msg-dev-'
telemetry_msg_id_published2Cloud1 = '"message_id": "msg-dev-'

trip_start_reason_code = 'trip_reason_code:74'
trip_stop_reason_code = 'trip_reason_code:75'
tripId_code = 'trip_id: '

trip_start_event_type_code = '"event_type": 4005'
trip_stop_event_type_code = '"event_type": 4006'

telemetry_msg_type_code = '"message_type": 601'
telemetry_recv_topic = "C2C_HUB/RECV/TELEMETRY"
Publishing_msg_to_cloud = "Publishing msg to cloud"
source_id_telematics = '"source_id": "telematics"'
target_id_telematics = '"target_id": "c2c-cloud"'

# tele attributes

telemetry_msg_type_code_tel = '"message_type": 304'

telemetry_odo_attribute = "odo:"
telemetry_speed_attribute = "speed:"
telemetry_rpm_attribute = "rpm:"
telemetry_fuel_level_attribute = "fuel_level:"
telemetry_ev_battery_level_attribute = "ev_battery_level:"
telemetry_ev_battery_spec_current_attribute = "ev_battery_spec_current:"
telemetry_ev_battery_spec_watt_attribute = "ev_battery_spec_watt:"
telemetry_state_of_charge_attribute = "state_of_charge:"
telemetry_mileage_attribute = "mileage:"
telemetry_rpm_2_attribute = "rpm_2:"

# tele values configured in stub
telemetry_lat_value = "17.628162822"
telemetry_long_value = "72.816781922"
telemetry_alt_value = "72.22"
telemetry_bar_value = "186.22"
telemetry_vel_value = "85.22"
telemetry_odo_value = "600000"
telemetry_speed_value = ""
telemetry_rpm_value = ""
telemetry_fuel_level_value = "30"
telemetry_ev_battery_level_value = "400"
telemetry_ev_battery_spec_current_value = ""
telemetry_ev_battery_spec_watt_value = ""
telemetry_state_of_charge_value = ""
telemetry_mileage_value = ""
telemetry_rpm_2_value = ""

# Telemetry - Cloud evet type
telemetry_lat_event_type = "3101"
telemetry_long_event_type = "3101"
telemetry_alt_event_type = "3101"
telemetry_bar_event_type = "3101"
telemetry_vel_event_type = "3101"
telemetry_odo_event_type = "2005"
telemetry_speed_event_type = "2001"
telemetry_rpm_event_type = "2002"
telemetry_fuel_level_event_type = "3250"
telemetry_ev_battery_level_event_type = "1001"
telemetry_ev_battery_spec_current_event_type = "1001"
telemetry_ev_battery_spec_watt_event_type = "1001"
telemetry_state_of_charge_event_type = "1001"
telemetry_mileage_event_type = "4001"
telemetry_rpm_2_event_type = "2002"  # not avaiable for drimaes
telemetry_ignition_event_type = "2003"
telemetry_ignition_event_type1 = "1001"
telemetry_ignition_event_type2 = "1001"
telemetry_HVAC_temp_current_event_type = "3104"
telemetry_INFO_EV_BATTERY_CAPACITY = "1001"
EV_BMS_BATTERY_SOH = "1001"
EV_BMS_BATTERY_SOC = "1001"
EV_BATTERY_SPEC_VOLTAGE = "1001"
EV_BMS_BATTERY_TEMPERATURE = "1001"
EV_BMS_BATTERY_REMAINING_CHARGE_TIME = "1001"
EV_BATTERY_EFFICIENCY = "1001"
EV_CHARGING_STATE = "1001"
FUEL_LEVEL_LOW = "3250"
INFO_FUEL_CAPACITY = "3250"
FUEL_EFFICIENCY = "3250"
RANGE_REMAINING = "5002"
ENV_OUTSIDE_TEMPERATURE = "5003"
EV_BATTERY_INSTANTANEOUS_CHARGE_RATE = "1001"

# Command & Control

commndctrl_msg_type_code = '"message_type":251'
notification_msg_type_code = '"message_type":502'

telemetry_HVAC_seat_temp_event_type = "3104"
HVAC_SIDE_MIRROR_HEAT = "3104"
HVAC_STEERING_WHEEL_HEAT = "3104"
DEFROST = "3104"
WINDOW_POSITION = "3102"
DOOR_POSITION = "3103"
WINDOW_LOCK = "3102"
DOOR_LOCK = "3103"
HORN = "3201"  # not working
HVAC_SEAT_VENTILATION = "3104"
IGNITION_KEEPTIME = "2503"  # Not working
HAZARD_LIGHT = ""
Emergency_Light = ""
CHARGE_START = ""
CHARGE_STOP = ""
Ignition_start = ""
Ignition_stop = ""
Indoor_Temperature = ""
FUEL_LEVEL_ALERT_LIMIT = ""
EV_BMS_BATTERY_TEMPERATURE_MIN = ""
EV_BMS_BATTERY_TEMPERATURE_MAX = ""
MAX_BATTERY_CHARGING_LIMIT = ""

appid = "c6060"  # QCQA env
