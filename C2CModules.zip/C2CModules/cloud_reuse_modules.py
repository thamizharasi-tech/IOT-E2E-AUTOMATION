import base64
import glob
import json
import os
import time
import requests

from C2CModules.device_reuse_modules import push_desired_file_on_primary_IVI, run_desired_service_on_primary_IVI, \
    pull_files_from_primary_IVI, get_SystemId
from C2CModules.OTA_reuse_modules import getVIN
from C2CModules.api_endpoints import api_endpoints
from C2CModules.api_headers import api_headers
from C2CModules.e2e_c2c_modules import replaceLineWithText, testResult
from C2CModules.e2e_testData import C2CtestData_c2c2Path, C2CtestData_jsonPath, tripId_code, \
    telemetry_msg_id_published2Cloud, commndctrl_msg_type_code, telemetry_msg_type_code_tel, deviceType_IVI
from C2CModules.resuse_modules import save_api_resp_into_file, verify_message_in_log


def set_telemetry_flags(self):
    folderPath_ivi = C2CtestData_c2c2Path + 'dm.conf'
    folderPath_ivi_c2cdeafult = C2CtestData_c2c2Path + 'c2c_default.conf'

    replaceLineWithText(self, folderPath_ivi, "telemetry_log=n", "telemetry_log=y")
    replaceLineWithText(self, folderPath_ivi, "telemetry_capability=n", "telemetry_capability=y")
    replaceLineWithText(self, folderPath_ivi_c2cdeafult, "telemetry_log=n", "telemetry_log=y")


def push_dmFile_on_IVI_device(self, onboarding_Type, chipset_type):
    set_telemetry_flags(self)
    push_desired_file_on_primary_IVI(self, onboarding_Type, chipset_type, "dm_conf")
    time.sleep(5)
    push_desired_file_on_primary_IVI(self, onboarding_Type, chipset_type, "c2cDefault_conf")


def run_dm_service_on_IVI_device(self, onboarding_Type, chipset_type):
    run_desired_service_on_primary_IVI(self, onboarding_Type, chipset_type, "dmService")


def pull_logs_from_IVI_device(self, onboarding_Type, chipset_type):
    pull_files_from_primary_IVI(self, onboarding_Type, chipset_type, "C2Clogs")


def get_telemetry_curr_resp(self, event_type):
    systemId = get_SystemId(self, deviceType_IVI)
    # url = BaseUrl_reg + "/telemetry-curr/v1.0/current-value/" + systemId + "?eventType=" + str(event_type)
    telemetry_curr = str(api_endpoints.telemetry_curr_url).replace('{sysId}', systemId).replace('{eventTypeValue}',
                                                                                                str(event_type))
    payload = {}
    headers = api_headers.tele_headers

    response = requests.get(telemetry_curr, headers=headers, data=payload)
    # Parse HTTP response body to json format
    response_body = response.json()
    # print(response_body)

    save_api_resp_into_file('telemetry_curr' + '_' + str(event_type), response.text)
    print(response.text)
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)
    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body["message"]))
        assert False

    assert (response_body["responseData"]["message"] == "Successfully fetched the current values")
    return response_body


def put_meta_data_resp(self):
    vin = getVIN(self, "tel", deviceType_IVI)
    # url = BaseUrl_reg + "/telemetry-curr/v1.0/current-value/" + systemId + "?eventType=" + str(event_type)
    complete_url = str(api_endpoints.meta_data_url).replace('{vin}', vin)
    print("put_meta_data url ", complete_url)
    headers = api_headers.metadata_headers
    text_file = C2CtestData_jsonPath + r'meta_data.json'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        json_data = json.load(f)
        json_data["fleetId"] = "fleetId_test123"
        json_data["driverId"] = "driverId_test123"

    with open(max_file, 'w') as f:
        f.write(json.dumps(json_data))

    with open(max_file, 'r') as jsonFile:
        payload = json.load(jsonFile)
    print(payload)

    response = requests.put(complete_url, headers=headers, data=json.dumps(payload))
    # Parse HTTP response body to json format
    response_body = response.json()
    save_api_resp_into_file('meta_data', response.text)
    print(response_body)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)
    if response_body["responseCode"] == str(1200):
        assert (response_body["responseData"]["message"] == "Vehicle data updated successfully")
    else:
        print("response Code is not 1200. Rather found : " + str(response_body))
        assert False

    return response_body


def get_tridId_from_log(self):
    print("Read the trip id from c2c log file")
    ls = verify_message_in_log(self, tripId_code, tripId_code)

    if tripId_code in str(ls[0]):
        trip_id = str(ls[0]).split('trip_id: ')
        trip_id = str(trip_id[1])
        print(f"Trip Id should be generated in 'systemId_timestamp' format")
        testResult(self, "passed", "Telemetry message should be published to cloud via Hub ",
                   "Trip Id is generated in 'systemId_timestamp' format")
        print("Trip Id : ", trip_id)
    if str(ls[0]) == "Error":
        print("Trip Id is not generated or device logs are not updated. pls refer device logs in detail")
        testResult(self, "verificationFailed", "Trip Id should be generated in 'systemId_timestamp' format",
                   "Trip Id is not generated or device logs are not updated. pls refer device "
                   "logs in detail ")
        trip_id = ""
    return trip_id


def get_trip_summary_resp(self, device_type, trid_id):
    vin = getVIN(self, "tel", device_type)
    put_meta_data_resp(self)
    verify_message_in_log(self, 'trip_id: ')
    complete_url = str(api_endpoints.trip_summary_url).replace('{tripIdValue}', trid_id)
    print(complete_url)
    headers = api_headers.trip_headers
    payload = {}
    response = requests.get(complete_url, headers=headers, data=payload)
    # Parse HTTP response body to json format
    response_body = response.json()
    print(response_body)
    save_api_resp_into_file('trip_summary', response.text)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body["message"]))
        assert False
    return response_body

def get_trip_summary_resp(self, device_type, trip_id):
    vin = getVIN(self, "tel", device_type)
    put_meta_data_resp(self)
    complete_url = str(api_endpoints.trip_summary_url).replace('{tripIdValue}', trip_id)
    print(complete_url)
    headers = api_headers.trip_headers
    payload = {}
    response = requests.get(complete_url, headers=headers, data=payload)
    # Parse HTTP response body to json format
    response_body = response.json()
    print(response_body)
    save_api_resp_into_file('trip_summary', response.text)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body["message"]))
        assert False

    return response_body

def get_trip_waypoint_resp(self, device_type, trip_id):
    vin = getVIN(self, "tel", device_type)
    put_meta_data_resp(self)
    complete_url = str(api_endpoints.trip_waypoint_tripId_url).replace('{tripIdValue}', trip_id).replace('\n','')
    print(complete_url)
    headers = api_headers.trip_headers
    payload = {}
    response = requests.get(complete_url, headers=headers, data=payload)
    # Parse HTTP response body to json format
    response_body = response.json()
    print(response_body)
    save_api_resp_into_file('trip_waypoint', response.text)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body["message"]))
        assert False

    return response_body


def initiate_commandCtrl(self, appid, name, area, value):
    vin = getVIN(self, "tel", deviceType_IVI)

    headers = api_headers.headers_command_cntrl
    text_file = C2CtestData_jsonPath + r'commandControl.json'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        json_data = json.load(f)
        json_data["appid"] = appid
        json_data["name"] = name
        json_data["payload"][0]["area"] = area
        json_data["payload"][0]["value"] = value
        json_data["target"]["vins"][0] = vin

    with open(max_file, 'w') as f:
        f.write(json.dumps(json_data))

    with open(max_file, 'r') as jsonFile:
        payload = json.load(jsonFile)
    print(payload)

    complete_url = str(api_endpoints.commandCtrl_initiate_post_url)
    print(complete_url)
    response = requests.post(complete_url, headers=headers, data=json.dumps(payload))
    # Parse HTTP response body to json format
    response_body = response.json()
    print(response_body)
    save_api_resp_into_file('commandControl' + "_" + name, response.text)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)
    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body["message"]))
        assert False
    return response_body


def get_commandCtrl_trackingId(self, response):
    trackingId = response["responseData"]['trackingId']
    print("Command Control - Tracking Id : ", trackingId)
    return trackingId


def get_commandCtrl_resp(self, trackingId):
    complete_url = str(api_endpoints.commandCtrl_get_resp_url).replace('{requestId}', trackingId)
    print("Complete_url :", complete_url)
    headers = api_headers.headers_command_cntrl_resp
    payload = {}
    response = requests.get(complete_url, headers=headers, data=payload)
    # Parse HTTP response body to json format
    response_body = response.json()
    print(response_body)
    save_api_resp_into_file('CommandControl' + '_' + trackingId, response.text)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)
    if response_body["responseCode"] == str(1200) or response_body["responseCode"] == 1200:
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body["message"]))
        assert False
    return response_body


def verify_commandCtrl_apiResp_status(self, response):
    print("Tracking Status :", response["responseData"]["trackingStatus"])
    status = response["responseData"]["data"][0]["status"]
    print("Status : ", status)
    if status == 103:
        assert True
    else:
        print("status is not 103. Rather found : " + str(status))
        assert False
    return status


def verify_msg_details_pub2Cloud(self, msg_type, msg_attribute):
    # verify Command Control message published to cloud
    if msg_type == commndctrl_msg_type_code:
        msg = commndctrl_msg_type_code
        msg_text = "Command & control"
    if msg_type == telemetry_msg_type_code_tel:
        msg = telemetry_msg_type_code_tel
        msg_text = "Telemetry"
    ls = verify_message_in_log(self, telemetry_msg_id_published2Cloud, msg)

    if telemetry_msg_id_published2Cloud in str(ls[0]) and msg in str(ls[0]):
        status = "Found"
        print(
            f"Command & control message published to cloud' {telemetry_msg_id_published2Cloud} with {msg} '")
        testResult(self, "passed", msg_text + "message should be published to cloud via Hub ",
                   msg_text + " message is published to cloud and device logs are updated accordingly, pls refer "
                              "device logs for detailed info")

        print("c2c logs line data : => ", ls[0])

        try:

            ls1 = str(ls[0]).split('"body": "')

            data = str(ls1[1])
            lenmax = len(data) - len(data) % 4
            decodedBytes = base64.b64decode(data[0:lenmax]).decode()

            msg_body_data = str(decodedBytes)
            print("Decoded message body :", msg_body_data)

            if msg_attribute in msg_body_data:
                testResult(self, "passed",
                           msg_attribute + " value should be present in the telemetry message published to the cloud",
                           msg_attribute + " value is present in the telemetry message published to the cloud and device logs are updated accordingly, pls refer "
                           "device logs for detailed info")
            if msg_attribute not in msg_body_data:
                testResult(self, "verificationFailed",
                           msg_attribute + " value should be present in the telemetry message published to the cloud",
                           msg_attribute + " value is not present in the telemetry message published to the cloud or device logs are not updated accordingly, pls refer "
                           "device logs for detailed info")
        except:
            print("Unable to decode message body data due to truncated logs")

    elif str(ls[0]) == "Error":
        status = "NotFound"
        print(
            msg_text + " message is not published to cloud or device logs are not updated. pls refer device logs in detail")
        testResult(self, "verificationFailed", "Command & control message should be published to cloud via Hub ",
                   msg_text + " message is not published to cloud or device logs are not updated. pls refer device "
                              "logs in detail ")
    else:
        status = "NotFound"
    print("----------------------------------------------------------")
    return status


def verify_commandCtrl_msg_in_deviceLogs(self, OnboardingType, chipsetType, msg_type, msg_attribute):
    # ===========================================================================================
    # Pull logs & verify command & control msg
    # ===========================================================================================
    print("Pull/Fetch device logs for validation : ")
    i = 1
    while i <= 10:
        pull_logs_from_IVI_device(self, OnboardingType, chipsetType)
        status = verify_msg_details_pub2Cloud(self, msg_type, msg_attribute)
        print("Status : ", status)
        if status == "Found":
            break
        i = i + 1
        time.sleep(5)

    print("Logs are fetched from device to host machine @ desired location and verified ")
    if status == "Found":
        print(
            f"Command & control message published to cloud' {telemetry_msg_id_published2Cloud} with {msg_type} '")
        testResult(self, "passed", "Command & control message should be published to cloud via Hub ",
                   "Command & control message is published to cloud and device logs are updated accordingly, pls refer "
                   "device logs for detailed info")

    elif status == "NotFound":
        print(
            "Command & control message is not published to cloud or device logs are not updated or logs have been rotated. pls refer device logs in detail")
        testResult(self, "verificationFailed", "Command & control message should be published to cloud via Hub ",
                   "Command & control message is not published to cloud or device logs are not updated or logs have been rotated. pls refer device "
                   "logs in detail ")

    print("----------------------------------------------------------")

def decode_msg_body(data):
    ls1 = str(data).split('"body": "')

    data = str(ls1[1])
    lenmax = len(data) - len(data) % 4
    decodedBytes = base64.b64decode(data[0:lenmax]).decode()

    msg_body_data = str(decodedBytes)
    print("Decoded message body :", msg_body_data)

    return msg_body_data


def commandCtrl_resp(self, trackingId):
    vin = getVIN(self, "tel", deviceType_IVI)
    put_meta_data_resp(self)
    verify_message_in_log(self, 'trip_id: ')
    complete_url = str(api_endpoints.trip_summary_url).replace('{tripIdValue}', "sysfc4fbd6b044611eebe7e_1686058134272")
    print(complete_url)
    headers = api_headers.trip_headers
    payload = {}
    response = requests.get(complete_url, headers=headers, data=payload)
    # Parse HTTP response body to json format
    response_body = response.json()
    print(response_body)
    save_api_resp_into_file('trip_summary', response.text)

    return response_body

def notifcation_api(self, msg):
    vin = getVIN(self, "tel", deviceType_IVI)
    systemId = get_SystemId(self, deviceType_IVI)

    headers = api_headers.notification_headers
    text_file = C2CtestData_jsonPath + r'notification.json'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        json_data = json.load(f)
        json_data["target"][0]["systemId"] = systemId
        json_data["message"] = msg

    with open(max_file, 'w') as f:
        f.write(json.dumps(json_data))

    with open(max_file, 'r') as jsonFile:
        payload = json.load(jsonFile)
    print(payload)

    complete_url = str(api_endpoints.notification_url)
    print(complete_url)
    response = requests.post(complete_url, headers=headers, data=json.dumps(payload))
    # Parse HTTP response body to json format
    response_body = response.json()
    print(response_body)
    save_api_resp_into_file('notification', response.text)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)
    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body["message"]))
        assert False
    return response_body

def fileUpload_api(self, msg):
    vin = getVIN(self, "tel", deviceType_IVI)
    systemId = get_SystemId(self, deviceType_IVI)

    trip = systemId + '_1682333506000_1682333506000.dat'

    filepath = C2CtestData_jsonPath + 'filename'

    headers = api_headers.fileupload_headers
    text_file = C2CtestData_jsonPath + r'fileUpload.json'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        json_data = json.load(f)
        json_data["target"][0]["systemId"] = systemId
        json_data["message"] = msg

    with open(max_file, 'w') as f:
        f.write(json.dumps(json_data))

    with open(max_file, 'r') as jsonFile:
        payload = json.load(jsonFile)
    print(payload)

    complete_url = str(api_endpoints.fileUpload_url)
    print(complete_url)
    files = {'file': open(filepath, 'rb')}
    # print(files)
    response = requests.post(api_endpoints.fileUpload_url, headers=headers, data=open(filepath, 'rb').read())
    #response = requests.post(complete_url, headers=headers, data=json.dumps(payload))
    # Parse HTTP response body to json format
    response_body = response.json()
    print(response_body)
    save_api_resp_into_file('fileupload', response.text)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)
    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body["message"]))
        assert False
    return response_body

def get_latest_trip_details_resp(self, device_type):
    vin = getVIN(self, "tel", device_type)
    systemId = get_SystemId(self, device_type)
    complete_url = str(api_endpoints.latest_trip_details_url)
    print(complete_url)
    headers = api_headers.latestTrip_headers

    text_file = C2CtestData_jsonPath + r'latestTripDetails.json'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        json_data = json.load(f)
        json_data["vin"]= vin
        json_data["systemId"] = systemId

    with open(max_file, 'w') as f:
        f.write(json.dumps(json_data))

    with open(max_file, 'r') as jsonFile:
        payload = json.load(jsonFile)
    print(payload)
    response = requests.post(complete_url, headers=headers, data=json.dumps(payload))
    # Parse HTTP response body to json format
    response_body = response.json()
    print(response_body)
    save_api_resp_into_file('latest_trip_details', response.text)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body["message"]))
        assert False

    return response_body
