import glob
import json
import os
import time
from datetime import datetime, timedelta, timezone
import requests

from C2CModules.device_reuse_modules import getModel, getVIN
from C2CModules.e2e_c2c_modules import saveAPIrespIntoFile, testResult
from C2CModules.api_endpoints import api_endpoints
from C2CModules.e2e_testData import payloadPath, C2CtestReport_otaPath, firm_reg, testData, C2CtestData_jsonPath


def apiHeader_fota(self):
    text_file = payloadPath + r'otaHeaders_fota.txt'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file, 'r') as jsonFile:
        headers = jsonFile.read()
    headers = parsed = json.loads(headers)
    return headers


def apiHeader_fotaFile(self):
    text_file = payloadPath + r'otaHeaders_fotaFile.txt'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file, 'r') as jsonFile:
        headers = jsonFile.read()
    headers = parsed = json.loads(headers)
    return headers

def apiHeader_sotaFile(self):
    text_file = payloadPath + r'otaHeaders_sotaFile.txt'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file, 'r') as jsonFile:
        headers = jsonFile.read()
    headers = parsed = json.loads(headers)
    return headers


def apiHeader_sota(self):
    text_file = payloadPath + r'otaHeaders_sota.txt'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file, 'r') as jsonFile:
        headers = jsonFile.read()
    headers = parsed = json.loads(headers)
    return headers


def fileVer(self, file, option, FirmwareVerFlag_fota, FirmwareVersion_fota):
    print("\n")
    if option == "baseFirmware":
        if FirmwareVerFlag_fota == "Yes":
            fileVer = FirmwareVersion_fota
        else:
            fileVer = file.split('_')
            fileVer = fileVer[1].replace('.zip', '')
            fileVer = fileVer.replace('v', '')

    elif option == "updateFirmware":
        if FirmwareVerFlag_fota == "Yes":
            fileVer = FirmwareVersion_fota
        else:
            fileVer = file.split('_')
            fileVer = fileVer[1].replace('.zip', '')
            fileVer = fileVer.replace('v', '')
    else:
        print("Incorrect Input")
    return fileVer


def sotaFileVer(self,  packageNameFlag_sota,packageName_sota, packageVersionFlag_sota, packageVersion_sota, filename_sota):
    if packageNameFlag_sota == "Yes":
        appName = packageName_sota
    else:
        filenameS = filename_sota.split('_')
        appName = filenameS[0]

    if packageVersionFlag_sota == "Yes":
        targetVersion = packageVersion_sota
    else:
        filenameS = filename_sota.split('_')
        filenameV = filenameS[1].replace('.update', '')
        targetVersion = filenameV.replace('.zip', '')
        targetVersion = targetVersion.replace('v', '')
    return appName, targetVersion

def listFirmware(self, firmwareId, onboarding_Type):
    time.sleep(30)
    s = 0
    headers = apiHeader_fota(self)
    model = getModel(self, "fota", onboarding_Type)

    response = requests.get(api_endpoints.listFirmware_url, headers=headers)

    # Parse HTTP response body to json format
    response_body = response.json()

    saveAPIrespIntoFile("listFirmware_" + model, response.text, "OTA")
    # print(response.text)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseData"]["message"] == "SUCCESS" or response_body["responseData"]["message"] == "14000":
        for i in range(5):
            modelName = response_body["responseData"]["data"][i]['model']
            firmId = response_body["responseData"]["data"][i]['id']
            if modelName == model and str(firmwareId) == str(firmId):
                s = int(i)
        firmId = response_body["responseData"]["data"][int(s)]['id']
        modelName = response_body["responseData"]["data"][int(s)]['model']
        status = response_body["responseData"]["data"][int(s)]['status']
        description = response_body["responseData"]["data"][int(s)]['description']
        system = response_body["responseData"]["data"][int(s)]['system']
        firmwareVersion = response_body["responseData"]["data"][int(s)]['firmwareVersion']
        fileName = response_body["responseData"]["data"][int(s)]['fileName']
        isDiffImage = response_body["responseData"]["data"][int(s)]['isDiffImage']
        isBase = response_body["responseData"]["data"][int(s)]['isBase']
        downloadConsent = response_body["responseData"]["data"][int(s)]['downloadConsent']
        installConsent = response_body["responseData"]["data"][int(s)]['installConsent']
        rebootConsent = response_body["responseData"]["data"][int(s)]['rebootConsent']

        if str(firmwareId) == str(firmId):
            if status == "SUCCESS":
                testResult(self, "passed",
                                      "Firmware package should listed with SUCCESS status on SMP UI-> Configuration -> OTA -> OTA Files page",
                                      "Firmware package is listed with SUCCESS status on SMP UI-> Configuration -> OTA -> OTA Files page")

            elif status == "FAILURE":
                testResult(self, "failed",
                                      "Firmware package should listed with SUCCESS status on SMP UI-> Configuration -> OTA -> OTA Files page",
                                      "Firmware package is listed with FAILURE status on SMP UI-> Configuration -> OTA -> OTA Files page")

            elif status == "ARCHIVE":
                testResult(self, "failed",
                                      "Firmware package should listed with SUCCESS status on SMP UI-> Configuration -> OTA -> OTA Files page",
                                      "Firmware package is listed with ARCHIVE status on SMP UI-> Configuration -> OTA -> OTA Files page")

        elif str(firmwareId) != str(firmId):
            if firmwareId == 1:
                print("\n")
            else:
                testResult(self, "failed",
                                      "Firmware package should be listed on first row on SMP UI-> Configuration -> OTA -> OTA Files page",
                                      "Firmware package is not listed on first row or on SMP UI-> Configuration -> OTA -> OTA Files page")

    elif response_body["message"] != "SUCCESS":
        testResult(self, "failed",
                              "Firmware package should be listed on first row on SMP UI-> Configuration -> OTA -> OTA Files page",
                              "Firmware package list is not displayed on SMP UI-> Configuration -> OTA -> OTA Files page")

    else:
        print("Something went wrong")
    return model


def listFirmwareScript(self, scriptId, onboarding_Type):
    time.sleep(30)
    refId = ''
    s = 0
    headers = apiHeader_fota(self)
    model = getModel(self, "fota", onboarding_Type)

    response = requests.get(api_endpoints.listFirmwareScript_url, headers=headers)

    # Parse HTTP response body to json format
    response_body = response.json()

    saveAPIrespIntoFile("listFirmwareScript_" + model, response.text, "OTA")
    # print(response_body)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == "14000" or response_body["responseCode"] == 14000:
        for i in range(5):
            modelName = response_body["responseData"]["data"][i]['model']
            refId = response_body["responseData"]["data"][i]['refId']
            if modelName == model and scriptId == str(refId):
                s = int(i)
        refId = response_body["responseData"]["data"][int(s)]['refId']
        name = response_body["responseData"]["data"][int(s)]['name']
        modelName = response_body["responseData"]["data"][int(s)]['model']
        status = response_body["responseData"]["data"][int(s)]['status']
        releaseNote = response_body["responseData"]["data"][int(s)]['releaseNote']
        sourceVersion = response_body["responseData"]["data"][int(s)]['steps'][0]['sourceVersion']
        targetVersion = response_body["responseData"]["data"][int(s)]['steps'][0]['targetVersion']
        if modelName == model and scriptId == str(refId):
            if status == "SUCCESS":
                testResult(self, "passed",
                                      "Firmware script should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts page",
                                      name +
                                      " - Firmware script is listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts page")

            elif status == "FAILURE":
                testResult(self, "failed",
                                      "Firmware script should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts page",
                                      name +
                                      " - Firmware script is listed with FAILURE status on SMP UI-> Configuration -> OTA -> Scripts page")

            elif status == "ARCHIVE":
                testResult(self, "failed",
                                      "Firmware script should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts page",
                                      name +
                                      " - Firmware script is listed with ARCHIVE status on SMP UI-> Configuration -> OTA -> Scripts page")

        elif modelName != model or scriptId != refId:
            testResult(self, "failed",
                                  "Firmware script should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts page",
                                  "Firmware script is not listed on first row or on SMP UI-> Configuration -> OTA -> Scripts page")

    elif response_body["responseCode"] != "14000":
        testResult(self, "failed",
                              "Firmware1 script should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts page",
                              "Firmware1 script list is not displayed on SMP UI-> Configuration -> OTA -> Scripts page")

    else:
        print("Something went wrong")

    text_file = open(C2CtestReport_otaPath + r'beforeOTA\refId_fota.txt', "w")
    text_file.write(refId)
    text_file.close()
    return refId

def presignedUrl(self, model, filename, option, device_type):
    if option == "fota":
        headers = apiHeader_fota(self)
        if device_type == "IVI":
            payload = {"filename": filename, "system": "IVI", "model-name": model}
        if device_type == "TCU":
            payload = {"filename": filename, "system": "Telematics", "model-name": model}
        url = api_endpoints.presignedFirmware_url
    if option == "sota":
        headers = apiHeader_sota(self)
        if device_type == "IVI":
            payload = {"filename": filename, "system": "IVI", "model-name": model}
        if device_type == "TCU":
            payload = {"filename": filename, "system": "Telematics", "model-name": model}
        url = api_endpoints.presignedSota_url
        print(url)

    response = requests.post(url, headers=headers, data=json.dumps(payload))
    response_body = response.json()

    saveAPIrespIntoFile("presignedUrl_" + model, response.text, "OTA")

    # print(response.text)
    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)
    print(response_body["responseData"]["message"])
    upload_url = response_body["responseData"]["message"]
    saveAPIrespIntoFile("uploadUrl_" + model, "OTA", option)
    return response_body["responseData"]["message"]


def uploadFile(self, model, upload_url, filepath, filename):
    headers = apiHeader_fotaFile(self)
    # print("Final file path : => ", filepath)
    files = {'file': open(filepath, 'rb')}
    # print(files)
    response = requests.put(upload_url, headers=headers, data=open(filepath, 'rb').read())

    saveAPIrespIntoFile("uploadFile_" + filename + '_' + model, response.text, "OTA")

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)


def uploadFile(self, model, upload_url, filepath):
    try:
        headers = apiHeader_sotaFile(self)
        # print(headers)
        print("Final file path : => ", filepath)
        files = {'file': open(filepath, 'rb')}
        # print(files)
        data = open(filepath, 'rb').read()
        # headers = {
        #     'api-key': 'c290YWFwaUAxMjM',
        #     'x-requestor': 'xrequestor',
        #     'appContent-Type': 'application/json',
        #     #'Content-Type': 'text/plain'
        #     'Content-Type': 'application/binary'
        # }
        # print(data)
        response = requests.put(upload_url, data=data, headers=headers)
        # print(response)

        # response = requests.put(upload_url, headers=headers, files=files)
        # print(response)

        saveAPIrespIntoFile("uploadFile_" + "IVI" + '_' + model, response.text, "OTA")

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)
    except:
        print("Something went wrong while uploading file")



def triggerFirmwareUpdate(self, onboarding_Type):
    headers = apiHeader_fota(self)
    model = getModel(self, "fota", onboarding_Type)
    startDate = int(datetime.now(tz=timezone.utc).timestamp()) * 1000
    print("Start Date : ", startDate)
    endDate = int(datetime.now(tz=timezone.utc).timestamp()) * 1000 + 100000000
    print("End Date : ", endDate)

    scriptId = read_refID(self, "fota")
    print(scriptId)

    vin = getVIN(self, "fota", onboarding_Type)
    print("VIN No. : => ", vin)

    text_file = payloadPath + 'triggerFirmwareUpdatePayload.json'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        json_data = json.load(f)
        json_data["vins"][0] = vin
        json_data["scriptid"] = scriptId
        json_data["period"]["startDate"] = startDate
        json_data["period"]["endDate"] = endDate

    with open(max_file, 'w') as f:
        f.write(json.dumps(json_data))

    with open(max_file, 'r') as jsonFile:
        payload = json.load(jsonFile)

    # Act: convert dict to json by json.dumps() for body data and send POST request.

    response = requests.post(api_endpoints.triggerUpdateFirmware_url, headers=headers, data=json.dumps(payload))
    # Parse HTTP response body to json format
    response_body = response.json()
    saveAPIrespIntoFile("triggerFirmwareUpdate_" + model, response.text, "OTA")
    # print(response_body)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(14000):
        if response_body["responseData"]["message"] == "success" or response_body["responseData"]["message"] == "Success":
            scheduleId = str(response_body["responseData"]["scheduleId"])
            testResult(self, "passed", "Firmware should be scheduled successfully and campaign should started ",
                                  "Firmware scheduled successfully OR Campaign is started ")

    elif response_body["responseCode"] != str(14000):
        #print(response_body["responseData"]["message"])
        testResult(self, "failed", "Firmware should be scheduled successfully and campaign should started ",
                              "Firmware is not scheduled successfully OR Campaign is not started  " + " Reason for failure is : " + response_body["responseData"]["message"])

    else:
        print("Something went wrong")
    text_file = open(C2CtestReport_otaPath + r'beforeOTA\scheduleId_fota.txt', "w")
    text_file.write(scheduleId)
    text_file.close()
    return scheduleId


def listFirmwareSchedules(self, scheduleId, onboarding_Type):
    time.sleep(30)
    refId = ''
    s = 0
    headers = apiHeader_fota(self)
    model = getModel(self, "fota", onboarding_Type)

    response = requests.get(api_endpoints.listFirmwareUpdates_url, headers=headers)

    # Parse HTTP response body to json format
    response_body = response.json()

    saveAPIrespIntoFile("listFirmwareSchedules_" + model, response.text, "OTA")
    # print(response_body)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == 14000 or response_body["responseCode"] == "14000":

        for i in range(5):
            modelName = response_body["responseData"]["data"][i]['model']
            refId = response_body["responseData"]["data"][i]['refId']
            if modelName == model and scheduleId == str(refId):
                s = int(i)

        modelName = response_body["responseData"]["data"][int(s)]['model']
        status = response_body["responseData"]["data"][int(s)]['status']
        offered = response_body["responseData"]["data"][int(s)]['offered']
        accepted = response_body["responseData"]["data"][int(s)]['accepted']
        complete = response_body["responseData"]["data"][int(s)]['complete']
        scriptId = response_body["responseData"]["data"][int(s)]['script']['id']
        scriptName = response_body["responseData"]["data"][int(s)]['script']['name']
        refId = response_body["responseData"]["data"][int(s)]['refId']

        if modelName == model and scheduleId == str(refId):
            if status == "SUCCESS":
                testResult(self, "passed",
                                      "Firmware schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates",
                                      scriptName +
                                      " - Firmware schedule/campaign is listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates")

            elif status == "FAILURE":
                testResult(self, "failed",
                                      "Firmware schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates",
                                      scriptName +
                                      " - Firmware schedule/campaign is listed with FAILURE status on SMP UI-> Updates -> OTA -> OTA Updates")

            elif status == "ARCHIVE":
                testResult(self, "failed",
                                      "Firmware schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates",
                                      scriptName +
                                      " - Firmware schedule/campaign is listed with ARCHIVE status on SMP UI-> Updates -> OTA -> OTA Updates")

        elif modelName != model or scriptId != refId:
            testResult(self, "failed",
                                  "Firmware schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates",
                                  "Firmware schedule/campaign is not listed on first row or on SMP UI-> Updates -> OTA -> OTA Updates")

    elif response_body["responseCode"] != "14000":
        testResult(self, "failed",
                              "Firmware schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates",
                              "Firmware schedule/campaign list is not displayed on SMP UI-> Updates -> OTA -> OTA Updates")

    else:
        print("Something went wrong")

    return status, offered, accepted, complete


def listFirmwareScheduleStatus(self, onboarding_Type):
    time.sleep(30)
    refId = ''
    headers = apiHeader_fota(self)
    model = getModel(self, "fota", onboarding_Type)
    vin = getVIN(self, "fota", onboarding_Type)
    scheduleId = read_scheduleId(self, "fota")
    payload = {"vins": [vin]}

    listFirmwareUpdates_scheduleStatus = firm_reg + "/ota-services/v2/schedule-status/" + scheduleId + "?pageNumber=1&pageSize=10"
    response = requests.post(listFirmwareUpdates_scheduleStatus, data=json.dumps(payload), headers=headers)
    # print(listFirmwareUpdates_scheduleStatus)

    # Parse HTTP response body to json format
    response_body = response.json()

    saveAPIrespIntoFile("listFirmwareScheduleStatus_" + model, response.text, "OTA")
    # print(response_body)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(14000):

        vinNo = response_body["responseData"]["data"][0]['vin']
        status = response_body["responseData"]["data"][0]['status']

        # print(vin, vinNo)

        if vin == vinNo:
            print("Firmware schedule-status is listed with " + status + " status on SMP UI")

    return status


def listPackages(self, packageId, onboarding_Type):
    time.sleep(30)
    s = 0
    headers = apiHeader_sota(self)
    model = getModel(self, "sota", onboarding_Type)

    response = requests.get(api_endpoints.listPackage_url, headers=headers)

    # Parse HTTP response body to json format
    response_body = response.json()

    saveAPIrespIntoFile("listPackages_" + model, response.text, "OTA")
    #print(response.text)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(15000):
        for i in range(5):
            modelName = response_body["responseData"]["dataList"][i]['model']
            packId = response_body["responseData"]["dataList"][i]['packageId']
            if modelName == model and packageId == packId:
                s = int(i)
        packId = response_body["responseData"]["dataList"][int(s)]['packageId']
        modelName = response_body["responseData"]["dataList"][int(s)]['model']
        status = response_body["responseData"]["dataList"][int(s)]['status']
        description = response_body["responseData"]["dataList"][int(s)]['description']
        system = response_body["responseData"]["dataList"][int(s)]['system']
        fileName = response_body["responseData"]["dataList"][int(s)]['filename']
        isDiffImage = response_body["responseData"]["dataList"][int(s)]['isDiffImage']
        downloadConsent = response_body["responseData"]["dataList"][int(s)]['downloadConsent']
        installConsent = response_body["responseData"]["dataList"][int(s)]['installConsent']
        rebootConsent = response_body["responseData"]["dataList"][int(s)]['rebootConsent']
        if modelName == model and packageId == packId:
            if status == "SUCCESS":
                testResult(self, "passed",
                                      "Update package should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> OTA Files -> SOTA page",
                                      "Update package is listed with SUCCESS status on SMP UI-> Configuration -> OTA -> OTA Files -> SOTA page")

            elif status == "FAILURE":
                testResult(self, "failed",
                                      "Update package should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> OTA Files -> SOTA page",
                                      "Update package is listed with FAILURE status on SMP UI-> Configuration -> OTA -> OTA Files -> SOTA page")

            elif status == "ARCHIVE":
                testResult(self, "failed",
                                      "Firmware package should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> OTA Files -> SOTA page",
                                      "Firmware package is listed with ARCHIVE status on SMP UI-> Configuration -> OTA -> OTA Files -> SOTA page")

        elif modelName != model or packageId != packId:
            if packageId == 0:
                print("\n")
            else:
                testResult(self, "failed",
                                      "SOTA Update package should be listed with SUCCESS message on first row on SMP UI-> Configuration -> OTA -> OTA Files -> SOTA page",
                                      "SOTA Update package is not listed on first row on SMP UI-> Configuration -> OTA -> OTA Files -> SOTA page")

    elif response_body["message"] != "SUCCESS":
        testResult(self, "failed",
                              "SOTA Update package should be listed with SUCCESS message on first row on SMP UI-> Configuration -> OTA -> OTA Files -> SOTA page",
                              "SOTA Update package list is not displayed on SMP UI-> Configuration -> OTA -> OTA Files -> SOTA page")

    else:
        print("Something went wrong")

    return model


def listSOTAScript(self, scriptId, command, onboarding_Type):
    time.sleep(30)
    refId = ''
    s = 0
    headers = apiHeader_sota(self)
    model = getModel(self, "sota", onboarding_Type)

    response = requests.get(api_endpoints.listSotaScript_url, headers=headers)

    # Parse HTTP response body to json format
    response_body = response.json()

    saveAPIrespIntoFile("listSOTAScript_" + model+"_"+command, response.text, "OTA")
    # print(response_body)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(15000):
        for i in range(5):
            modelName = response_body["responseData"]["dataList"][i]['model']
            refId = response_body["responseData"]["dataList"][i]['scriptId']
            if modelName == model and scriptId == str(refId):
                s = int(i)
        scriptName = response_body["responseData"]["dataList"][int(s)]['scriptName']
        applicationName = response_body["responseData"]["dataList"][int(s)]['applicationName']
        command = response_body["responseData"]["dataList"][int(s)]['command']
        status = response_body["responseData"]["dataList"][int(s)]['status']
        refId = response_body["responseData"]["dataList"][int(s)]['scriptId']
        modelName = response_body["responseData"]["dataList"][int(s)]['model']
        targetVersion = response_body["responseData"]["dataList"][int(s)]['targetVersion']
        if modelName == model and scriptId == str(refId):
            if status == "SUCCESS":
                testResult(self, "passed",
                                      "SOTA script should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts -> SOTA page",
                                      scriptName +
                                      " - SOTA script is listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts -> SOTA page")

            elif status == "FAILURE":
                testResult(self, "failed",
                                      "SOTA script should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts -> SOTA page",
                                      scriptName +
                                      " - SOTA script is listed with FAILURE status on SMP UI-> Configuration -> OTA -> Scripts -> SOTA page")

            elif status == "ARCHIVE":
                testResult(self, "failed",
                                      "SOTA script should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts -> SOTA page",
                                      scriptName +
                                      " - SOTA script is listed with ARCHIVE status on SMP UI-> Configuration -> OTA -> Scripts -> SOTA page")

        elif modelName != model or scriptId != refId:
            testResult(self, "failed",
                                  "SOTA script should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts -> SOTA page",
                                  "SOTA script is not listed on first row or on SMP UI-> Configuration -> OTA -> Scripts -> SOTA page")

    elif response_body["responseCode"] != str(15000):
        testResult(self, "failed",
                              "SOTA script should be listed with SUCCESS status on SMP UI-> Configuration -> OTA -> Scripts -> SOTA page",
                              "SOTA script list is not fetched")

    else:
        print("Something went wrong")

    text_file = open(C2CtestReport_otaPath + r'beforeOTA\refId_sota.txt', "w")
    text_file.write(refId)
    text_file.close()
    return refId


def triggerSOTAUpdate(self, scriptId, command, onboarding_Type):
    headers = apiHeader_sota(self)
    model = getModel(self, "sota", onboarding_Type)
    scheduleId = ''
    startDate = int(datetime.now(tz=timezone.utc).timestamp()) * 1000
    print("Start Date : ", startDate)
    endDate = int(datetime.now(tz=timezone.utc).timestamp()) * 1000 + 100000000
    print("End Date: ", endDate)

    vin = getVIN(self, "sota", onboarding_Type)
    print("VIN No. : => ", vin)

    text_file = payloadPath + 'triggerSOTAUpdatePayload.json'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        json_data = json.load(f)
        json_data["vins"][0] = vin
        json_data["scriptId"] = scriptId
        json_data["period"]["startDate"] = startDate
        json_data["period"]["endDate"] = endDate

    with open(max_file, 'w') as f:
        f.write(json.dumps(json_data))

    with open(max_file, 'r') as jsonFile:
        payload = json.load(jsonFile)
        # print(payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.

    response = requests.post(api_endpoints.triggerUpdatePackage_url, headers=headers, data=json.dumps(payload))
    # Parse HTTP response body to json format
    response_body = response.json()
    saveAPIrespIntoFile("triggerSotaUpdate_" + model +"_"+command, response.text, "OTA")
    # print(response_body)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(15000):
        if response_body["responseData"]["message"] == "success" or response_body["responseData"]["message"] == "Success":
            scheduleId = str(response_body["responseData"]["scheduleId"])
            testResult(self, "passed",
                                  "SOTA update should be scheduled successfully and campaign should be started ",
                                  "SOTA update scheduled successfully and campaign is started ")

    elif response_body["responseCode"] != str(15000):
        #print(response_body["responseData"]["message"])
        testResult(self, "failed", "SOTA update should be scheduled successfully and campaign should be started ",
                              "SOTA update is not scheduled successfully OR Campaign is not started. " + " Reason for failure is : " + response_body["responseData"]["message"])

    else:
        print("Something went wrong")
    text_file = open(C2CtestReport_otaPath + r'beforeOTA\scheduleId_sota.txt', "w")
    text_file.write(scheduleId)
    text_file.close()
    return scheduleId


def listSOTAupdateSchedules(self, scheduleId,command, onboarding_Type):
    time.sleep(30)
    refId = ''
    s = 0
    headers = apiHeader_sota(self)
    model = getModel(self, "sota", onboarding_Type)

    response = requests.get(api_endpoints.listSotaUpdate_url, headers=headers)

    # Parse HTTP response body to json format
    response_body = response.json()

    saveAPIrespIntoFile("listSOTAschedules_" + model+"_"+command, response.text, "OTA")
    # print(response_body)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == "Success" or response_body["responseCode"] == str(15000):

        for i in range(5):
            modelName = response_body["responseData"]["dataList"][i]['model']
            refId = response_body["responseData"]["dataList"][i]['scheduleId']
            if modelName == model and scheduleId == str(refId):
                s = int(i)

        modelName = response_body["responseData"]["dataList"][int(s)]['model']
        status = response_body["responseData"]["dataList"][int(s)]['status']
        offered = response_body["responseData"]["dataList"][int(s)]['offered']
        accepted = response_body["responseData"]["dataList"][int(s)]['accepted']
        complete = response_body["responseData"]["dataList"][int(s)]['complete']
        scriptId = response_body["responseData"]["dataList"][int(s)]['scriptId']
        scriptName = response_body["responseData"]["dataList"][int(s)]['scriptName']
        command = response_body["responseData"]["dataList"][int(s)]['command']
        refId = response_body["responseData"]["dataList"][int(s)]['scheduleId']
        # print(modelName, model, scheduleId, refId)
        if modelName == model and scheduleId == str(refId):
            if status == "SUCCESS":
                testResult(self, "passed",
                                      "SOTA update schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates -> SOTA page",
                                      scriptName +
                                      " - SOTA update schedule/campaign is listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates -> SOTA page")

            elif status == "FAILURE":
                testResult(self, "failed",
                                      "SOTA update /schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates -> SOTA page",
                                      scriptName +
                                      " - SOTA update schedule/campaign is listed with FAILURE status on SMP UI-> Updates -> OTA -> OTA Updates -> SOTA page")

            elif status == "ARCHIVE":
                testResult(self, "failed",
                                      "SOTA update /schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates -> SOTA page",
                                      scriptName +
                                      " - SOTA update schedule/campaign is listed with ARCHIVE status on SMP UI-> Updates -> OTA -> OTA Updates -> SOTA page")

        elif modelName != model or scriptId != refId:
            testResult(self, "failed",
                                  "SOTA update /schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates -> SOTA page",
                                  "SOTA update schedule/campaign is not listed on first row or on SMP UI-> Updates -> OTA -> OTA Updates -> SOTA page")

    elif response_body["message"] != "Success" or response_body["responseCode"] != str(15000):
        testResult(self, "failed",
                              "SOTA update /schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> OTA Updates -> SOTA page",
                              "SOTA update schedule/campaign list is not displayed on SMP UI-> Updates -> OTA -> OTA Updates -> SOTA page")

    else:
        print("Something went wrong")

    return refId


def replaceLineWithText(self, filename, linenumb, replacedtext):
    with open(filename, 'r') as givenfilecontent:
        filelines = givenfilecontent.readlines()
        filelines[linenumb - 1] = replacedtext
    with open(filename, 'w') as givenfilecontent:
        givenfilecontent.writelines(filelines)
    print('The given linenumber = ', linenumb, ' is replaced with {', replacedtext, '}')


def read_refID(self, option):
    if option == "fota":
        filename = 'refId_fota.txt'
    elif option == "sota":
        filename = 'refId_sota.txt'
    text_file = C2CtestReport_otaPath + 'beforeOTA' + '\\' + filename
    # text_file = folderPath + r'C2CtestData\usr\local\json\refId.txt'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        refID = f.read()
    return refID


def read_scheduleId(self, option):
    if option == "fota":
        filename = 'scheduleId_fota.txt'
    elif option == "sota":
        filename = 'scheduleId_sota.txt'
    text_file = C2CtestReport_otaPath + 'beforeOTA' + '\\' + filename
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        scheduleId = f.read()
    return scheduleId


def stabilityCheck_triggerFirmwareUpdate(self, vin, model, scriptId):
    headers = apiHeader_fota(self)
    now = datetime.now()
    format = "%Y-%m-%d %I:%M:%S"
    # format datetime using strftime()
    startDate = now.strftime(format)
    dt = datetime.now() + timedelta(days=1)
    endDate = dt.strftime(format)
    print("Model No. : => ", model)
    print("VIN No. : => ", vin)

    text_file = payloadPath + 'triggerFirmwareUpdatePayload.json'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        json_data = json.load(f)
        json_data["vins"][0] = vin
        json_data["scriptid"] = scriptId
        json_data["period"]["startDate"] = startDate
        json_data["period"]["endDate"] = endDate

    with open(max_file, 'w') as f:
        f.write(json.dumps(json_data))

    with open(max_file, 'r') as jsonFile:
        payload = json.load(jsonFile)

    # Act: convert dict to json by json.dumps() for body data and send POST request.

    response = requests.post(api_endpoints.triggerUpdateFirmware_url, headers=headers, data=json.dumps(payload))
    # Parse HTTP response body to json format
    response_body = response.json()
    saveAPIrespIntoFile("triggerFirmwareUpdate_" + model, response.text, "OTA")
    # print(response_body)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(14000):
        if response_body["responseData"]["message"] == "success" or response_body["responseData"]["message"] == "Success":
            scheduleId = str(response_body["responseData"]["scheduleId"])
            testResult(self, "passed", "Firmware should be scheduled successfully and campaign should be started ",
                                  "Firmware scheduled successfully OR Campaign is started ")

    elif response_body["responseCode"] != str(14000):
        #print(response_body["responseData"]["message"])
        testResult(self, "failed", "Firmware should be scheduled successfully and campaign should be started ",
                              "Firmware is not scheduled successfully OR Campaign is not started. "  + " Reason for failure is " + response_body["responseData"]["message"])

    else:
        print("Something went wrong")
    return scheduleId


def listPackageSchedules(self, scheduleId, onboarding_Type):
    time.sleep(30)
    refId = ''
    s = 0
    headers = apiHeader_sota(self)
    model = getModel(self, "sota", onboarding_Type)

    response = requests.get(api_endpoints.listSotaUpdates_url, headers=headers)

    # Parse HTTP response body to json format
    response_body = response.json()

    saveAPIrespIntoFile("listPackageSchedules_" + model, response.text, "OTA")
    # print(response_body)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == "Success" or response_body["responseCode"] == str(15000):
        for i in range(5):
            modelName = response_body["responseData"]["dataList"][i]['model']
            scheduleId1 = response_body["responseData"]["dataList"][i]['scheduleId']
            if modelName == model and scheduleId == str(scheduleId1):
                s = int(i)

        modelName = response_body["responseData"]["dataList"][int(s)]['model']
        status = response_body["responseData"]["dataList"][int(s)]['status']
        offered = response_body["responseData"]["dataList"][int(s)]['offered']
        accepted = response_body["responseData"]["dataList"][int(s)]['accepted']
        complete = response_body["responseData"]["dataList"][int(s)]['complete']
        scriptName = response_body["responseData"]["dataList"][int(s)]['scriptName']
        scheduleId1 = response_body["responseData"]["dataList"][int(s)]['scheduleId']

        if modelName == model and scheduleId == str(scheduleId1):
            if status == "SUCCESS":
                testResult(self, "passed",
                                      "Package schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> SOTA Updates",
                                      scriptName +
                                      " - Package schedule/campaign is listed with SUCCESS status on SMP UI-> Updates -> OTA -> SOTA Updates")

            elif status == "FAILURE":
                testResult(self, "failed",
                                      "Package schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> SOTA Updates",
                                      scriptName +
                                      " - Package schedule/campaign is listed with FAILURE status on SMP UI-> Updates -> OTA -> SOTA Updates")

            elif status == "ARCHIVE":
                testResult(self, "failed",
                                      "Package schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> SOTA Updates",
                                      scriptName +
                                      " - Package schedule/campaign is listed with ARCHIVE status on SMP UI-> Updates -> OTA -> SOTA Updates")

        elif modelName != model and scheduleId != str(scheduleId1):
            testResult(self, "failed",
                                  "Package schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> SOTA Updates",
                                  "Package schedule/campaign is not listed on first row or on SMP UI-> Updates -> OTA -> SOTA Updates")

    elif response_body["responseCode"] != "Success" or response_body["responseCode"] != str(15000):
        testResult(self, "failed",
                              "Package schedule/campaign should be listed with SUCCESS status on SMP UI-> Updates -> OTA -> SOTA Updates",
                              "Package schedule/campaign list is not displayed on SMP UI-> Updates -> OTA -> SOTA Updates")

    else:
        print("Something went wrong")

    return status, offered, accepted, complete


def listPackageScheduleStatus(self, onboarding_Type):
    time.sleep(30)
    refId = ''
    headers = apiHeader_sota(self)
    model = getModel(self, "sota", onboarding_Type)
    vin = getVIN(self, "sota", onboarding_Type)
    scheduleId = read_scheduleId(self, "sota")
    payload = {"vins": [vin]}

    listPackageUpdates_scheduleStatus = api_endpoints.listPackageUpdates_scheduleStatus_url + scheduleId + api_endpoints.urlPart

    response = requests.post(listPackageUpdates_scheduleStatus, headers=headers, data=json.dumps(payload))

    # Parse HTTP response body to json format
    response_body = response.json()

    saveAPIrespIntoFile("listPackageScheduleStatus_" + model, response.text, "OTA")
    # print(response_body)

    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(15000):

        vinNo = response_body["responseData"]["dataList"][0]['vin']
        status = response_body["responseData"]["dataList"][0]['status']
        appName = response_body["responseData"]["dataList"][0]['appName']

        # print(vin, vinNo)

        if vin == vinNo:
            #print('\n')
            print("Package update schedule-status is listed with " + status + " status on SMP UI")

    return status, appName

def appCheck(self, file_name, appname):
    # entering try block
    try:
        appName = ''
        # opening and reading the file
        file_read = open(file_name, "r")

        # reading file content line by line.
        lines = file_read.readlines()

        new_list = []
        idx = 0

        # looping through each line in the file
        for line in lines:

            # if line have the input string, get the index
            # of that line and put the
            # line into newly created list
            if appname in line:
                new_list.insert(idx, line)
                idx += 1

        # closing file after reading
        file_read.close()

        # if length of new list is 0 that means
        # the input string doesn't
        # found in the text file
        if len(new_list) == 0:
            #print("\n\"" + appname + "\" is not found in \"" + file_name + "\"!")
            appName =''
        else:

            # displaying the lines
            # containing given string
            lineLen = len(new_list)
            #print("\n**** Lines containing \"" + appname + "\" ****\n")
            for i in range(lineLen):
                if appname in new_list[i]:
                    appName = new_list[i]
                    break
                else:
                    appName =''
    # entering except block
    # if input file doesn't exist
    except FileNotFoundError:
        print("\nThe file doesn't exist!")
    except:
        print("Something went wrong!")
    return appName


def replaceLineWithText(self, filename, linenumb, replacedtext):
    with open(filename, 'r') as givenfilecontent:
        filelines = givenfilecontent.readlines()
        filelines[linenumb - 1] = replacedtext
    with open(filename, 'w') as givenfilecontent:
        givenfilecontent.writelines(filelines)
    print('The given linenumber = ', linenumb,' is replaced with {', replacedtext, '}')


def stabilityCheck_SOTA_IVI(self):

    sota_endpoint = "/sota-service/v1.0/schedule"
    baseUrl = testData("StabilityCheck", 2, 2)
    vin = testData("StabilityCheck", 3, 2)
    model = testData("StabilityCheck", 4, 2)
    scriptId = testData("StabilityCheck", 5, 2)
    command1 ="INSTALL"
    text_file = payloadPath + r'otaHeaders_sota.txt'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file, 'r') as jsonFile:
        headers = jsonFile.read()
    headers = parsed = json.loads(headers)
    startDate = int(datetime.now(tz=timezone.utc).timestamp()) * 1000
    print("\nStart Date : ", startDate)
    endDate = int(datetime.now(tz=timezone.utc).timestamp()) * 1000 + 100000000
    print("End Date: ", endDate)
    text_file = C2CtestData_jsonPath + r'OTA_Payload\triggerSOTAUpdatePayload.json'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        json_data = json.load(f)
        json_data["vins"][0] = vin
        json_data["scriptId"] = scriptId
        json_data["period"]["startDate"] = startDate
        json_data["period"]["endDate"] = endDate

    with open(max_file, 'w') as f:
        f.write(json.dumps(json_data))

    with open(max_file, 'r') as jsonFile:
        payload = json.load(jsonFile)
        # print(payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    triggerSOTAUpdatePackage_url = baseUrl + sota_endpoint

    response = requests.post(triggerSOTAUpdatePackage_url, headers=headers, data=json.dumps(payload))
    # Parse HTTP response body to json format
    response_body = response.json()
    saveAPIrespIntoFile("stability_triggerSotaUpdate_" + model + "_" + command1, response.text, "OTA")
    # print(response_body)
    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(15000):
        if response_body["responseData"]["message"] == "success" or response_body["responseData"][
            "message"] == "Success":
            scheduleId = str(response_body["responseData"]["scheduleId"])
            testResult(self, "passed",
                       "SOTA update should be scheduled successfully and campaign should be started ",
                       "SOTA update scheduled successfully and campaign is started ")

    elif response_body["responseCode"] != str(15000):
        # print(response_body["responseData"]["message"])
        testResult(self, "failed", "SOTA update should be scheduled successfully and campaign should be started ",
                   "SOTA update is not scheduled successfully OR Campaign is not started. " + " Reason for failure is : " +
                   response_body["responseData"]["message"])

    else:
        print("Something went wrong")

def stabilityCheck_FOTA_IVI(self):
    fota_endpoint = "/ota-services/v2/script"
    baseUrl = testData("StabilityCheck", 2, 3)
    vin = testData("StabilityCheck", 3, 3)
    model = testData("StabilityCheck", 4, 3)
    scriptId = testData("StabilityCheck", 5, 3)
    text_file = payloadPath + r'otaHeaders_fota.txt'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file, 'r') as jsonFile:
        headers = jsonFile.read()
    headers = parsed = json.loads(headers)
    startDate = int(datetime.now(tz=timezone.utc).timestamp()) * 1000
    print("\nStart Date : ", startDate)
    endDate = int(datetime.now(tz=timezone.utc).timestamp()) * 1000 + 100000000
    print("End Date: ", endDate)
    text_file = C2CtestData_jsonPath + r'OTA_Payload\triggerFirmwareUpdatePayload.json'
    files = glob.glob(text_file)
    max_file = max(files, key=os.path.getctime)
    with open(max_file) as f:
        json_data = json.load(f)
        json_data["vins"][0] = vin
        json_data["scriptid"] = scriptId
        json_data["period"]["startDate"] = startDate
        json_data["period"]["endDate"] = endDate

    with open(max_file, 'w') as f:
        f.write(json.dumps(json_data))

    with open(max_file, 'r') as jsonFile:
        payload = json.load(jsonFile)
        # print(payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    triggerSOTAUpdatePackage_url = baseUrl + fota_endpoint

    response = requests.post(triggerSOTAUpdatePackage_url, headers=headers, data=json.dumps(payload))
    # Parse HTTP response body to json format
    response_body = response.json()
    saveAPIrespIntoFile("stability_triggerFirmwareUpdate_" + model, response.text, "OTA")
    # print(response_body)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    if response_body["responseCode"] == str(14000):
        if response_body["responseData"]["message"] == "success" or response_body["responseData"][
            "message"] == "Success":
            scheduleId = str(response_body["responseData"]["scheduleId"])
            testResult(self, "passed", "Firmware should be scheduled successfully and campaign should started ",
                       "Firmware scheduled successfully OR Campaign is started ")

    elif response_body["responseCode"] != str(14000):
        # print(response_body["responseData"]["message"])
        testResult(self, "failed", "Firmware should be scheduled successfully and campaign should started ",
                   "Firmware is not scheduled successfully OR Campaign is not started  " + " Reason for failure is : " +
                   response_body["responseData"]["message"])
    else:
        print("Something went wrong")



