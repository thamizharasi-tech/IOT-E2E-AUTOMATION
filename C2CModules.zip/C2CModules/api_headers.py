class api_headers:
    # Common headers:
    headersr_reg_post = {
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'content-type': 'application/json',
        'x-requestor': 'aa',
        'api-key': 'SXdma2whU1RlaHZKOVAxRQ'
    }
    headers_reg_get = {
        'x-requestor': 'aa',
        'api-key': 'SXdma2whU1RlaHZKOVAxRQ',
        'Accept': '*/*'
    }
    headers_lmsq = {
        'api-key': 'bG1zUUFQSUAxMjM',
        'x-requestor': 'aa',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'content-type': 'application/json'
    }
    headers_lmsc = {
        'api-key': 'bG1zLWMtYXBp',
        'x-requestor': 'aa',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'content-type': 'application/json'
    }
    headers_telemetry = {
        'x-requestor': 'aa',
        'api-key': 'SXdma2whU1RlaHZKOVAxRQ',
        'Accept': '*/*'
    }
    headers_ota_db = {
        'api-key': 'b3RhLWRiNGFwaSo',
        'x-requestor': 'aa',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'Content-Type': 'application/json',
    }
    headers_geofence = {
        'api-key': 'SXdma2whU1RlaHZKOVAxRQ',
        'x-requestor': 'aa',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'Content-Type': 'application/json',
    }
    headers_carota = {
        'api-key': 'b3RhLXNlcnZpY2UtYXBp',
        'x-requestor': 'aa',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'Content-Type': 'application/json',
        'x-token': '5e79819ef502b40022fe8b52',
        'x-checksum': '6dd90243832408ebfb040d67e95468cb',
        'x-tm': '1234567890',
    }
    headers_smp_api = {
        'accept-type': 'application/json',
        'content-type': 'application/json',
    }
    headers_chipset_api = {
        'accept-type': 'application/json',
        'content-type': 'application/json',
        'api-key': 'Y2hpcHNldC1hcGk',
        'x-requestor': 'xyz'
    }
    headers_notification = {
        'accept-type': 'application/json',
        'content-type': 'application/json'
    }
    headers_resilience = {
        'accept-type': 'application/json',
        'content-type': 'application/json',
        'api-key': 'cmVzaWxpZW5jZS1zZXJ2aWNlLWFwaQ',
        'x-requestor': 'xyz'
    }
    headers_command_cntrl = {
        'accept-type': 'application/json',
        'content-type': 'application/json',
        'api-key': 'Y29tbWFuZF9jb250cm9sX2FwaQ',
        'x-requestor': 'xyz'
    }
    headers_command_cntrl_resp = {
        'accept': '*/*',
        'api-key': 'Y29tbWFuZF9jb250cm9sX2FwaQ',
        'x-requestor': 'test'
    }
    headers_route_config = {
        'accept-type': 'application/json',
        'content-type': 'application/json',
        'api-key': 'cm91dGVBcGlAMTIz',
        'x-requestor': 'xyz'
    }
    headers_veh_details = {
        'accept-type': 'application/json',
        'content-type': 'application/json'
    }
    headers_veh_lifecycle = {
        'api-key': 'ZGV2aWNlLWFwaQ',
        'x-requestor': 'aa',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'content-type': 'application/json'
    }
    headers1_veh_lifecycle = {
        'api-key': 'dmVoaWNsZS1hcGk',
        'x-requestor': 'aa',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'content-type': 'application/json'
    }
    headers2_veh_lifecycle = {
        'api-key': 'ZGV2aWNlLWdsb2JhbC1hcGk',
        'x-requestor': 'aa',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'content-type': 'application/json'
    }
    headers_partition = {
        'api-key': 'cGFydGl0aW9uQDQ1Ng==',
        'x-requestor': 'aa',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'content-type': 'application/json'
    }
    headers_get_token = {
        'accept': '*/*',
        'api-key': 'Y29nbml0by10b2tlbi1hcGk',
        'x-requestor': 'ssreejan@qti.qualcomm.com',
        'Content-Type': 'application/json'
    }
    headers_sota_trigger = {
        'accept': '*/*',
        'api-key': 'c290YWFwaUAxMjM',
        'x-requestor': 'abc',
        'Content-Type': 'application/json'
    }
    headers_encrypt_gbl = {
        'Authorization': 'Basic cWMtcWFnYmwtY29uZmlnOnFbJFFhZ2IxWzBO',
        'Content-Type': 'text/plain',
        'Cookie': 'JSESSIONID=384EBAA6831B15D9C89F4208FCECA6C1'
    }
    headers_encrypt_reg = {
        'Authorization': 'Basic cWMtcWFyZWctY29uZmlnOnFbJFFhcmduMVswTg==',
        'Content-Type': 'text/plain',
        'Cookie': 'JSESSIONID=384EBAA6831B15D9C89F4208FCECA6C1'
    }
    headers_decrypt_reg = {
        'Authorization': 'Basic cWMtcWFyZWctY29uZmlnOnFbJFFhcmduMVswTg==',
        'Content-Type': 'application/json',
        'Cookie': 'JSESSIONID=384EBAA6831B15D9C89F4208FCECA6C1'
    }
    headers_decrypt_gbl = {
        'Authorization': 'Basic cWMtcWFnYmwtY29uZmlnOnFbJFFhZ2IxWzBO',
        'Content-Type': 'application/json',
        'Cookie': 'JSESSIONID=384EBAA6831B15D9C89F4208FCECA6C1'
    }
    headers_group_api = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    headers_command_service = {
        'accept': '*/*',
        'x-requestor': 'abc',
        'api-key': 'Y2NzZXJ2aWNlQDc4OQ',
        'Content-Type': 'application/json'
    }
    headers_telemetry_curr = {
        'accept': '*/*',
        'x-requestor': 'abc',
        'api-key': 'dGVsZW1ldHJ5LWN1cnJAMTIz'
    }
    headers_telemetry_location = {
        'accept': '*/*',
        'x-requestor': 'abc',
        'api-key': 'dGVsZW1ldHJ5LWdlb2ZlbmNlQDc4OQ',
        'Content-Type': 'application/json'
    }
    headers_veh_sensor_data = {
        'accept': '*/*',
        'x-requestor': 'abc',
        'api-key': 'Y29tbWFuZF9jb250cm9sX2FwaQ'
    }
    headers_command_context_controller = {

        'api-key': 'Y29tbWFuZF9jb250cm9sX2FwaQ',
        'x-requestor': 'xyz',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'content-type': 'application/json'
    }
    headers_update_details_t_telemetry_geofence_vehicle = {
        'api-key': 'dGVsZW1ldHJ5LWdlb2ZlbmNlQDc4OQ',
        'x-requestor': 'qa',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'content-type': 'application/json'
    }
    headers_telemetry_history = {

        'api-key': 'dGVsZW1ldHJ5LXBlcnNpc3RANDU2',
        'x-requestor': 'abc',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'content-type': 'application/json'
    }
    headers_connectivity_api = {

        'api-key': 'SXdma2whU1RlaHZKOVAxRQ',
        'x-requestor': 'abc',
        'personaid': 'testing',
        'Accept': '*/*',
        'x-application': 'application_id',
        'external-trace-id': '',
        'content-type': 'application/json'
    }

    headers_package_services = {
        'accept': '*/*',
        'api-key': 'cGFja2FnZUAxMjM',
        'x-requestor': 'abc',
        'Content-Type': 'application/json'
    }

    tele_headers = {
        'accept': '*/*',
        'x-requestor': 'test',
        'api-key': 'dGVsZW1ldHJ5LWN1cnJAMTIz'
    }

    metadata_headers = {
        'accept': '*/*',
        'api-key': 'dmVoaWNsZS1hcGk',
        'x-requestor': 'abc',
        'Content-Type': 'application/json'
    }

    trip_headers = {
        'accept': '*/*',
        'x-requestor': 'abc',
        'api-key': 'dHJpcC1zZXJ2aWNl'
    }
    latestTrip_headers = {
          'accept': '*/*',
          'x-requestor': 'abc',
          'api-key': 'dHJpcC1zZXJ2aWNl',
          'Content-Type': 'application/json'
    }
    notification_headers = {
        'accept': '*/*',
        'x-requestor': 'test',
        'api-key': 'bm90aWZpY2F0aW9uLXNlcnZpY2U',
        'Content-Type': 'application/json'
    }
    fileupload_headers = {
        'api-key': 'ZmlsZS11cGxvYWRAMTIz',
        'x-requestor': 'admin'
    }