import datetime
import glob
import json
import os
import random
import shutil
import time

import requests

from C2CModules.e2e_c2c_modules import saveAPIrespIntoFile, apiHeader
from C2CModules.e2e_testData import C2CtestReport_APIresponsesPath, C2CtestData_jsonPath, C2CtestReport_c2cLogsPath, \
    folderPath, C2CtestReport_DeviceOnbrdng_backupPath, C2CtestReport_SKUupdateByGroupPath, \
    C2CtestReport_FeatureUpdateByGroupPath, C2CtestReport_SKUupdateByVINPath, C2CtestReport_otaPath, deviceIdFlag, \
    reqDeviceId_ivi, deviceType_IVI, deviceType_TCU, onboardingTypeFlag, ex_singleDeviceOnboarding_TCU, \
    ex_singleDeviceOnboarding_IVI, ex_comboDeviceOnboarding_TCUVT_fusion, ex_comboDeviceOnboarding_TCUIVI, \
    ex_comboDeviceOnboarding_TCUVT, ex_comboDeviceOnboarding_TCUIVIVT, ex_comboDeviceOnboarding_TCUVTIVI_fusion, \
    tcu_files

from C2CModules.api_endpoints import api_endpoints

def search_text_in_file(self, filepath, message_type1, message_type2):
    try:
        max_file = filepath
        # files = glob.glob(LogPath)
        # max_file = max(files, key=os.path.getctime)
        # Safely read the input filename using 'with'
        freq = 0
        with open(max_file) as f:
            s = f.read()
            if message_type2 not in s:
                print(f'"{message_type2}" not found in {max_file}.'.format(**locals()))
                freq = 0
                line = "Error"
                return line, freq
        # Safely write the changed content, if found in the file

        with open(max_file, 'r') as f:
            for l_no, line in enumerate(f):
                if message_type1 in line and message_type2 in line:
                    print(f'"{message_type2}" found in {max_file}.'.format(**locals()))
                    freq = int(freq) + 1
                    #print(" => Line No : ", l_no)
                    #print(" => Line data : ", line)
                    return line, freq
    except:
        freq = "log file is empty or contain undefined chars that cannot be decoded"
        line = "Error"
    print(freq, line)
    return line, freq


def verify_text_line_by_line_in_file(self, filepath, text):
    try:
        # READ FILE
        filename = glob.glob(filepath)
        filename = max(filename, key=os.path.getctime)
        df = open(filename)
        # read file
        read = df.read()
        # return cursor to the beginning of the file.
        df.seek(0)
        read
        # create empty list
        arr = []
        # count number of lines in the file
        line = 1
        for word in read:
            if word == '\n':
                line += 1
        # print("Number of lines in file is: ", line)
        for i in range(line):
            # readline() method, reads one line at a time
            arr.append(df.readline())
        for i in range(len(arr)):
            if text in arr[i]:
                i + 1
                linenumb = i
                break
        # print(linenumb)
        with open(filename, 'r') as givenfilecontent:
            filelines = givenfilecontent.readlines()
            # replacedtext = replacedtext
            # filelines[linenumb] = replacedtext + '\n'
            # print(filelines)
        print(f' => The {text} contain at linenumber = ', linenumb, ' in ',
              filename)
    except FileNotFoundError:
        print(f"Sorry, the {filename} conf file does not exist or incorrect file path/name")
    except:
        print(f"Error while updating {filename} conf files")


def verify_message_in_log(self, message1, message2):
    filepath = C2CtestReport_c2cLogsPath + 'c2clogs.txt'
    ls = search_text_in_file(self, filepath, message1, message2)
    #ls = verify_text_line_by_line_in_file(self, filepath, message)
    return ls

def save_api_resp_into_file(filename, response):
    file = open(C2CtestReport_APIresponsesPath + filename + "_resp" + ".json", "w")
    file.write(response)
    file.close()


# ============================================================
# POST request API
# ============================================================

def device_reg_post_request(self, device_type):
    # Arrange: Test data (url,header and payload) for POST request
    url = api_endpoints.device_reg_post_ep
    headers = apiHeader(self)
    print('Registration URL => ', url)
    time.sleep(5)
    random_id = ' '.join([str(random.randint(10, 9999)).zfill(7) for _ in range(1)])

    if device_type == deviceType_TCU:

        if deviceIdFlag == "Yes":
            deviceId = reqDeviceId_ivi
        else:
            deviceId = "QA_TEST_TCU_" + random_id
        filename = "\TCU_deviceRegPostRes"

    elif device_type == deviceType_IVI:

        if deviceIdFlag == "Yes":
            deviceId = reqDeviceId_ivi
        else:
            deviceId = "QA_TEST_IVI_" + random_id
        filename = "\IVI_deviceRegPostRes"

    payload = [
        {
            "device_id": deviceId,
            "device_type": device_type,
            "attestationMechanism": "X.509"
        }
    ]

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(url, headers=headers, data=json.dumps(payload))

    # Parse HTTP response body to json format
    response_body = response.json()
    # print(response_body)

    # Save response full body as text in a file
    saveAPIrespIntoFile(filename, response.text, "")

    # Assert: Validate response status code and body contents
    if response.status_code == 200 and response_body["responseCode"] == str(1200):
        # print(f"Status Code is 200 & response code is 1200")
        assert True
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)
        assert (response_body["responseCode"] == str(1200))
    else:
        print("Status code is not 200. Rather found : " + str(response.status_code))
        assert False

    if response_body["responseMessage"] == "SUCCESS":
        # print(f"Response Message is SUCCESS")
        # assert True
        assert (response_body["responseMessage"] == "SUCCESS")
    else:
        print(str(response_body["responseMessage"]))
        # assert False
    return response_body

# ============================================================
# GET request API
# ============================================================

def get_request_api(url, headers, filename):
    # Arrange: Test data (url,header) for GET request
    url = url
    print('URL => ', url)
    time.sleep(5)

    # Act: Get device details
    response = requests.get(url, headers=headers)

    # Parse HTTP response body to json format
    response_body = response.json()
    # print(response_body)

    # Save response full body as text in a file
    saveAPIrespIntoFile(filename, response.text, "")

    if response_body["responseMessage"] == "Success":
        # assert (response_body["responseCode"] == str(1200))
        # print(f"Response Message is Success")
        assert True

    # Assert: Validate response status code and body content
    if response.status_code == 200:
        # print(f"Status Code is 200 & response code is 1200")
        assert True
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    else:
        print("Status code is not 200. Rather found : " + str(response.status_code))
        assert False

    return response_body
