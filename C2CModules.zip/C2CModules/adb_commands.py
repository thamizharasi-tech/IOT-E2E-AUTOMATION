
# copy default file commands:
drimaes_default_conf_path = r'C:\Car2Cloud_E2ETesting\C2CtestData\usr\local\drimaes_defaultConfNew\*'
copy_c2c_vehicleJson_cmd = r'drimaes_defaultConfNew\c2c_vehicle.json'

# sp_validation commands
drimaes_fetch_dmConf_cmnd = r'pull /mnt/vendor/persist/data/c2c/dm.conf'
drimaes_fetch_car2cloudConf_cmnd = r'/mnt/vendor/persist/data/c2c/car2cloud.conf'
drimaes_fetch_side_loadedConf_cmnd = r'/mnt/vendor/persist/data/c2c/side_loaded.conf'
drimaes_fetch_side_loadedConf_cmnd = r'/mnt/vendor/persist/data/c2c/side_loaded.conf'
drimaes_fetch_c2c_defaultConf_cmnd = r'/mnt/vendor/persist/data/c2c/c2c_default.conf'


# Commands adb commands
root_cmnd = "root"
reboot_cmnd = "reboot"
remount_cmnd = "remount"
read_uname_cmnd = "shell uname -a"
ping_cmnd = "shell ping -c 3 8.8.8.8"
curl_cmnd = "shell curl www.google.com"
enableVerity_cmd = r'shell enable-verity'

# drimaes image flash fastboot commands
path = ''
fastboot_cmd = r'reboot bootloader'
verify_fastboot_devices_cmd = r'fastboot devices'
fastboot_flash_abl_cmd = r'fastboot flash abl' + path + '\\' + 'abl.elf'
fastboot_boot_a_cmd = r'fastboot flash boot_a' + path + '\\' + 'boot.img'
fastboot_flash_dtbo = r'fastboot flash dtbo' + path + '\\' + 'dtbo.img'
fastboot_flash_metadata = r'fastboot flash metadata' + path + '\\' + 'metadata.img'
fastboot_flash_persist = r'fastboot flash persist' + path + '\\' + 'persist.img'
fastboot_flash_super = r'ffastboot flash super' + path + '\\' + 'super.img'
fastboot_flash_userdata = r'fastboot flash userdata' + path + '\\' + 'userdata.img'
fastboot_flash_vbmeta_a = r'fastboot flash vbmeta_a' + path + '\\' + 'vbmeta.img'
fastboot_flash_vbmeta_system_a = r'fastboot flash vbmeta_system_a' + path + '\\' + 'vbmeta_system.img'
fastboot_flash_vendor_boot = r'fastboot flash vendor_boot' + path + '\\' + 'vendor_boot.img'
fastboot_reboot_cmd = r'fastboot reboot'


# IVI device adb commands
get_current_slot_cmnd= "shell bootctl get-current-slot"
list_packages_cmnd = "shell pm list packages"

# Drimaes IVI (6155):
drimaes_read_firmware_ver_cmnd = "shell cat /vendor/firmware_mnt/verinfo/ver_info.txt"
drimaes_fetch_firmware_ver_cmd = "pull /vendor/firmware_mnt/verinfo/ver_info.txt"


drimaes_create_new_folder_c2c_cmnd = "shell mkdir -p /data/vendor/c2c"
drimaes_create_new_folder_certs_cmnd = "shell mkdir -p /data/usr/local/certs"



#C2C_adbCommands
#rebootdevice
reboot_device = r'adb -s %1 reboot'

#createFolder
new = r'adb -s %1 reboot'
reboot_device = r'adb -s %1 reboot'
