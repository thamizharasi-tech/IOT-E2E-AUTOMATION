#from conftest import api_setup

#base = api_setup()
#BaseUrl_gbl = str(base[0])
#BaseUrl_reg = str(base[1])
from C2CModules.e2e_c2c_modules import testData
from C2CModules.e2e_testData import BaseUrl_gbl, BaseUrl_reg, firm_reg, sota_reg


class api_endpoints:

    deviceRegistration_url = BaseUrl_gbl + "/device-request-processor/v1/device/registration"
    getOverallCount_url = BaseUrl_gbl + r'/device-registration-service/v1/registration/requests/'
    getDeviceDetails_url = BaseUrl_gbl + r'/device-registration-service/v1/registration/'

    licensecleanup_url = BaseUrl_reg + r'/licensecleanup/deleteLicense?vin='

    # Get onboarded VIN / SKU upadte / Feature details/list

    getVINdetails_url = BaseUrl_reg + "/smp-server/vin/vehiclesearch"
    getSKUupdateList_url = BaseUrl_reg + "/smp-server/sku/listUpdateSKU"
    getFeatureUpdateList_url = BaseUrl_reg + "/smp-server/feature/getUpdateFeatures"

    # SKU Update By VIN Urls
    VinGetuPvChipsetSpIdlist_url = BaseUrl_reg + "/smp-server/vin/getSystemProgramChipsetSpDataByVin"
    VinGetSKUIdlist_url = BaseUrl_reg + "/smp-server/sku/getSkusByPvChipsetSpAndVin"
    VinUpdateSKU_url = BaseUrl_reg + "/smp-server/sku/updateSKUByVin"

    # Create new group url
    createGroup_url = BaseUrl_reg + "/smp-server/group/createGroup"

    # SKU Update By Group Urls
    GrpGetuPvChipsetSpIdlist_url = BaseUrl_reg + "/smp-server/group/getSystemProgramChipsetSpDataByVinGroup"
    GrpGetSKUIdlist_url = BaseUrl_reg + "/smp-server/sku/getSkusByPvChipsetSp"
    GrpUpdateSKU_url = BaseUrl_reg + "/smp-server/sku/updateSKU"

    # Feature Update Urls
    getFilterValuesbyGroup_url = BaseUrl_reg + "/smp-server/group/getSystemProgramChipsetSpDataByVinGroup"
    getFeaturesforselectedFilters = BaseUrl_reg + "/smp-server/feature/getFeaturesByPvChipsetSp"
    sendUpdateFeatureRequest = BaseUrl_reg + "/smp-server/feature/updateFeature"

    # Device registration
    device_reg_post_ep = BaseUrl_gbl + '/device-request-processor/v1/device/registration'
    get_overallCount_ep = BaseUrl_reg + '/device-registration-service/v1/registration/requests/{requestId}'
    get_deviceDetails_ep = BaseUrl_reg + '/device-registration-service/v1/registration/{requestId}/devices'

    # Telemetry, Command & Control & Notification
    telemetry_curr_url = BaseUrl_reg + '/telemetry-curr/v1.0/current-value/{sysId}?eventType={eventTypeValue}'
    meta_data_url = BaseUrl_reg + "/vehicle/v3/{vin}"
    trip_summary_url = BaseUrl_reg + "/asset-management/v1/trip-info?pageNo=0&pageSize=10&tripId={tripIdValue}"
    trip_waypoint_url = BaseUrl_reg + "/asset-management/v1/trip-waypoints?pageNo=0&pageSize=5&systemId={systemIdValue}&vin={vinValue}&startDate={startDateValue}&endDate={EndDateValue}"
    trip_waypoint_tripId_url = BaseUrl_reg + "/asset-management/v1/trip/{tripIdValue}/waypoints"
    commandCtrl_initiate_post_url = BaseUrl_reg + "/command-request/v1.0/command"
    commandCtrl_get_resp_url = BaseUrl_reg + "/command-request/v1.0/commandtracking/{requestId}"
    latest_trip_details_url = BaseUrl_reg + '/asset-management/v1/latest-trip-details'

    notification_url = BaseUrl_reg + '/notify/v1/notification'
    fileUpload_url = BaseUrl_reg + '/file-upload/v2/upload-file'

    # OTA Urls

    # Presigned  Urls
    presignedFirmware_url = firm_reg + "/ota-services/v2/presigned-url"
    presignedSota_url = sota_reg + "/sota-service/v1.0/presigned-url"

    # Upload Package Urls
    uploadFirmware_url = firm_reg + "/ota-services/v2/firmware"
    uploadPackage_url = sota_reg + "/sota-service/v1.0/upload-package"

    # List Packages Urls
    listFirmware_url = firm_reg + "/ota-services/v2/firmwares?pageNumber=1&pageSize=10"
    listPackage_url = sota_reg + "/sota-service/v1.0/list-package?pageNumber=1&pageSize=10"

    # Create Script Urls
    createFOTAscript_url = firm_reg + "/ota-services/v2/script"
    createSOTAscript_url = sota_reg + "/sota-service/v1.0/script"

    # List Script Urls
    listFirmwareScript_url = firm_reg + "/ota-services/v2/scripts?pageNumber=1&pageSize=10"
    listSotaScript_url = sota_reg + "/sota-service/v1.0/list-scripts?pageNumber=1&pageSize=10"

    # Trigger Urls
    triggerUpdateFirmware_url = firm_reg + "/ota-services/v2/schedule"
    triggerUpdatePackage_url = sota_reg + "/sota-service/v1.0/schedule"

    # List Script Urls
    listFirmwareUpdates_url = firm_reg + "/ota-services/v2/schedules?pageNumber=1&pageSize=10"
    listSotaUpdate_url = sota_reg + "/sota-service/v1.0/list-schedules?pageNumber=1&pageSize=10"
    listSotaUpdates_url = sota_reg + "/sota-service/v1.0/list-schedules?status=success,failure&pageNumber=1&pageSize=10"

    listPackageUpdates_scheduleStatus_url = sota_reg + "/sota-service/v1.0/list-schedule-vin/"
    urlPart = "?pageNumber=1&pageSize=10"


    lmsq = BaseUrl_reg + "/lmsq"
    lmsc = BaseUrl_reg + "/lmsc"
    telemetry_url = BaseUrl_reg + "/telemetry-persistence-service/v1/things/"
    ota_db_url = BaseUrl_reg + "/ota-db-api/v1.0/"
    geo_fence_url = BaseUrl_reg + "/navigation-service/v1/things/geofences/"
    carota = BaseUrl_reg + "/ota-services/"
    ota = BaseUrl_reg + "/smp-server/"
    smp_api = BaseUrl_reg + "/smp-server/chipset/onboard"
    chipset_api = BaseUrl_reg + "/chipsetapi/chipset/"
    notification = BaseUrl_reg + "/smp-server/notification/v1.0/"
    resilience_reg = BaseUrl_reg + "/resilience-service/v1.0/config/"
    resilience_gbl = BaseUrl_reg + "/resilience-service/v1.0/config/"
    command_control = BaseUrl_reg + "/command-request/v1.0/"
    # Route_config
    Message_type_url = BaseUrl_reg + "/routeconfig/v1.0/messagetype"
    Message_route_url = BaseUrl_reg + "/routeconfig/v1.0/messageroute"
    Application_url = BaseUrl_reg + "/routeconfig/v1.0/application"
    Application_route_url = BaseUrl_reg + "/routeconfig/v1.0/applicationroute"
    get_vehicle_details = BaseUrl_reg + "/smp-server/vin/vehiclesearch"
    veh_lifecycle_url = BaseUrl_reg + "/device-regional/v1.0"
    veh_lifecycle_url1 = BaseUrl_reg + "/vehicle/v1.0"
    veh_lifecycle_url2 = BaseUrl_gbl + "/device-global/v1.0"
    partition_service = BaseUrl_reg + "/partition-service/v1.0/"
    get_token = BaseUrl_gbl + "/cognito-token/c2c-auth/get-token"
    sota_trigger = BaseUrl_reg + "/sota-service/v1.0/"
    encrypt_decrypt_gbl = BaseUrl_gbl + "/configserver/"
    encrypt_decrypt_reg = BaseUrl_reg + "/configserver/"
    group_api = BaseUrl_reg + "/smp-server/group/v1.0/getVinListForSkuFeatureUpdate"
    command_service = BaseUrl_reg + "/command-service/v1.0/"
    telemetry_curr = BaseUrl_reg + "/telemetry-curr/v1.0/"
    telemetry_location = BaseUrl_reg + "/telemetry-location/v1/"
    veh_sensor_data = BaseUrl_reg + "/command-request/v1/"
    telemetry_history = BaseUrl_reg + "/telemetry-persist/v1/"
    connectivity_api = BaseUrl_reg + "/connectivity/"
    package_service_vehiclePackageAssignment = BaseUrl_gbl + "/package-service/v1/vehicle-package-assignment/details"
    package_service_get = BaseUrl_gbl + "/package-service/v1/vehicle-package-assignment/{systemId}"
    package_service_getPackageDetails = BaseUrl_gbl + "/package-service/v1/package-details/1"
    package_service_getPackageDetails_1 = BaseUrl_gbl + "/package-service/v1/package-details/packages?pageNumber=1&noOfRecordsInAPage=10"