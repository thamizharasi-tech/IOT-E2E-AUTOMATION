import pytest

from C2CModules.e2e_testData import deviceType_IVI, b2c_ivi_chipset
from C2CModules.notifications import notificationServiceController_subscribe, \
    notificationServiceController_details_by_systemId_Category, notificationServiceController_details_by_systemId, \
    notificationServiceController_unsubscribe
from C2CModules.primary_IVI_device_modules import get_SystemId, getVIN
from utils.XLUtils import read_api_data_from_excel

OnboardingType = deviceType = deviceType_IVI
chipsetType = b2c_ivi_chipset


class Test_NotificationServiceController:

    # Notification Service Control - Subscribe - Speed
    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_subscribe_speed(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController", "notificationServiceController_subscribe_speed")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])


            # Call subscribe reusable module
        response_body = notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName, destinationType)
        assert (response_body["message"] == "Successfully Subscribed")
        print("----------------------------------------------------------")

    # Notification Service Control - Subscribe - Geofence
    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_subscribe_geofence(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_subscribe_geofence")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Subscribed")
        print("----------------------------------------------------------")

    # Notification Service Control - Subscribe - SOS ON
    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_subscribe_sos_on(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_subscribe_sos_on")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Subscribed")
        print("----------------------------------------------------------")

    # Notification Service Control - Subscribe - SOS OFF
    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_subscribe_sos_off(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_subscribe_sos_off")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Subscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_subscribe_bms(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_subscribe_bms")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Subscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_subscribe_curfew(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_subscribe_curfew")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Subscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_subscribe_unauthorizedMovement(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_subscribe_unauthorizedMovement")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Subscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_subscribe_maintenance(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_subscribe_maintenance")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Subscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_subscribe_criticalBatteryTemp(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_subscribe_criticalBatteryTemp")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Subscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_subscribe_warningBatteryTemp(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_subscribe_warningBatteryTemp")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Subscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_subscribe_normalBatteryTemp(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_subscribe_normalBatteryTemp")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Subscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_details_by_systemId(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_details_by_systemId")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)

            # Call subscribe reusable module
        response_body = notificationServiceController_details_by_systemId(self, systemId)
        assert (response_body["message"] == "Successfully fetched the Subscribers Details")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_details_by_systemId_Category(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_details_by_systemId_Category")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            categoryName = str(dict1["categoryName"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            categoryName = 'SPEED NOTIFICATION'

            # Call subscribe reusable module
        response_body = notificationServiceController_details_by_systemId_Category(self, systemId,categoryName)
        if response_body["responseCode"] == str(1200) or response_body["responseCode"] == 1200:
            assert (response_body["responseMessage"] == "SUCCESS")
        else:
            print("response Code is not 1200. Rather found : " + str(response_body))
            assert False
        print("----------------------------------------------------------")

    # Notification Service Control - UnSubscribe - Speed
    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_unsubscribe_speed(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController", "notificationServiceController_unsubscribe_speed")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])


            # Call subscribe reusable module
        response_body = notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName, destinationType)
        assert (response_body["message"] == "Successfully Unsubscribed")
        print("----------------------------------------------------------")

    # Notification Service Control - UnSubscribe - Geofence
    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_unsubscribe_geofence(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_unsubscribe_geofence")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Unsubscribed")
        print("----------------------------------------------------------")

    # Notification Service Control - UnSubscribe - SOS ON
    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_unsubscribe_sos_on(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_unsubscribe_sos_on")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Unsubscribed")
        print("----------------------------------------------------------")

    # Notification Service Control - Subscribe - SOS OFF
    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_unsubscribe_sos_off(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_unsubscribe_sos_off")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Unsubscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_unsubscribe_bms(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_unsubscribe_bms")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Unsubscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_unsubscribe_curfew(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_unsubscribe_curfew")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Unsubscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_unsubscribe_unauthorizedMovement(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_unsubscribe_unauthorizedMovement")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Unsubscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_unsubscribe_maintenance(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_unsubscribe_maintenance")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Unsubscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_unsubscribe_criticalBatteryTemp(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_unsubscribe_criticalBatteryTemp")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Unsubscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_unsubscribe_warningBatteryTemp(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_unsubscribe_warningBatteryTemp")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Unsubscribed")
        print("----------------------------------------------------------")

    @pytest.mark.Smoke
    def test1_positive_notificationServiceController_unsubscribe_normalBatteryTemp(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Notification_ServiceController",
                                         "notificationServiceController_unsubscribe_normalBatteryTemp")
        print()
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            vin = str(dict1["vin"])
            endPoint = str(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            endPoint = int(dict1["endPoint"])
            categoryName = str(dict1["categoryName"])
            destinationType = str(dict1["destinationType"])

            # Call subscribe reusable module
        response_body = notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName,
                                                                destinationType)
        assert (response_body["message"] == "Successfully Unsubscribed")
        print("----------------------------------------------------------")
