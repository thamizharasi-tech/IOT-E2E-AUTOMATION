import json
import random

import pytest

from C2CModules.e2e_testData import deviceType_IVI, b2c_ivi_chipset
from C2CModules.geofence import Geofence_createGeofence, Geofence_updateGeofence, Geofence_deleteGeofence, \
    Geofence_getGeofences
from C2CModules.testResults import testResult
from utils.XLUtils import read_api_data_from_excel

OnboardingType = deviceType = deviceType_IVI
chipsetType = b2c_ivi_chipset


class Test_Geofence:

    # geofence_createGeofence
    @pytest.mark.Smoke
    def test1_positive_geofence_createGeofence(self):

        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Geofence", "Geofence_createGeofence")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")

            name = str(dict1["GeofenceName"])
            geometryType = str(dict1["geometryType"])
            radius = str(dict1["radius"])
            lat = str(dict1["coordinates-lat"])
            long = str(dict1["coordinates-long"])
            isActive = str(dict1["isActive"])
            tolerance = str(dict1["tolerance"])
            type = str(dict1["type"])
            poiFlag = str(dict1["poiFlag"])
            tag = str(dict1["tag"])

        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            msg_id = ' '.join([str(random.randint(10, 9999)).zfill(6) for _ in range(1)])
            name = 'Geofence' + str(msg_id)
            geometryType = "circle"
            radius = str(150)
            lat = str(28.61370736476138)
            long = str(77.22751858264235)
            isActive = 'True'
            tolerance = str(0)
            type = 'PERSONAL'
            poiFlag = 'False'
            tag = 'office'

        # Call api reusable module
        response = Geofence_createGeofence(self, name, geometryType, radius, long, lat, isActive, tolerance, type, poiFlag, tag, "valid")

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        # Validate response body
        if response_body["message"] == "Location Saved Successfully!":
            geoId = response_body["responseData"]["geoId"]
            #message = response_body["responseData"]["message"]
            print('Geofence Id : ', geoId)
            #print('Message : ', message)
            testResult(self, "passed", "New geofence should be created successfully",
                       "New geofence is created successfully ")
        elif response_body["message"] != "Location Saved Successfully!":
            # print(response_body["responseData"]["message"])
            testResult(self, "failed", "New geofence should be created successfully ",
                       "New geofence is not created " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            print("Something went wrong")

    print("----------------------------------------------------------")

    # geofence_createGeofence
    @pytest.mark.Smoke
    def test1_positive_geofence_updateGeofence(self):

        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Geofence", "Geofence_updateGeofence")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")

            name = str(dict1["GeofenceName"])
            geometryType = str(dict1["geometryType"])
            radius = str(dict1["radius"])
            lat = str(dict1["coordinates-lat"])
            long = str(dict1["coordinates-long"])
            isActive = str(dict1["isActive"])
            tolerance = str(dict1["tolerance"])
            type = str(dict1["type"])
            poiFlag = str(dict1["poiFlag"])
            tag = str(dict1["tag"])
            geoId = str(dict1["geoId"])
            if geoId == "NA":
                # Read geofence Id from Geofence_createGeofence api resp from Excel sheet
                dict1 = read_api_data_from_excel(self, "API_Data", "Geofence_createGeofence")
                api_resp = str(dict1["Actual API Response"])
                # print(api_resp)
                json_object = json.loads(api_resp)
                geoId = json_object["responseData"]["geoId"]
                print('Geofence Id : ', geoId)


        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            msg_id = ' '.join([str(random.randint(10, 9999)).zfill(6) for _ in range(1)])
            name = 'Geofence' + str(msg_id)
            geometryType = "circle"
            radius = 500
            lat = 28.61370736476138
            long = 77.22751858264235
            isActive = 'True'
            tolerance = 0
            type = 'PERSONAL'
            poiFlag = 'False'
            tag = 'home'

            # Read geofence Id from Geofence_createGeofence api resp from Excel sheet
            dict1 = read_api_data_from_excel(self, "API_Data", "Geofence_createGeofence")
            api_resp = str(dict1["Actual API Response"])
            # print(api_resp)
            json_object = json.loads(api_resp)
            geoId = json_object["responseData"]["geoId"]
            print('Geofence Id : ', geoId)


        # Call api reusable module
        response = Geofence_updateGeofence(self, geoId, name, geometryType, radius, long, lat, isActive, tolerance, type, poiFlag, tag, "valid")

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        # Validate response body
        if response_body["message"] == "Location updated Successfully!":
            geoId = response_body["responseData"]["geoId"]
            #message = response_body["responseData"]["message"]
            print('Geofence Id : ', geoId)
            #print('Message : ', message)
            testResult(self, "passed", "Geofence should be updated successfully",
                       "Geofence is updated successfully ")
        elif response_body["message"] != "Location updated Successfully!":
            # print(response_body["responseData"]["message"])
            testResult(self, "failed", "Geofence should be updated successfully ",
                       "Failed to update geofence " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            print("Something went wrong")

    print("----------------------------------------------------------")

    # Geofence_deleteGeofence
    @pytest.mark.Smoke
    def test1_positive_geofence_deleteGeofence(self):

        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Geofence", "Geofence_deleteGeofence")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            geoId = str(dict1["geoId"])
            if geoId:
                # Read geofence Id from Geofence_createGeofence api resp from Excel sheet
                dict1 = read_api_data_from_excel(self, "API_Data", "Geofence_createGeofence")
                api_resp = str(dict1["Actual API Response"])
                # print(api_resp)
                json_object = json.loads(api_resp)
                geoId = json_object["responseData"]["geoId"]
                print('Geofence Id : ', geoId)

        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")

            # Read geofence Id from Geofence_createGeofence api resp from Excel sheet
            dict1 = read_api_data_from_excel(self, "API_Data", "Geofence_createGeofence")
            api_resp = str(dict1["Actual API Response"])
            # print(api_resp)
            json_object = json.loads(api_resp)
            geoId = json_object["responseData"]["geoId"]
            print('Geofence Id : ', geoId)

        # Call api reusable module
        response = Geofence_deleteGeofence(self, geoId, "valid")

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        # Validate response body
        if response_body["responseCode"] == str(1200):
            geoId = response_body["responseData"]["id"]
            message = response_body["responseData"]["message"]
            print('Geofence Id : ', geoId)
            print('Message : ', message)
            testResult(self, "passed", "Geofence should be deleted successfully",
                       "Geofence is deleted successfully ")
        elif response_body["responseCode"] != str(1200):
            # print(response_body["responseData"]["message"])
            testResult(self, "failed", "Geofence should be deleted successfully ",
                       "Failed to delete the geofence " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            print("Something went wrong")

    print("----------------------------------------------------------")

    # Geofence_getGeofenceList
    @pytest.mark.Smoke
    def test1_positive_geofence_getGeofenceList(self):

        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Geofence", "Geofence_getGeofences")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")

        # Call api reusable module
        response = Geofence_getGeofences(self, "valid")

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        # Validate response body
        if response_body["message"] == "Success":
            testResult(self, "passed", "Geofence list should be fetched successfully",
                       "Geofence list is fetched successfully ")
        elif response_body["message"] != "Success":
            # print(response_body["responseData"]["message"])
            testResult(self, "failed", "Geofence list should be fetched successfully ",
                       "Failed to fetch the geofence list " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            print("Something went wrong")

    print("----------------------------------------------------------")