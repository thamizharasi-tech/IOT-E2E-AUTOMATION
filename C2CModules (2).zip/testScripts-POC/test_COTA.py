import pytest

from C2CModules.COTA_modules import COTA_liveCommandTracking
from C2CModules.e2e_testData import deviceType_IVI, drimaes_ivi_chipset
from C2CModules.primary_IVI_device_modules import get_SystemId
from C2CModules.testResults import testResult
from utils.XLUtils import read_api_data_from_excel

OnboardingType = deviceType = deviceType_IVI
chipsetType = drimaes_ivi_chipset


class Test_COTA:

    # COTA_live command tracking
    @pytest.mark.Smoke
    def test1_positive_COTA_liveCommandTracking(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "COTA", "COTA_liveCommandTracking")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)

        # Call COTA reusable module
        response_body = COTA_liveCommandTracking(self, systemId, "valid")

        # Validate response status code

        assert (response_body.status_code == 200), "Status code is not 200. Rather found : " + str(
            response_body.status_code)

        # Parse API response into JSON
        response_body = response_body.json()

        if response_body["message"] == str('Data fetched successfully'):

            print("Live Tracking", response_body["responseData"]["liveTracking"])
            print("Current Frequency", response_body["responseData"]["currentFrequency"])

            testResult(self, "passed", "Should fetch the current data/values for System Id successfully",
                       "Successfully fetched the current values/data for desired System Id ")

        elif response_body["message"] == str('Data fetched successfully'):

            testResult(self, "failed", "Should fetch the current data/values for System id successfully ",
                       "Failed to fetch the data/values " + " Reason for failure is : " +
                       response_body["responseData"]["message"])

        else:
            print("Something went wrong")
            assert False

    # COTA_live command tracking with invalid api key
    @pytest.mark.Smoke
    def test1_negative_COTA_liveCommandTracking_invalid_apiKey(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "COTA", "COTA_liveCommandTracking")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)

        # Call COTA reusable module
        response = COTA_liveCommandTracking(self, systemId, "invalid_apiKey")

        # Validate response status code
        assert (response.status_code == 403), "Status code is not 403. Rather found : " + str(
            response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        # Validate response body
        if response_body["message"] == "api keys are not matching..please provide valid key":
            testResult(self, "passed", "Should throw proper error for invalid api key",
                       "Showing proper error for invalid api key")
        else:

            testResult(self, "failed", "Should throw proper error for invalid api key",
                       "Not showing proper response code & error for invalid api key")

        print("----------------------------------------------------------")

    # COTA_live command tracking with empty api key
    @pytest.mark.Smoke
    def test2_negative_COTA_liveCommandTracking_empty_apiKey(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "COTA", "COTA_liveCommandTracking")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)

        # Call COTA reusable module
        response = COTA_liveCommandTracking(self, systemId, "empty_apiKey")

        # Validate response status code
        assert (response.status_code == 403), "Status code is not 403. Rather found : " + str(
            response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        # Validate response body
        if response_body["message"] == "api keys are not matching..please provide valid key":
            testResult(self, "passed", "Should throw proper error for empty api key",
                       "Showing proper error for empty api key")
        else:

            testResult(self, "failed", "Should throw proper error for empty api key",
                       "Not showing proper response code & error for empty api key")

        print("----------------------------------------------------------")

    # COTA_live command tracking with no api key
    @pytest.mark.Smoke
    def test3_negative_COTA_liveCommandTracking_no_apiKey(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "COTA", "COTA_liveCommandTracking")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)

        # Call COTA reusable module
        response = COTA_liveCommandTracking(self, systemId, "no_apiKey")

        # Validate response status code
        assert (response.status_code == 403), "Status code is not 403. Rather found : " + str(
            response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        # Validate response body
        if response_body["message"] == "Required authentication headers are missing..!!!!":
            testResult(self, "passed", "Should throw proper error for no api key",
                       "Showing proper error for no api key")
        else:

            testResult(self, "failed", "Should throw proper error for no api key",
                       "Not showing proper response code & error for no api key")

        print("----------------------------------------------------------")

    # COTA_live command tracking with empty x-requestor
    @pytest.mark.Smoke
    def test4_negative_COTA_liveCommandTracking_empty_xRequestor(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "COTA", "COTA_liveCommandTracking")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)

        # Call COTA reusable module
        response = COTA_liveCommandTracking(self, systemId, "empty_x-requestor")

        # Validate response status code
        assert (response.status_code == 403), "Status code is not 403. Rather found : " + str(
            response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        # Validate response body
        if response_body["message"] == "x-requestor header cannot be blank":
            testResult(self, "passed", "Should throw proper error for empty x-requestor",
                       "Showing proper error for empty x-requestor")
        else:

            testResult(self, "failed", "Should throw proper error for empty x-requestor",
                       "Not showing proper response code & error for empty x-requestor")

        print("----------------------------------------------------------")

    # COTA_live command tracking with no x-requestor
    @pytest.mark.Smoke
    def test5_negative_COTA_liveCommandTracking_no_xRequestor(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "COTA", "COTA_liveCommandTracking")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)

        # Call COTA reusable module
        response = COTA_liveCommandTracking(self, systemId, "no_x-requestor")

        # Validate response status code
        assert (response.status_code == 403), "Status code is not 403. Rather found : " + str(
            response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        # Validate response body
        if response_body["message"] == "Required authentication headers are missing..!!!!":
            testResult(self, "passed", "Should throw proper error for no x-requestor",
                       "Showing proper error for no x-requestor")
        else:

            testResult(self, "failed", "Should throw proper error for no x-requestor",
                       "Not showing proper response code & error for no x-requestor")

        print("----------------------------------------------------------")

    # COTA_live command tracking with invalid system id
    @pytest.mark.Smoke
    def test6_negative_COTA_liveCommandTracking_invalid_systemId(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "COTA", "COTA_liveCommandTracking_invalid_systemId")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = "sys123"

        # Call COTA reusable module
        response = COTA_liveCommandTracking(self, systemId, "valid")

        # Validate response status code
        assert (response.status_code == 400 or response.status_code == 403 or response.status_code == 404), "Status code is not 400/403. Rather found : " + str(
            response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        # Validate response body
        if response.status_code == 400:
            if response_body["errors"][0]["errorCode"] == str(14508):
                if response_body["errors"][0]["message"] == str('System Id should be 23 characters long'):
                    testResult(self, "passed", "Should throw proper error for invalid System Id",
                               "Showing proper response code & error message for invalid System Id")

            elif response_body["message"] == str('Data fetched successfully'):

                testResult(self, "failed", "Should throw proper error for invalid System Id",
                           "Not showing proper response code & error message for invalid System Id")

        elif response.status_code == 403 or response.status_code == 404:
            testResult(self, "passed", "Should throw proper error for invalid System Id",
                       "Showing proper response code & error message for invalid System Id")

        else:
            testResult(self, "failed", "Should throw proper error for invalid System Id",
                       "Not showing proper response code & error message for invalid System Id")

    # COTA_live command tracking with empty system id
    @pytest.mark.Smoke
    def test7_negative_COTA_liveCommandTracking_empty_systemId(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "COTA", "COTA_liveCommandTracking_empty_systemId")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            if systemId == "None":
                systemId = ""
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = ""

        # Call COTA reusable module
        response_body = COTA_liveCommandTracking(self, systemId, "valid")

        # Validate response status code

        assert (response_body.status_code == 404), "Status code is not 404. Rather found : " + str(
            response_body.status_code)

