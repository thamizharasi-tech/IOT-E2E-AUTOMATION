import pytest

from C2CModules.deviceRegistration_modules import registration_DeviceReg, \
    registration_getCount, registration_getDetails
from C2CModules.e2e_testData import deviceType_IVI


class Test_Registration:

    # Registration-DeviceReg
    @pytest.mark.Smoke
    def test1_positive_Registration_DeviceReg(self):
        registration_DeviceReg(self, deviceType_IVI)

    # Registration_getCount
    @pytest.mark.Smoke
    def test2_positive_Registration_getCount(self):
        registration_getCount(self)

    # Registration_getDetails
    @pytest.mark.Smoke
    def test3_positive_Registration_getDetails(self):
        registration_getDetails(self)



