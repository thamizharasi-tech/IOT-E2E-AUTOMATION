import random
import time

import pytest

from C2CModules.packageController_modules import packageController_packageUpgrade, packageController_packageAllDetails, \
    packageController_packageIdDetails, packageController_packageAssignmentDetails, \
    packageController_packageAssignmentStatusUpdate, read_packageId, read_packageStatus_byPackageId, \
    read_packageStatus_byTrackingId
from C2CModules.primary_IVI_device_modules import getVIN, get_SystemId
from C2CModules.testResults import testResult
from utils.XLUtils import read_api_data_from_excel
from C2CModules.e2e_testData import deviceType_IVI, drimaes_ivi_chipset

OnboardingType = deviceType = deviceType_IVI
chipsetType = drimaes_ivi_chipset


class Test_Package:

    # packageController_packageAllDetails
    @pytest.mark.Smoke
    def test1_positive_packageController_packageAllDetails(self):

        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "PackageController", "PackageController_PackageAllDetails")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            print("No Input Required")

        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            print("No Input Required")

        # Call api reusable module
        response_body = packageController_packageAllDetails(self)

        if response_body["responseCode"] == str(1200):
            data_len = len(response_body["responseData"]["dataList"])
            if data_len <= 0:
                print("Data list is empty")
            testResult(self, "passed", "Should list all the packages",
                       "All packages are listed ")
        elif response_body["responseCode"] != str(1200):
            # print(response_body["responseData"]["message"])
            testResult(self, "failed", "Should list all the packages ",
                       "All packages are not listed  " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            print("Something went wrong")

    print("----------------------------------------------------------")

    # PackageController_PackageIdDetails
    @pytest.mark.Smoke
    def test2_positive_PackageController_PackageIdDetails(self):

        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "PackageController", "PackageController_PackageIdDetails")
        message = str(dict["Message"])
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            packageId = str(dict1["packageId"])
            print("Package Id :", packageId)

        else:
            print("Flag is not set to Yes, pls update the test data in sheet")
            # Get package id for value package'
            response = packageController_packageAllDetails(self)
            packageId = read_packageId(self, response, "Value")

            print("Package Id for 'Value' Package : ", packageId)

        # Call api reusable module
        response_body = packageController_packageIdDetails(self, packageId)

        data_len = len(response_body["responseData"]["dataList"])
        if data_len <= 0:
            print("Data list is empty")
            testResult(self, "failed", "Should fetch and list the package details ",
                       "Package details is not fetched or listed   " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            testResult(self, "passed", "Should fetch and list the package details",
                       "Package details is successfully fetched and listed ")

        print("----------------------------------------------------------")

    # PackageController_PackageAssignmentDetails
    @pytest.mark.Smoke
    def test3_positive_PackageController_PackageAssignmentDetails(self):

        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "PackageController", "PackageController_PackageAssignmentDetails")
        message = str(dict["Message"])
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)

        print("System Id :", systemId)

        # Call api reusable module
        response_body = packageController_packageAssignmentDetails(self, systemId)

        data_len = len(response_body["responseData"]["dataList"])
        if data_len <= 0:
            print("Data list is empty")
            testResult(self, "failed", "Should fetch and list the package assignment details of the device ",
                       "Package assignment details of the device is not fetched or listed   " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            testResult(self, "passed", "Should fetch and list the package assignment details of the device",
                       "Package assignment details of the device is successfully fetched and listed")

        print("----------------------------------------------------------")

    # PackageController_PackageUpgrade
    @pytest.mark.Smoke
    def test4_positive_PackageController_PackageUpgrade(self):

        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "PackageController",
                                         "PackageController_PackageUpgrade")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            packageId = str(dict1["packageId"])
            vin = str(dict1["vin"])

        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            vin = getVIN(self, OnboardingType, chipsetType)
            # Get package id for value package'
            response = packageController_packageAllDetails(self)
            packageId = read_packageId(self, response, "Value")

        print("System Id :", systemId)
        print("Package Id: ", packageId)
        print("VIN: ", vin)

        # Call api reusable module
        response = packageController_packageUpgrade(self, systemId, vin, packageId)

        if response['message'] == 'Vehicle Package Mapping already exist':
            print(" => Vehicle is already mapped to 'Value' package, hence skipping this step")

            print("--------------------------------------------------------------")
            print("Verify package status : ")
            print("--------------------------------------------------------------")
            # Verify package upgrade status
            response = packageController_packageAssignmentDetails(self, systemId)

            # Get package id & status'
            status = read_packageStatus_byPackageId(self, response, packageId)

            print("Package Id: ", packageId)
            print("Package status: ", status)

            if status == "SUCCESS":
                testResult(self, "passed",
                           "'Value' package status should be set to 'SUCCESS'",
                           "'Value' package status is set to 'SUCCESS'")
            elif status != "SUCCESS":
                testResult(self, "failed",
                           "Package status should be set to 'SUCCESS'",
                           "Package status is not set to 'SUCCESS'")
        else:
            # Get package tracking id'
            packageTrackingId = response["responseData"]["packageTrackingId"]

            print("Package Tracking ID : ", packageTrackingId)
            testResult(self, "passed",
                       "Initiate package upgrade or Assign 'Value' package to Vehicle via API",
                       "Package Upgrade is initiated successfully ")

            print("--------------------------------------------------------------")
            print("Verify package status : ")
            print("--------------------------------------------------------------")

            for i in range(20):
                # Verify package upgrade status
                response = packageController_packageAssignmentDetails(self, systemId)

                # Get package id & status'

                packageId, status = read_packageStatus_byTrackingId(self, response, packageTrackingId)
                if status != "SUCCESS" or status == "IN_PROGRESS" or status == 'RECEIVED':
                    time.sleep(30)
                else:
                    break

            if status == "SUCCESS":
                print("Upgraded Package Id: ", packageId)
                print("Upgraded Package status: ", status)
                testResult(self, "passed",
                           "Vehicle should be mapped to 'Value' package",
                           "Vehicle is mapped to 'Value' package successfully")
            elif status != "SUCCESS":
                print("Vehicle is mapped to - Package Id: ", packageId)
                print("Vehicle Package status: ", status)
                testResult(self, "failed",
                           "Vehicle should be mapped to 'Value' package",
                           "Vehicle is not mapped to 'Value' package successfully")

        print("----------------------------------------------------------")


    # PackageController_PackageAssignmentStatusUpdate
    @pytest.mark.Smoke
    def test5_positive_PackageController_PackageAssignmentStatusUpdate(self):

        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "PackageController", "PackageController_PackageAssignmentStatusUpdate")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["systemId"])
            packageId = str(dict1["packageId"])
            packageTrackingId = str(dict1["trackingId"])
            status = str(dict1["status"])

        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            # Get package id for value package'
            response = packageController_packageAllDetails(self)
            packageId = read_packageId(self, response, "Value")
            # Verify package upgrade status
            response = packageController_packageAssignmentDetails(self, systemId)

            # Get package id & status'
            status = read_packageStatus_byPackageId(self, response, packageId)

            # Get package tracking id'
            try:
                packageTrackingId = response["responseData"]["packageTrackingId"]
            except:
                packageTrackingId = response["responseData"]["dataList"][1]["trackingId"]

        print("System Id :", systemId)
        print("Package Id: ", packageId)
        print("Package status: ", status)
        print("Package tracking Id: ", packageTrackingId)


        # Call api reusable module
        response_body = packageController_packageAssignmentStatusUpdate(self, systemId, packageId, status, packageTrackingId)

        data_len = len(response_body["responseData"]["dataList"])
        if data_len <= 0:
            print("Data list is empty")
            testResult(self, "failed", "Should fetch and list the package assignment status for the device ",
                       "Package assignment details of the device is not fetched or listed   " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            testResult(self, "passed", "Should fetch and list the package assignment status for the device",
                       "Package assignment details of the device is successfully fetched and listed")

        print("----------------------------------------------------------")
