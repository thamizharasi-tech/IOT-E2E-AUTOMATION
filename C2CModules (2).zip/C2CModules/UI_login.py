from playwright.sync_api import sync_playwright


def ui_login():
    playwright = sync_playwright().start()
    browser = playwright.chromium.launch(headless=False, args=["--start-maximised"])
    context = browser.new_context()
    # Open new page
    page = context.new_page()

    yield page