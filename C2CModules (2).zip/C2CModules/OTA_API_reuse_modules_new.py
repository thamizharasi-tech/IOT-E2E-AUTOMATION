import ast
import json
import time


import requests

from C2CModules.resuse_modules import save_api_resp_into_file
from C2CModules.token_generation import token_gen_reus_mod, update_apiheader_with_token_inExcel
from utils.XLUtils import save_api_resp_in_excel, read_api_data_from_excel


# ---------------------------------
# API Modules
# ---------------------------------

# FOTA API Reusable modules :


# FOTA-firmwareUpload

def FOTA_firmwareUpload(self, model, system, description, isDiffImage, isBase, isFull, downloadConsent, installConsent,
                        rebootConsent, filename, firmwareVer):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-firmwareUpload")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["model"] = model
    json_object["system"] = system
    json_object["description"] = description
    json_object["isDiffImage"] = isDiffImage
    json_object["isBase"] = isBase
    json_object["isFull"] = isFull
    json_object["downloadConsent"] = downloadConsent
    json_object["installConsent"] = installConsent
    json_object["rebootConsent"] = rebootConsent
    # json_object["firmwareVersion"] = firmwareVer
    json_object["filename"] = filename
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-firmwareUpload",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-firmwareUpload', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-firmwareUpload", response.text)

    # Validate response status code
    assert (
                response.status_code == 200 or response.status_code == 400), "Status code is not 200. Rather found : " + str(
        response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    return response_body


# FOTA-createScript

def FOTA_createScript(self, model, ScriptName, precondition, ecu_type, sourceVersion, targetVersion, releaseNote,temp):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-createScript")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    if "invalid_apiKey" == temp:
        header_x["api-key"] = 'xyz'
    elif "empty_apiKey" in temp:
        header_x["api-key"] = ''
    elif "no_apiKey" in temp:
        del header_x["api-key"]
    elif "empty_x-requestor" in temp:
        header_x["x-requestor"] = ''
    elif "no_x-requestor" in temp:
        del header_x["x-requestor"]
    print(header_x)

    # Payload :

    json_object = json.loads(payload)
    json_object["model"] = model
    json_object["name"] = ScriptName
    json_object["precondition"][0] = precondition
    json_object["steps"][0]["ecu"] = ecu_type
    json_object["steps"][0]["sourceVersion"] = sourceVersion
    json_object["steps"][0]["targetVersion"] = targetVersion
    json_object["releaseNote"] = releaseNote
    if "no_model" in temp:
        del json_object["model"]
    elif "no_name" in temp:
        del json_object["name"]
    elif "no_precondition" in temp:
        del json_object["precondition"]
    elif "no_ecu" in temp:
        del json_object["steps"][0]["ecu"]
    elif "no_sourceVersion" in temp:
        del json_object["steps"][0]["sourceVersion"]
    elif "no_targetVersion" in temp:
        del json_object["steps"][0]["targetVersion"]
    elif "no_releaseNote" in temp:
        del json_object["releaseNote"]

    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-createScript",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-createScript', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-createScript", response.text)


    return response

#FOTA-edit script
def FOTA_scriptReleaseNoteUpdate(self, scriptId, releaseNote,temp):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-PATCH-scriptReleaseNoteUpdate")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{scriptId}',scriptId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    if "invalid_apiKey" == temp:
        header_x["api-key"] = 'xyz'
    elif "empty_apiKey" in temp:
        header_x["api-key"] = ''
    elif "no_apiKey" in temp:
        del header_x["api-key"]
    elif "empty_x-requestor" in temp:
        header_x["x-requestor"] = ''
    elif "no_x-requestor" in temp:
        del header_x["x-requestor"]
    print(header_x)

    # Payload :

    json_object = json.loads(payload)
    json_object["release-note"] = releaseNote
    if "no_releaseNote" in temp:
        del json_object["release-note"]

    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.patch(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-PATCH-scriptReleaseNoteUpdate",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-PATCH-scriptReleaseNoteUpdate', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-PATCH-scriptReleaseNoteUpdate", response.text)


    return response


# FOTA-GetAllFirmware

def FOTA_GetAllFirmware(self,pageNo,pageSize, temp):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-GetAllFirmware")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{pageNo}',pageNo).replace('{pageSize}',pageSize)
    if "removeQueryParams_from_url" in temp:
        #Remove query params from the url
        complete_url=complete_url.split('?')[0]
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    if "invalid_apiKey" == temp:
        header_x["api-key"] = 'xyz'
    elif "empty_apiKey" in temp:
        header_x["api-key"] = ''
    elif "no_apiKey" in temp:
        del header_x["api-key"]
    elif "invalid_x-requestor" in temp:
        header_x["x-requestor"] = '@#$'
    elif "empty_x-requestor" in temp:
        header_x["x-requestor"] = ''
    elif "no_x-requestor" in temp:
        del header_x["x-requestor"]
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-GetAllFirmware",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-GetAllFirmware', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-GetAllFirmware", response.text)

    return response


# FOTA-Get-Firmware-models

def FOTA_Get_Firmware_models(self):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-Get-Firmware-models")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-Get-Firmware-models",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-Get-Firmware-models', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-Get-Firmware-models", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    return response_body


# FOTA-getVersionDetails

def FOTA_getVersionDetails(self, modelName):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-getVersionDetails")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{modelName}', modelName)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-getVersionDetails",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-getVersionDetails', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-getVersionDetails", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    return response_body


# FOTA-Get-Scriptmodel

def FOTA_Get_Scriptmodel(self):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-Get-Scriptmodel")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-Get-Scriptmodel",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-Get-Scriptmodel', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-Get-Scriptmodel", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    return response_body


# FOTA-GetAllScriptDetails

def FOTA_GetAllScriptDetails(self,pageNo,pageSize,temp):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-GetAllScriptDetails")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{pageNo}',pageNo).replace('{pageSize}',pageSize)
    if "removeQueryParams_from_url" in temp:
        #Remove query params from the url
        complete_url=complete_url.split('?')[0]
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    if "invalid_apiKey" == temp:
        header_x["api-key"] = 'xyz'
    elif "empty_apiKey" in temp:
        header_x["api-key"] = ''
    elif "no_apiKey" in temp:
        del header_x["api-key"]
    elif "empty_x-requestor" in temp:
        header_x["x-requestor"] = ''
    elif "no_x-requestor" in temp:
        del header_x["x-requestor"]
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-GetAllScriptDetails",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-GetAllScriptDetails', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-GetAllScriptDetails", response.text)


    return response


# FOTA-createPresigneUrl

def FOTA_createPresigneUrl(self, filename, system, model_name):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-createPresigneUrl")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["filename"] = filename
    json_object["system"] = system
    json_object["model-name"] = model_name
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-createPresigneUrl",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-createPresigneUrl', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-createPresigneUrl", response.text)

    # Validate response status code
    if response.status_code == 200 or response.status_code == 400:
        assert True
    else:
        print(response)
        assert False

    # Parse API response into JSON
    response_body = response.json()

    return response_body


# FOTA-uploadFile

def FOTA_uploadFile(self, upload_url, filepath):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-uploadFile")
    # base_url = str(dict["Base Url"])
    # endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    # payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.put(upload_url, headers=header_x, data=open(filepath, 'rb').read())

    print("API response : ", response)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-uploadFile",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.put(upload_url, headers=headers, data=open(filepath, 'rb').read())
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    # save_api_resp_into_file('FOTA-uploadFile', response.text)
    # save_api_resp_in_excel(self, "API_Data", "FOTA-uploadFile", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = ''

    return response_body


# FOTA-createSchedule

def FOTA_createSchedule(self, vin, scriptId, startDate, endDate):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-createSchedule")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["vins"][0] = vin
    json_object["scriptid"] = scriptId
    json_object["period"]["startDate"] = startDate
    json_object["period"]["endDate"] = endDate
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-createSchedule",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-createSchedule', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-createSchedule", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    return response_body


# FOTA-GetAllScheduleDetails

def FOTA_GetAllScheduleDetails(self,pageNo,pageSize,temp):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-GetAllScheduleDetails")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{pageNo}',pageNo).replace('{pageSize}',pageSize)
    if "removeQueryParams_from_url" in temp:
        #Remove query params from the url
        complete_url=complete_url.split('?')[0]


    print("Complete URL : ", complete_url)


    # Header :
    header_x = ast.literal_eval(headers)
    if "invalid_apiKey" == temp:
        header_x["api-key"] = 'xyz'
    elif "empty_apiKey" in temp:
        header_x["api-key"] = ''
    elif "no_apiKey" in temp:
        del header_x["api-key"]
    elif "empty_x-requestor" in temp:
        header_x["x-requestor"] = ''
    elif "no_x-requestor" in temp:
        del header_x["x-requestor"]
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-GetAllScheduleDetails",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-GetAllScheduleDetails', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-GetAllScheduleDetails", response.text)


    return response


# FOTA-GetScheduleStatus

def FOTA_GetScheduleStatus(self, scheduleId, vin):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-GetScheduleStatus")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{scheduleId}', scheduleId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["vins"] = vin
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    pload = json.dumps(payload)
    print("------------------", pload)
    response = requests.post(complete_url, headers=header_x, data=pload)
    print("API response : ", response.text)
    print(response)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-GetScheduleStatus",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-GetScheduleStatus', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-GetScheduleStatus", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    return response_body


# FOTA-GetPreconditions
def FOTA_GetPreconditions(self):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "FOTA-Get-Precondition")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    # print(header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("\n")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "FOTA-GetToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "FOTA-Get-Precondition",
                                                "FOTA-GetToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('FOTA-Get-Precondition', response.text)
    save_api_resp_in_excel(self, "API_Data", "FOTA-Get-Precondition", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    return response_body