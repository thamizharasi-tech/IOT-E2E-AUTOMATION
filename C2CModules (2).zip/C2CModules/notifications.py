import ast
import json
import time

import requests

from C2CModules.api_modules import header_update
from C2CModules.resuse_modules import save_api_resp_into_file
from C2CModules.token_generation import token_gen_reus_mod, update_apiheader_with_token_inExcel
from utils.XLUtils import read_api_data_from_excel, save_api_resp_in_excel


# ---------------------------------
# API Modules
# ---------------------------------
# Notification_message
def notification_message(self, vin, systemId, message):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Notification_message")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request
    #  vin = getVIN(self, "tel", deviceType_IVI)
    #  systemId = get_SystemId(self, deviceType_IVI)

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["target"][0]["systemId"] = systemId
    json_object["target"][0]["vin"] = vin
    json_object["message"] = message
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Notification-AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Notification_message",
                                                "Notification-AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Notification_message', response.text)
    save_api_resp_in_excel(self, "API_Data", "Notification_message", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    if response_body["responseCode"] == str(1200):
        assert (response_body["responseData"]["message"] == "SUCCESS")
    else:
        print("response Code is not 1200. Rather found : " + str(response_body))
        assert False

    return response_body

# Notification_message
def notification_message_new(self, vin, systemId, message, source, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Notification_message")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)

    # Payload :
    json_object = json.loads(payload)
    if tc == "invalid_without_systemId_field":
        del json_object["target"][0]["systemId"]
    else:
        json_object["target"][0]["systemId"] = systemId
    if tc == "invalid_without_vin_field":
        del json_object["target"][0]["vin"]
    else:
        json_object["target"][0]["vin"] = vin
    if tc == "invalid_without_message_field":
        del json_object["message"]
    else:
        json_object["message"] = message
    if tc == "invalid_without_source_field":
        del json_object["meta"]["source"]
    else:
        json_object["meta"]["source"] = source
    if tc == "invalid_without_target_field":
        del json_object["target"]
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Notification-AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Notification_message",
                                                "Notification-AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Notification_message', response.text)
    save_api_resp_in_excel(self, "API_Data", "Notification_message", response.text)

    return response


# Notification Service Controller -Subscribe
def notificationServiceController_subscribe(self, systemId, vin, endPoint, categoryName, destinationType):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "notificationServiceController_subscribe")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["filterValues"][0]["systemId"] = systemId
    json_object["filterValues"][0]["vin"] = vin
    json_object["category"][0]["endPoint"] = endPoint
    json_object["category"][0]["categoryName"] = categoryName
    json_object["category"][0]["destinationType"] = destinationType
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Notification-AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Notification_message",
                                                "Notification-AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('notificationServiceController_subscribe', response.text)
    save_api_resp_in_excel(self, "API_Data", "notificationServiceController_subscribe", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    return response_body


# Notification Service Controller - Details by System Id
def notificationServiceController_details_by_systemId(self, systemId):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "notificationServiceController_details_by_systemId")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Url :
    complete_url = str(base_url + endpoint).replace('{systemId}', systemId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Notification-AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Notification_message",
                                                "Notification-AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('notificationServiceController_details_by_systemId', response.text)
    save_api_resp_in_excel(self, "API_Data", "notificationServiceController_details_by_systemId", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    return response_body


# Notification Service Controller - Details by System Id & Category Type
def notificationServiceController_details_by_systemId_Category(self, systemId, categoryType):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "notificationServiceController_details_by_systemId_Category")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Url :
    complete_url = str(base_url + endpoint).replace('{systemId}', systemId).replace('{notificationType}', categoryType)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Notification-AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Notification_message",
                                                "Notification-AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('notificationServiceController_details_by_systemId_Category', response.text)
    save_api_resp_in_excel(self, "API_Data", "notificationServiceController_details_by_systemId_Category",
                           response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    return response_body


# Notification Service Controller - Un-Subscribe
def notificationServiceController_unsubscribe(self, systemId, vin, endPoint, categoryName, destinationType):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "notificationServiceController_unsubscribe")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    print(header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["filterValues"][0]["systemId"] = systemId
    json_object["filterValues"][0]["vin"] = vin
    json_object["category"][0]["endPoint"] = endPoint
    json_object["category"][0]["categoryName"] = categoryName
    json_object["category"][0]["destinationType"] = destinationType
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.delete(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Notification-AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Notification_message",
                                                "Notification-AuthToken")
            time.sleep(60)
            response = requests.delete(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('notificationServiceController_unsubscribe', response.text)
    save_api_resp_in_excel(self, "API_Data", "notificationServiceController_unsubscribe", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    return response_body


# Notification_broadcastMessage
def notification_broadcastMessage(self, groupName, title, message, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Notification_broadcastMessage")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Url :
    complete_url = str(base_url + endpoint).replace('{groupName}', groupName)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["title"] = title
    json_object["message"] = message
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Notification-AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Notification_broadcastMessage",
                                                "Notification-AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Notification_broadcastMessage', response.text)
    save_api_resp_in_excel(self, "API_Data", "Notification_broadcastMessage", response.text)

    return response


# Notification_createBroadcastGroup
def notification_createBroadcastGroup(self, systemId, vin, groupName, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Notification_createBroadcastGroup")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    if tc == "invalid_without_systemId_field":
        del json_object["group"][0]["systemId"]
    else:
        json_object["group"][0]["systemId"] = systemId
    if tc == "invalid_without_VIN_field":
        del json_object["group"][0]["vin"]
    else:
        json_object["group"][0]["vin"] = vin
    if tc == "invalid_without_groupName_field":
        del json_object["groupName"]
    else:
        json_object["groupName"] = groupName
    if tc == "invalid_without_group_field":
        del json_object["group"]
    if tc == "invalid_without_vinSystemId_field":
        del json_object["group"][0]["vin"]
        del json_object["group"][0]["systemId"]
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Notification-AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Notification_createBroadcastGroup",
                                                "Notification-AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Notification_createBroadcastGroup', response.text)
    save_api_resp_in_excel(self, "API_Data", "Notification_createBroadcastGroup", response.text)

    return response
