import ast
import json
import random
import time

import requests

from C2CModules.e2e_testData import deviceIdFlag, reqDeviceId_tcu, reqDeviceId_ivi
from C2CModules.resuse_modules import *
from C2CModules.testResults import testResult
from C2CModules.token_generation import token_gen_reus_mod, update_apiheader_with_token_inExcel
from utils.XLUtils import read_api_data_from_excel, save_api_resp_in_excel


# Registration-DeviceReg - E2E
def registration_DeviceReg(self, deviceType):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Registration-DeviceReg")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = base_url + endpoint
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)

    random_id = ' '.join([str(random.randint(10, 9999)).zfill(7) for _ in range(1)])

    if deviceType == "TCU":
        if deviceIdFlag == "Yes":
            deviceId = reqDeviceId_tcu
        else:
            deviceId = "QA_TEST_TCU_" + random_id
    elif deviceType == "IVI":
        if deviceIdFlag == "Yes":
            deviceId = reqDeviceId_ivi
        else:
            deviceId = "QA_TEST_IVI_" + random_id

    # Payload :
    json_object = json.loads(payload)
    print(json_object)
    json_object[0]['device_type'] = deviceType
    json_object[0]["device_id"] = deviceId
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Registration-RequestToken")
            time.sleep(5)
            update_apiheader_with_token_inExcel(self, "API_Data", "Registration-DeviceReg", "Registration-RequestToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Registration-DeviceReg', response.text)
    save_api_resp_in_excel(self, "API_Data", "Registration-DeviceReg", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()
    # Validate api response body contents
    assert(response_body["responseCode"] == "1200")
    assert(response_body["responseMessage"] == "SUCCESS")
    reqId = response_body["responseData"]["requestId"]
    print("Request Id :", reqId)
    assert(response_body["responseData"]["status"] == "SUBMITTED")
    assert (response_body["responseData"]["message"] == "Request Submitted for registration!")
    return response_body


# Registration_getCount
def registration_getCount(self):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Registration_getCount")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Read reqId from Registration_DeviceReg api resp from Excel sheet
    dict1 = read_api_data_from_excel(self, "API_Data", "Registration-DeviceReg")
    api_resp = str(dict1["Actual API Response"])
    # print(api_resp)
    json_object = json.loads(api_resp)
    reqId = json_object["responseData"]["requestId"]
    print("Request Id :", reqId)


    # Url :
    url = base_url + endpoint
    complete_url = url.replace('{requestId}',reqId)
    print("Complete URL : ", complete_url)

    # Header:
    header_x = ast.literal_eval(headers)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    #print(payload)
    time.sleep(90)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Registration-RequestToken_GETmethod")
            time.sleep(5)
            update_apiheader_with_token_inExcel(self, "API_Data", "Registration_getCount",
                                                "Registration-RequestToken_GETmethod")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Registration_getCount', response.text)
    save_api_resp_in_excel(self, "API_Data", "Registration_getCount", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    # Validate api response body contents
    assert (response_body["responseData"]["totalCount"] == 1)
    assert (response_body["responseData"]["status"] == "Completed")
    print("Success Count : ", response_body["responseData"]["successCount"])
    print("Failure Count : ", response_body["responseData"]["failCount"])
    if response_body["responseData"]["successCount"] == 1:
        print("successCount is set to :=> ", response_body["responseData"]["successCount"])
        testResult(self, "passed", 'New Device Registration', 'New Device is registered successfully')
        print('\n')
        # assert True
    elif response_body["responseData"]["failCount"] == 1:
        print("failCount is set to :=> ", response_body["responseData"]["failCount"])
        testResult(self, "failed", 'New Device Registration', 'New Device is not registered successfully')
    assert (response_body["responseData"]["failCount"] == 0)
    assert (response_body["responseData"]["message"] == "Successfully generated the registration data.")
    return response_body

# Registration_getDetails
def registration_getDetails(self):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Registration_getDetails")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Read reqId from Registration_DeviceReg api resp from Excel sheet
    dict1 = read_api_data_from_excel(self, "API_Data", "Registration-DeviceReg")
    api_resp = str(dict1["Actual API Response"])
    # print(api_resp)
    json_object = json.loads(api_resp)
    reqId = json_object["responseData"]["requestId"]
    print("Request Id :", reqId)


    # Url :
    url = base_url + endpoint
    complete_url = url.replace('{requestId}',reqId)
    print("Complete URL : ", complete_url)

    # Header:
    header_x = ast.literal_eval(headers)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    #print(payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Registration-RequestToken_GETmethod")
            time.sleep(5)
            update_apiheader_with_token_inExcel(self, "API_Data", "Registration_getDetails",
                                                "Registration-RequestToken_GETmethod")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Registration_getDetails', response.text)
    save_api_resp_in_excel(self, "API_Data", "Registration_getDetails", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    # Validate api response body contents
    if response_body["responseMessage"] == "SUCCESS" or response_body["responseMessage"] == "Success":
        # print(f"Response Message is SUCCESS")
        assert True
        assert (response_body["responseMessage"] == "Success")
    else:
        print(str(response_body["responseMessage"]))

    device_id = response_body["responseData"][0]["device_id"]
    status = response_body["responseData"][0]["status"]
    url = response_body["responseData"][0]["url"]
    systemId = response_body["responseData"][0]["system_id"]
    deviceType = response_body["responseData"][0]["device_type"]
    certificateDetails = response_body["responseData"][0]["certificateDetails"]["certificate"]
    PrivateKeyDetails = response_body["responseData"][0]["certificateDetails"]["privateKey"]
    return response_body

# Registration-DeviceReg - API for negative test cases
def Registration_DeviceReg_API(self, device_type, device_id, attestationMechanism):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "DeviceRegistration", "Registration-DeviceReg")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = base_url + endpoint
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)

    random_id = ' '.join([str(random.randint(10, 9999)).zfill(7) for _ in range(1)])

    # Payload :
    json_object = json.loads(payload)
    print(json_object)
    json_object[0]['device_type'] = device_type
    json_object[0]["device_id"] = device_id
    json_object[0]["attestationMechanism"] = attestationMechanism
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    return response



