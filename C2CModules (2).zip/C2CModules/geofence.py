import ast
import json
import time

import requests

from C2CModules.api_modules import header_update
from C2CModules.resuse_modules import save_api_resp_into_file
from C2CModules.token_generation import token_gen_reus_mod, update_apiheader_with_token_inExcel
from utils.XLUtils import read_api_data_from_excel, save_api_resp_in_excel


# ---------------------------------
# API Modules
# ---------------------------------

# Geofence Creation
def Geofence_createGeofence(self, name, geometryType, radius, long, lat, isActive, tolerance, type, poiFlag, tag, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Geofence_createGeofence")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["name"] = name
    json_object["geometryType"] = geometryType
    json_object["radius"] = radius
    json_object["coordinates"][0][0] = long
    json_object["coordinates"][0][1] = lat
    json_object["isActive"] = isActive
    json_object["tolerance"] = tolerance
    json_object["type"] = type
    json_object["poiFlag"] = poiFlag
    json_object["tag"] = tag
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Geofence_AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Geofence_createGeofence",
                                                "Geofence_AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Geofence_createGeofence', response.text)
    save_api_resp_in_excel(self, "API_Data", "Geofence_createGeofence", response.text)

    return response


# Geofence - Update
def Geofence_updateGeofence(self, geoId, name, geometryType, radius, long, lat, isActive, tolerance, type, poiFlag,
                            tag, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Geofence_updateGeofence")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{geofenceId}', geoId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["name"] = name
    json_object["geometryType"] = geometryType
    json_object["radius"] = radius
    json_object["coordinates"][0][0] = str(long)
    json_object["coordinates"][0][1] = str(lat)
    json_object["isActive"] = isActive
    json_object["tolerance"] = tolerance
    json_object["type"] = type
    json_object["poiFlag"] = poiFlag
    json_object["tag"] = tag
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.put(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Geofence_AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Geofence_updateGeofence",
                                                "Geofence_AuthToken")
            time.sleep(60)
            response = requests.put(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Geofence_updateGeofence', response.text)
    save_api_resp_in_excel(self, "API_Data", "Geofence_updateGeofence", response.text)


    return response


# Geofence - Delete
def Geofence_deleteGeofence(self, geoId, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Geofence_deleteGeofence")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for DELETE request

    # Url :
    complete_url = str(base_url + endpoint).replace('{geofenceId}', geoId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.delete(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Geofence_AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Geofence_deleteGeofence",
                                                "Geofence_AuthToken")
            time.sleep(60)
            response = requests.delete(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Geofence_deleteGeofence', response.text)
    save_api_resp_in_excel(self, "API_Data", "Geofence_deleteGeofence", response.text)


    return response

# Geofence - get geofence list
def Geofence_getGeofences(self, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Geofence_getGeofences")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for GET request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token Generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Geofence_AuthToken")
            update_apiheader_with_token_inExcel(self, "API_Data", "Geofence_deleteGeofence",
                                                "Geofence_AuthToken")
            time.sleep(60)
            response = requests.delete(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Geofence_getGeofences', response.text)
    save_api_resp_in_excel(self, "API_Data", "Geofence_getGeofences", response.text)

    return response
