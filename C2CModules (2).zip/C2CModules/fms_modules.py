import ast
import json
import time
import os
import requests

from C2CModules.api_modules import header_update
from C2CModules.testResults import testResult
from C2CModules.e2e_testData import *
from C2CModules.resuse_modules import verify_message_in_log, save_api_resp_into_file
from C2CModules.token_generation import token_gen_reus_mod, update_apiheader_with_token_inExcel
from utils.XLUtils import read_api_data_from_excel, save_api_resp_in_excel
from C2CModules.primary_IVI_device_modules import pull_files_from_primary_IVI


# ---------------------------------
# API Modules
# ---------------------------------

# AssetManagement_trip-info
def assetManagement_trip_info_by_date(self, startDate, endDate):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_trip-info")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Url :
    url = str(base_url + endpoint).replace('{startDate}', startDate)
    complete_url = str(url).replace('{endDate}', endDate)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    # print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_trip-info",
                                                "AssetManagement_trip_AuthToken")
            time.sleep(120)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_trip-info', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_trip-info", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    if response_body["responseCode"] == str(1200):
        assert (response_body["responseData"]["message"] == "Success")
    else:
        print("response Code is not 1200. Rather found : " + str(response_body))
        assert False

    return response_body


# AssetManagement_trip-info-by-tripId
def assetManagement_trip_info_by_tripId(self, trip_id):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_trip-info-by-tripId")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{tripIdValue}', trip_id).replace('\n', '')
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    # print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_trip-info-by-tripId",
                                                "AssetManagement_trip_AuthToken")
            time.sleep(120)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
            # time.sleep(60)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_trip-info-by-tripId', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_trip-info-by-tripId", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body))
        assert False

    return response_body


# AssetManagement_trip-waypoints-by-tripid
def assetManagement_trip_waypoints_by_tripid(self, trip_id):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_trip-waypoints-by-tripid")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{tripId}', trip_id).replace('\n', '')
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    # print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_trip-waypoints-by-tripid",
                                                "AssetManagement_trip_AuthToken")
            time.sleep(120)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_trip-waypoints-by-tripid', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_trip-waypoints-by-tripid", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body))
        assert False

    return response_body


# AssetManagement_trip-waypoints-by-systemId
def assetManagement_trip_waypoints_by_systemId(self, startDate, endDate, systemId):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_trip-waypoints-by-systemId")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Url :
    url = str(base_url + endpoint).replace('{startDate}', startDate)
    completeurl = str(url).replace('{endDate}', endDate)
    complete_url = str(completeurl).replace('{systemId}', systemId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    # print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_trip-waypoints-by-systemId",
                                                "AssetManagement_trip_AuthToken")
            time.sleep(120)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
            # time.sleep(60)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_trip-waypoints-by-systemId', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_trip-waypoints-by-systemId", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body))
        assert False

    return response_body


# AssetManagement_latest-trip-meta
def assetManagement_latest_trip_meta(self, vin, systemId, status):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_latest-trip-meta")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)

    # Payload :
    json_object = json.loads(payload)
    json_object["vin"] = vin
    json_object["systemId"] = systemId
    json_object["status"] = status
    payload = json_object
    # print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_latest-trip-meta",
                                                "AssetManagement_trip_AuthToken")
            time.sleep(120)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
            # time.sleep(60)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_latest-trip-meta', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_latest-trip-meta", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body))
        assert False

    return response_body


# AssetManagement_latest-trip-details
def assetManagement_latest_trip_details(self, vin, systemId, status):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_latest-trip-details")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)

    # Payload :
    json_object = json.loads(payload)
    json_object["vin"] = vin
    json_object["systemId"] = systemId
    json_object["status"] = status
    payload = json_object
    # print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_latest-trip-details",
                                                "AssetManagement_trip_AuthToken")
            time.sleep(120)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
            # time.sleep(60)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_latest-trip-details', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_latest-trip-details", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body))
        assert False

    return response_body


# ---------------------------------
# NEW API Modules
# ---------------------------------

# AssetManagement_trip-info
def assetManagement_trip_info_by_date_new(self, startDate, endDate, pageNo, pageSize, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_trip-info")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Url :
    url = str(base_url + endpoint).replace('{startDate}', startDate)
    complete_url = str(url).replace('{endDate}', endDate).replace('{pageNo}', pageNo).replace('pageNo=0',
                                                                                              'pageNo=' + str(
                                                                                                  pageNo)).replace(
        '{pageSize}', pageSize).replace('pageSize=10', 'pageSize=' + str(pageSize)).replace('pageSize=10',
                                                                                            'pageSize=' + str(pageSize))
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Headers:\n", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_trip-info",
                                                "AssetManagement_trip_AuthToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_trip-info', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_trip-info", response.text)

    return response


# AssetManagement_trip-info-by-tripId
def assetManagement_trip_info_by_tripId_new(self, trip_id, pageNo, pageSize, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_trip-info-by-tripId")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{tripIdValue}', trip_id).replace('{pageNo}', pageNo).replace(
        'pageNo=0', 'pageNo=' + str(pageNo)).replace('{pageSize}', pageSize).replace('pageSize=10',
                                                                                     'pageSize=' + str(pageSize))

    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Headers:\n", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_trip-info-by-tripId",
                                                "AssetManagement_trip_AuthToken")
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
            time.sleep(60)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_trip-info-by-tripId', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_trip-info-by-tripId", response.text)

    return response


# AssetManagement_trip-waypoints-by-tripid
def assetManagement_trip_waypoints_by_tripid_new(self, trip_id, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_trip-waypoints-by-tripid")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{tripId}', trip_id).replace('\n', '')
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Headers:\n", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_trip-waypoints-by-tripid",
                                                "AssetManagement_trip_AuthToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_trip-waypoints-by-tripid', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_trip-waypoints-by-tripid", response.text)

    return response


# AssetManagement_trip-waypoints-by-systemId
def assetManagement_trip_waypoints_by_systemId_new(self, startDate, endDate, pageNo, pageSize, systemId, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_trip-waypoints-by-systemId")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Url :
    url = str(base_url + endpoint).replace('{startDate}', startDate)
    completeurl = str(url).replace('{endDate}', endDate)
    print(completeurl)

    if "{pageNo}" in completeurl:
        complete_url = str(completeurl).replace('{pageNo}', pageNo).replace(
            '{pageSize}', pageSize).replace('{systemId}', systemId)
    else:
        pageNo1 = 'pageNo=' + str(pageNo)
        pageSize1 = 'pageSize=' + str(pageSize)
        print(pageNo1, pageSize1)
        complete_url = str(completeurl).replace('pageNo=0', pageNo1).replace('pageSize=10', pageSize1).replace('{systemId}', systemId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Headers:\n", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_trip-waypoints-by-systemId",
                                                "AssetManagement_trip_AuthToken")
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
            time.sleep(60)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_trip-waypoints-by-systemId', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_trip-waypoints-by-systemId", response.text)

    return response


# AssetManagement_latest-trip-meta
def assetManagement_latest_trip_meta_new(self, vin, systemId, status, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_latest-trip-meta")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Headers:\n", header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["vin"] = vin
    json_object["systemId"] = systemId
    json_object["status"] = status
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_latest-trip-meta",
                                                "AssetManagement_trip_AuthToken")
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
            time.sleep(60)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_latest-trip-meta', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_latest-trip-meta", response.text)

    return response


# AssetManagement_latest-trip-details
def assetManagement_latest_trip_details_new(self, vin, systemId, status, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "AssetManagement_latest-trip-details")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Headers:\n", header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["vin"] = vin
    json_object["systemId"] = systemId
    json_object["status"] = status
    # if "without_systemId" == tc:
    # del json_object["systemId"]
    # if "without_vin" == tc:
    # del json_object["vin"]
    if "without_vin_sys" == tc:
        del json_object["vin"]
        del json_object["systemId"]
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "AssetManagement_trip_AuthToken")
            time.sleep(10)
            update_apiheader_with_token_inExcel(self, "API_Data", "AssetManagement_latest-trip-details",
                                                "AssetManagement_trip_AuthToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
            time.sleep(60)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('AssetManagement_latest-trip-details', response.text)
    save_api_resp_in_excel(self, "API_Data", "AssetManagement_latest-trip-details", response.text)

    return response




# ---------------------------------
# Modules
# ---------------------------------
def get_tridId_from_log(self):
    print("Read the trip id from c2c log file")
    ls = verify_message_in_log(self, tripId_code, tripId_code)

    if tripId_code in str(ls[0]):
        print(str(ls[0]))
        trip_id = str(ls[0]).split('trip_id: ')
        trip_id = str(trip_id[1])
        print(f"Trip Id should be generated in 'systemId_timestamp' format")
        testResult(self, "verificationPassed", "Telemetry message should be published to cloud via Hub ",
                   "Trip Id is generated in 'systemId_timestamp' format")
        print("Trip Id : ", trip_id)
    if str(ls[0]) == "Error":
        ls = verify_message_in_log(self, 'Trip_id: ', 'Trip_id: ')
        print(ls)
        trip_id = str(ls[0]).split('Trip_id: ')
        try:
            trip_id = str(trip_id[1])
        except:
            trip_id = ""

        if str(ls[0]) == "Error" or trip_id == "":
            print(
                "Trip Id is not generated or not found in device logs. pls refer device files & logs for detailed info")
            trip_id = ""
    return trip_id


# ------------------------------------------------------------
# calculate fuel consumed based on trip start & end fuel level
# ------------------------------------------------------------
def calculate_fuel_consumed(self, trip_start_fuel_level, trip_end_fuel_level):
    # Fuel Usage = Fuel end - Fuel start
    try:
        fuel_consumed1 = float(trip_start_fuel_level - trip_end_fuel_level)
        fuel_consumed = float(fuel_consumed1 / 1000)
    except:
        fuel_consumed1 = float(trip_start_fuelLevel_value_ev - trip_end_fuelLevel_value_ev)  # coverting into litters
        fuel_consumed = float(fuel_consumed1 / 1000)
    return fuel_consumed


# ------------------------------------------------------------
# calculate CO2 emission
# ------------------------------------------------------------
def calculate_CO2_emission(self, fuel_usage, fuel_constant):
    # CO2(kg) = Fuel Usage * Fuel Constant
    try:
        CO2_emission = float(fuel_usage * fuel_constant)
    except:
        CO2_emission = float(trip_summary_fuelConsumed_value_ev * trip_Fuel_Constant_ev)

    return CO2_emission


# ------------------------------------------------------------
# calculate trip distance based on trip start & end odo meter value
# ------------------------------------------------------------
def calculate_trip_distance(self, trip_start_odo, trip_end_odo):
    # Trip distance = ODO End – ODO Start
    try:
        trip_distance = float((trip_end_odo - trip_start_odo) / 1000)
    except:
        trip_distance = float(trip_end_odometer_value - trip_start_odometer_value) / 1000  # coverting into Km's
    return trip_distance


# ------------------------------------------------------------
# calculate trip fuel efficiency
# ------------------------------------------------------------
def calculate_trip_fuel_efficiency(self, trip_distance, trip_fuel_usage):
    # Fuel Efficiency = Trip Distance/ Fuel Usage
    try:
        fuel_efficiency = float(trip_distance / trip_fuel_usage)

    except ZeroDivisionError:
        fuel_efficiency = 0.0

    except:
        fuel_efficiency = 0.0

    return fuel_efficiency


# ------------------------------------------------------------
# calculate trip duration based on trip start & end time stamp
# ------------------------------------------------------------
def calculate_trip_duration(self, trip_start_time, trip_end_time):
    # Trip duration = (Trip End  time – Trip Start time)/3600000 [ to covert ms to hrs]
    try:
        trip_duration = float((trip_end_time - trip_start_time) / 3600000)

    except ZeroDivisionError:
        trip_duration = 0.0
    except:
        trip_duration = 0.0

    return trip_duration


# ------------------------------------------------------------
# calculate average speed
# ------------------------------------------------------------
def calculate_average_speed(self, trip_distance, trip_duration):
    # Avg Speed = Trip distance/ Trip Duration
    try:
        avg_speed = float(trip_distance / trip_duration)

    except ZeroDivisionError:
        avg_speed = 0.0

    except:
        avg_speed = float(trip_summary_tripDistance_value_ev / trip_summary_tripDuration_value_ev)  # km/hr

    return avg_speed


# ------------------------------------------------------------
# calculate battery consumed
# ------------------------------------------------------------
def calculate_battery_consumed(self, trip_start_battery_level, trip_end_battery_level):
    # batteryConsumed = (battery_level_end - battery_level_start) / 1000(inkwh)
    try:
        battery_consumed = float((trip_start_battery_level - trip_end_battery_level) / 1000)  # kwh
        if battery_consumed < 0:
            battery_consumed = battery_consumed * (-1)

    except ZeroDivisionError:
        battery_consumed = 0.0

    except:
        battery_consumed = float(trip_summary_tripDistance_value_ev / trip_summary_tripDuration_value_ev) / 1000

    return battery_consumed


# ------------------------------------------------------------
# calculate battery consumed based on battery SOC level
# ------------------------------------------------------------
def calculate_batterySOClevel_consumed(self, trip_start_battery_level, trip_end_battery_level):
    # batteryConsumed = (battery_level_end - battery_level_start) / 1000(inkwh)
    try:

        battery_consumed = float((trip_start_battery_level - trip_end_battery_level))  # %
        if battery_consumed < 0:
            battery_consumed = battery_consumed * (-1)

    except ZeroDivisionError:
        battery_consumed = 0.0

    except:
        battery_consumed = float(trip_summary_tripDistance_value_ev / trip_summary_tripDuration_value_ev) / 1000

    return battery_consumed


# ------------------------------------------------------------
# calculate battery efficiency
# ------------------------------------------------------------
def calculate_trip_battery_efficiency(self, trip_distance, battery_consumed):
    # trip_battery_efficiency = Trip distance/batteryConsumed
    try:
        battery_efficiency = float(trip_distance / battery_consumed)

    except ZeroDivisionError:
        battery_efficiency = 0.0
    except:
        battery_efficiency = float(trip_summary_tripDistance_value_ev) / float(trip_summary_batteryConsumed_value_ev)

    return battery_efficiency


# ------------------------------------------------------------
# calculate battery efficiency based on battery SOC level
# ------------------------------------------------------------
def calculate_trip_batterySOClevel_efficiency(self, trip_distance, battery_consumed):
    # trip_battery_efficiency = Trip distance/batteryConsumed
    batterySOClevelConstant = 41.86
    try:
        battery_efficiency = float(trip_distance / ((batterySOClevelConstant * battery_consumed) / 100))

    except ZeroDivisionError:
        battery_efficiency = 0.0
    except:
        battery_efficiency = float(trip_summary_tripDistance_value_ev) / float(
            batterySOClevelConstant * trip_summary_batteryConsumed_value_ev) / 100

    return battery_efficiency


# ------------------------------------------------------------
# Read Trip Id from trip file
# ------------------------------------------------------------

def read_tripId_from_Trip_waypoints(self, onboarding_Type, chipset_type, option):
    pull_files_from_primary_IVI(self, onboarding_Type, chipset_type, option)
    file = os.listdir('C:\Car2Cloud_E2ETesting\C2CtestReport\e2eExecution_Backup\c2cLogs\Trip_waypoints')[0]
    file = file.split('_')
    filename = file[0] + "_" + file[1]
    print(filename)
    return filename
