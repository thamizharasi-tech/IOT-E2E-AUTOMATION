import ast
import json
import time
import requests

from C2CModules.api_modules import header_update
from C2CModules.resuse_modules import save_api_resp_into_file
from C2CModules.token_generation import token_gen_reus_mod, update_apiheader_with_token_inExcel
from utils.XLUtils import read_api_data_from_excel, save_api_resp_in_excel


# Telemetry - Telemetry_Curr
def telemetry_Curr(self, event_type, systemId):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_Curr")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    # systemId = get_SystemId(self, deviceType_IVI)
    complete_url = str(base_url + endpoint).replace('{sysId}', systemId).replace('{eventTypeValue}',
                                                                                 str(event_type))
    complete_url = str(base_url + endpoint).replace('{sysId}', systemId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    # print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Telemetry_Curr",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_Curr', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_Curr", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body["message"]))
        assert False

    assert (response_body["responseData"]["message"] == "Successfully fetched the current values")

    return response_body


# Telemetry_CurrForEventType
def telemetry_Curr_eventType(self, event_type, systemId, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_CurrForEventType")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    # systemId = get_SystemId(self, deviceType_IVI)
    complete_url = str(base_url + endpoint).replace('{systemId}', systemId).replace('{eventType}',
                                                                                    str(event_type))
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Telemetry_CurrForEventType",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_CurrForEventType', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_CurrForEventType", response.text)

    return response


# Telemetry_Curr_byVIN
def telemetry_Curr_byVIN(self, vin, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_Curr_byVIN")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    # systemId = get_SystemId(self, deviceType_IVI)
    complete_url = str(base_url + endpoint).replace('{vin}', vin)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Telemetry_Curr_byVIN",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_Curr_byVIN', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_Curr_byVIN", response.text)

    return response


# Telemetry_Curr_byVINandEventType
def telemetry_Curr_byVIN_eventType(self, event_type, vin, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_Curr_byVINandEventType")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    # systemId = get_SystemId(self, deviceType_IVI)
    complete_url = str(base_url + endpoint).replace('{vin}', vin).replace('{eventType}',
                                                                          str(event_type))
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Telemetry_CurrForEventType",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_Curr_byVINandEventType', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_Curr_byVINandEventType", response.text)

    return response


# Telemetry_Curr_byVINandEventIds
def telemetry_Curr_byVINandEventIds(self, event_id, vin, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_Curr_byVINandEventIds")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{vin}', vin)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object['ids'][0] = event_id
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Telemetry_Curr_byVINandEventIds",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_Curr_byVINandEventIds', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_Curr_byVINandEventIds", response.text)

    # Validate response status code
    assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

    # Parse API response into JSON
    response_body = response.json()

    if response_body["responseCode"] == str(1200):
        assert True
    else:
        print("response Code is not 1200. Rather found : " + str(response_body["message"]))
        assert False

    assert (response_body["responseData"]["message"] == "Successfully fetched the current values")

    return response_body


# Telemetry - Telemetry_Curr_sensorValues
def telemetry_Curr_sensorValues(self, systemId, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_Curr_sensorValues")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    # systemId = get_SystemId(self, deviceType_IVI)
    complete_url = str(base_url + endpoint).replace('{systemId}', systemId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Telemetry_Curr_sensorValues",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_Curr_sensorValues', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_Curr_sensorValues", response.text)

    return response


# Telemetry - Telemetry_Curr_sensorValues
def telemetry_Curr_sensorElements(self, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_sensorElements")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    # systemId = get_SystemId(self, deviceType_IVI)
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Telemetry_sensorElements",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_sensorElements', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_sensorElements", response.text)

    return response


# Telemetry - Telemetry_Curr_sensorElements with eventType and attributeName
def telemetry_Curr_sensorElements_eventType_name(self, eventType, name, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_sensorElements_witheventType_attributeName")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    # systemId = get_SystemId(self, deviceType_IVI)
    complete_url = str(base_url + endpoint).replace('{eventType}', eventType).replace('{name}', name)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data",
                                                "Telemetry_sensorElements_witheventType_attributeName",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_sensorElements_witheventType_attributeName', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_sensorElements_witheventType_attributeName", response.text)

    return response


# Telemetry Metadata details
def telemetry_metadata_details(self, elementId, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_Metadata_Details")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for GET request

    # Url :
    # systemId = get_SystemId(self, deviceType_IVI)
    if tc == "no_elementId":
        print(endpoint)
        endpoint = endpoint.replace('?elementId={elementId}', '')
        complete_url = str(base_url + endpoint)
    elif tc == "empty_elementId":
        complete_url = str(base_url + endpoint).replace('{elementId}', '')
    else:
        complete_url = str(base_url + endpoint).replace('{elementId}', elementId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)

    # Payload :
    json_object = json.loads(payload)

    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send GET request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_Metadata_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Telemetry_Metadata_Details",
                                                "Telemetry_Metadata_AuthToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_Metadata_Details', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_Metadata_Details", response.text)

    return response


# Telemetry Publisher Config
def telemetry_publisher_config(self, eventType, isActive, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "TelemetryPublisher")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)

    # Payload :
    json_object = json.loads(payload)
    if tc == "no_eventType":
        del json_object['eventType']
    else:
        json_object['eventType'] = eventType
    if tc == "no_isActive":
        del json_object['isActive']
    else:
        json_object['isActive'] = isActive
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "TelemetryPublisher")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "TelemetryPublisher",
                                                "TelemetryPublisher_getToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('TelemetryPublisher', response.text)
    save_api_resp_in_excel(self, "API_Data", "TelemetryPublisher", response.text)

    return response


# SOS SERVICE
def Sos_Service(self, vin, system_id, device_id, sub_system_id, time, elementId, area, value, event_type, reason_code,
                tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Sos_Service")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)

    # Payload :
    json_object = json.loads(payload)
    if tc == "no_vin":
        del json_object["meta"]['vin']
    else:
        json_object["meta"]['vin'] = vin
    if tc == "no_deviceId":
        del json_object["meta"]['device_id']
    else:
        json_object["meta"]['device_id'] = device_id
    if tc == "no_systemId":
        del json_object["meta"]['system_id']
    else:
        json_object["meta"]['system_id'] = system_id
    if tc == "no_subsystemId":
        del json_object["meta"]['sub_system_id']
    else:
        json_object["meta"]['sub_system_id'] = sub_system_id
    if tc == "no_time":
        del json_object["telemetry"][0]['time']
    else:
        json_object["telemetry"][0]['time'] = time
    if tc == "no_id":
        del json_object["telemetry"][0]["data"][0]['id']
    else:
        json_object["telemetry"][0]["data"][0]['id'] = elementId
    if tc == "no_area":
        del json_object["telemetry"][0]["data"][0]['area']
    else:
        json_object["telemetry"][0]["data"][0]['area'] = area
    if tc == "no_value":
        del json_object["telemetry"][0]["data"][0]['value']
    else:
        json_object["telemetry"][0]["data"][0]['value'] = value
    if tc == "no_eventType":
        del json_object["telemetry"][0]['event_type']
    else:
        json_object["telemetry"][0]['event_type'] = event_type
    if tc == "no_reasoncode":
        del json_object["telemetry"][0]['reason_code']
    else:
        json_object["telemetry"][0]['reason_code'] = reason_code
    if tc == "no_data":
        del json_object["telemetry"][0]["data"]
    if tc == "no_telemetry":
        del json_object["telemetry"]
    if tc == "no_meta":
        del json_object["meta"]
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Sos_Service")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Sos_Service",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Sos_Service', response.text)
    save_api_resp_in_excel(self, "API_Data", "Sos_Service", response.text)

    return response


# Telemetry - Telemetry_Curr_sensorValues_withpayload
def telemetry_Curr_sensorValues(self, systemId, eventType, id, name,tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_Curr_sensorValues")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request
    if tc == "no_SystemId":
        complete_url = str(base_url + endpoint).replace('?systemId={systemId}', '')
    # elif tc == "VIN":
    # complete_url = str(base_url + endpoint)+'&vin={vin}'.replace('{vin}', vin)
    else:
        complete_url = str(base_url + endpoint).replace('{systemId}', systemId)
    # Url :
    # systemId = get_SystemId(self, deviceType_IVI)
    # complete_url = str(base_url + endpoint).replace('{systemId}', systemId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)
    
    # Payload :
    json_object = json.loads(payload)

    json_object["names"][0] = name

    json_object["eventTypes"][0] = eventType
    json_object["ids"][0] = id

    if tc == "EventType":

        del json_object["names"]
        del json_object["ids"]

    elif tc == "id15":
        del json_object["names"]
        json_object["ids"] = id

    elif tc == "name15":
        del json_object["ids"]
        json_object["names"] = name

    elif tc == "delid":
        del json_object["ids"]

    elif tc == "valid" or "no_SystemID":
        del json_object["names"]


    else:
        json_object["names"][0] = name

    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Telemetry_Curr_sensorValues",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_Curr_sensorValues', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_Curr_sensorValues", response.text)

    return response


# Telemetry - Telemetry_Curr_sensorValues_withVIN_In_payload
def telemetry_Curr_sensorValues_VIN(self, vin, eventType, id, name,tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_Curr_sensorValues_VIN")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request
    if tc == "no_SystemId":
        complete_url = str(base_url + endpoint).replace('?vin={vin}', '')
    else:
        complete_url = str(base_url + endpoint).replace('{vin}', vin)
    # Url :
    # systemId = get_SystemId(self, deviceType_IVI)
    # complete_url = str(base_url + endpoint).replace('{systemId}', systemId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)
    
    # Payload :
    json_object = json.loads(payload)
    json_object["names"][0] = name
    json_object["eventTypes"][0] = eventType
    json_object["ids"][0] = id
    if tc == "EventType":
        del json_object["names"]
        del json_object["ids"]
    elif tc == 'IDAndName':
        json_object["names"][0] = name
        json_object["ids"][0] = id
        json_object["eventTypes"][0] = eventType
    elif tc == "delid":
        del json_object["ids"]
    elif tc == "valid" or "no_SystemID":
        del json_object["names"]
    else:
        json_object["names"][0] = name

    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Telemetry_Curr_sensorValues_VIN",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_Curr_sensorValues', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_Curr_sensorValues_VIN", response.text)

    return response


# Telemetry - Telemetry_Curr_sensorValues_withVIN&systemID_In_payload
def telemetry_Curr_sensorValues_systemIDAndVIN(self, systemId, vin, eventType, id, name,tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Telemetry_Curr_sensorValues_SystemID&VIN")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request
    if tc == "no_SystemId":
        complete_url = str(base_url + endpoint).replace('{systemId}', systemId).replace('?vin={vin}', '')
    else:
        complete_url = str(base_url + endpoint).replace('{systemId}', systemId).replace('{vin}', vin)
    # Url :
    # systemId = get_SystemId(self, deviceType_IVI)
    # complete_url = str(base_url + endpoint).replace('{systemId}', systemId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header :", header_x)
    
    # Payload :
    json_object = json.loads(payload)

    json_object["names"][0] = name

    json_object["eventTypes"][0] = eventType
    json_object["ids"][0] = id

    if tc == "EventType":

        del json_object["names"]
        del json_object["ids"]

    elif tc == 'IDAndName':
        json_object["names"][0] = name
        json_object["ids"][0] = id
        json_object["eventTypes"][0] = eventType

    elif tc == "delid":
        del json_object["ids"]

    elif tc == "valid" or "no_SystemID":
        del json_object["names"]

    else:
        json_object["names"][0] = name

    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation :")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Telemetry_AuthToken")
            time.sleep(5)

            update_apiheader_with_token_inExcel(self, "API_Data", "Telemetry_Curr_sensorValues_SystemID&VIN",
                                                "Telemetry_AuthToken")
            time.sleep(60)
            response = requests.post(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Telemetry_Curr_sensorValues', response.text)
    save_api_resp_in_excel(self, "API_Data", "Telemetry_Curr_sensorValues_SystemID&VIN", response.text)

    return response
