import ast
import json
import time
import requests

from C2CModules.api_modules import header_update
from C2CModules.resuse_modules import save_api_resp_into_file
from C2CModules.token_generation import token_gen_reus_mod, update_apiheader_with_token_inExcel
from utils.XLUtils import read_api_data_from_excel, save_api_resp_in_excel


# ---------------------------------
# API Modules
# ---------------------------------

# Vehicle_update-vehicle-meta-data
def vehicle_update_vehicle_metadata(self, vin, model, year,make, engine_type,manufacturing_date,manufacturing_location,manufacturing_plant,manufacturing_country,vehicle_registration,vehicle_registration_date,fleet_id,driver_id, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Vehicle_update-vehicle-meta-data")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{vin}', vin)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    json_object["model"] = model
    json_object["year"] = year
    json_object["make"] = make
    json_object["engine_type"] = engine_type
    json_object["manufacturing_date"] = manufacturing_date
    json_object["manufacturing_location"] = manufacturing_location
    json_object["manufacturing_plant"] = manufacturing_plant
    json_object["manufacturing_country"] = manufacturing_country
    json_object["vehicle_registration"] = vehicle_registration
    json_object["vehicle_registration_date"] = vehicle_registration_date
    json_object["fleet_id"] = fleet_id
    json_object["driver_id"] = driver_id
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.put(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Vehicle-AuthToken")
            time.sleep(60)
            update_apiheader_with_token_inExcel(self, "API_Data", "Vehicle_update-vehicle-meta-data",
                                                "Vehicle-AuthToken")
            time.sleep(120)
            response = requests.put(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Vehicle_update-vehicle-meta-data', response.text)
    save_api_resp_in_excel(self, "API_Data", "Vehicle_update-vehicle-meta-data", response.text)

    return response


# Vehicle_get-vehicle-meta-data
def vehicle_get_vehicle_metadata(self, vin, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Vehicle_get-vehicle-meta-data")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request
    # vin = getVIN(self, "tel", deviceType_IVI)

    # Url :
    complete_url = str(base_url + endpoint).replace('{vin}', vin)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    # print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Vehicle-AuthToken")
            time.sleep(60)
            update_apiheader_with_token_inExcel(self, "API_Data", "Vehicle_get-vehicle-meta-data",
                                                "Vehicle-AuthToken")
            time.sleep(120)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Vehicle_get-vehicle-meta-data', response.text)
    save_api_resp_in_excel(self, "API_Data", "Vehicle_get-device-meta-data", response.text)

    return response


# Vehicle_get-device-meta-data
def vehicle_get_device_metadata(self, deviceId, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Vehicle_get-device-meta-data")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{deviceId}', deviceId)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Vehicle-AuthToken")
            time.sleep(5)
            update_apiheader_with_token_inExcel(self, "API_Data", "Vehicle_get-device-meta-data",
                                                "Vehicle-AuthToken")
            time.sleep(60)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Vehicle_get-device-meta-data', response.text)
    save_api_resp_in_excel(self, "API_Data", "Vehicle_get-device-meta-data", response.text)

    return response


# Vehicle_GetVinsbyModelNew
def vehicle_get_vinsbyModelNew(self, model, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Vehicle-GetVinsbyModelNew")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request

    # Url :
    complete_url = str(base_url + endpoint).replace('{modelName}', model)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Vehicle-AuthToken")
            time.sleep(5)
            update_apiheader_with_token_inExcel(self, "API_Data", "Vehicle-GetVinsbyModelNew",
                                                "Vehicle-AuthToken")
            time.sleep(120)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Vehicle-GetVinsbyModelNew', response.text)
    save_api_resp_in_excel(self, "API_Data", "Vehicle-GetVinsbyModelNew", response.text)

    return response


# Vehicle-GetVinCountByAllModels
def vehicle_get_vinCount_byAllModels(self, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Vehicle-GetVinCountByAllModels")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request
    # vin = getVIN(self, "tel", deviceType_IVI)

    # Url :
    complete_url = str(base_url + endpoint)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Vehicle-AuthToken")
            time.sleep(5)
            update_apiheader_with_token_inExcel(self, "API_Data", "Vehicle-GetVinCountByAllModels",
                                                "Vehicle-AuthToken")
            time.sleep(120)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Vehicle-GetVinCountByAllModels', response.text)
    save_api_resp_in_excel(self, "API_Data", "Vehicle-GetVinCountByAllModels", response.text)

    return response


# Vehicle-GetVinsByModel
def vehicle_get_vins_byModel(self, model, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Vehicle-GetVinsByModel")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request
    # vin = getVIN(self, "tel", deviceType_IVI)

    # Url :
    complete_url = str(base_url + endpoint).replace('{modelName}', model)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)
    print("Header : ", header_x)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Vehicle-AuthToken")
            time.sleep(5)
            update_apiheader_with_token_inExcel(self, "API_Data", "Vehicle-GetVinsByModel",
                                                "Vehicle-AuthToken")
            time.sleep(120)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Vehicle-GetVinsByModel', response.text)
    save_api_resp_in_excel(self, "API_Data", "Vehicle-GetVinsByModel", response.text)

    return response


# Vehicle-GetVinsByModel
def vehicle_get_vins_byModel_v3(self, vin, tc):
    # Read api test data from excel sheet
    dict = read_api_data_from_excel(self, "API_Data", "Vehicle-GetVinsByModel_v3")
    base_url = str(dict["Base Url"])
    endpoint = str(dict["Endpoint"])
    headers = str(dict["Headers"]).replace('\n', '')
    payload = str(dict["Payload"]).replace('\n', '')

    # Arrange: Test data (url,header and payload) for POST request
    # vin = getVIN(self, "tel", deviceType_IVI)

    # Url :
    complete_url = str(base_url + endpoint).replace('{vin}', vin)
    print("Complete URL : ", complete_url)

    # Header :
    header_x = ast.literal_eval(headers)
    header_x = header_update(header_x, tc)

    # Payload :
    json_object = json.loads(payload)
    payload = json_object
    # print("Payload : ", payload)

    # Act: convert dict to json by json.dumps() for body data and send POST request.
    response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
    print("API response : ", response.text)

    try:
        # Parse API response into JSON
        response_body = response.json()

        if response_body["Message"] == "User is not authorized to access this resource":
            print("Token generation : ")
            # Generate token
            token_gen_reus_mod(self, "API_Data", "Vehicle-AuthToken")
            time.sleep(5)
            update_apiheader_with_token_inExcel(self, "API_Data", "Vehicle-GetVinsByModel_v3",
                                                "Vehicle-AuthToken")
            time.sleep(120)
            response = requests.get(complete_url, headers=header_x, data=json.dumps(payload))
            print("API response : ", response.text)
    except:
        print("\n")

    # Save test result in Excel sheet @ desired cell for get count or device details api's
    save_api_resp_into_file('Vehicle-GetVinsByModel_v3', response.text)
    save_api_resp_in_excel(self, "API_Data", "Vehicle-GetVinsByModel_v3", response.text)

    return response
