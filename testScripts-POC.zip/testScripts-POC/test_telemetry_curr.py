import os

import pytest

from C2CModules.e2e_testData import deviceType_IVI, b2c_ivi_chipset
from C2CModules.primary_IVI_device_modules import get_SystemId, getVIN
from C2CModules.telemetry_modules import telemetry_Curr_sensorValues, telemetry_Curr_sensorElements, \
    telemetry_Curr_eventType, telemetry_Curr_byVIN, telemetry_Curr_byVIN_eventType
from C2CModules.testResults import testResult
from utils.XLUtils import read_api_data_from_excel

CurrentPath = os.path.realpath(__file__)
BaseName = os.path.basename(__file__)
Test_Case_No = BaseName.replace('.py', '')
print(Test_Case_No)

OnboardingType = deviceType = deviceType_IVI
chipsetType = b2c_ivi_chipset


class Test_Smoke:

    # telemetry_curr
    @pytest.mark.Smoke
    def test1_positive_telmetry_curr_sensor_values(self):
        print("----------------------------------------------------------")
        testCaseName = "valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Telemetry", "Telemetry_Curr_sensorValues")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")

            SystemId = str(dict1["SystemId"])

        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            SystemId = get_SystemId(self, OnboardingType, chipsetType)

        # Call api reusable module
        response_body = telemetry_Curr_sensorValues(self, SystemId, testCaseName)

        # Validate response status code
        assert (response_body.status_code == 200), "Status code is not 200. Rather found : " + str(response_body.status_code)

        # Parse API response into JSON
        response_body = response_body.json()

        if response_body["responseCode"] == str(1200):
            message = response_body["responseData"]["message"]
            print('Message : ', message)
            if len(response_body["responseData"]["dataList"]) >=1:
                print("ID : ", response_body["responseData"]["dataList"][0]["id"])
                print("Name : ", response_body["responseData"]["dataList"][0]["name"])
                print("Unit : ", response_body["responseData"]["dataList"][0]["unit"])
                print("Value : ", response_body["responseData"]["dataList"][0]["value"])
            testResult(self, "passed", "Should fetch the current values successfully",
                       "Successfully fetched the current values ")
        elif response_body["responseCode"] != str(1200):
            # print(response_body["responseData"]["message"])
            testResult(self, "failed", "Should fetch the current values successfully ",
                       "Failed to fetch the current values " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            print("Something went wrong")
        print("----------------------------------------------------------")

# telemetry_curr
    @pytest.mark.Smoke
    def test1_positive_telmetry_curr_sensor_elements(self):
        print("----------------------------------------------------------")
        testCaseName = "valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Telemetry", "Telemetry_sensorElements")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            print("No data is required")
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            print("No data is required")

        # Call api reusable module
        response_body = telemetry_Curr_sensorElements(self, testCaseName)

        # Validate response status code
        assert (response_body.status_code == 200), "Status code is not 200. Rather found : " + str(response_body.status_code)

        # Parse API response into JSON
        response_body = response_body.json()

        if response_body["responseCode"] == str(1200):
            message = response_body["responseData"]["message"]
            print('Message : ', message)
            if len(response_body["responseData"]["dataList"]) >=1:
                print("ID : ", response_body["responseData"]["dataList"][0]["id"])
                print("Event Type : ", response_body["responseData"]["dataList"][0]["eventType"])
                print("Name : ", response_body["responseData"]["dataList"][0]["name"])
                print("Unit : ", response_body["responseData"]["dataList"][0]["unit"])
            testResult(self, "passed", "Should fetch the sensor elements data successfully",
                       "Successfully fetched the sensor elements data ")
        elif response_body["responseCode"] != str(1200):
            # print(response_body["responseData"]["message"])
            testResult(self, "failed", "Should fetch the sensor elements data successfully ",
                       "Failed to fetch the current values " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            print("Something went wrong")
        print("----------------------------------------------------------")

    # telemetry_curr
    @pytest.mark.Smoke
    def test1_positive_telmetry_curr_eventType(self):
        print("----------------------------------------------------------")
        testCaseName = "valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Telemetry", "Telemetry_CurrForEventType")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            systemId = str(dict1["SystemId"])
            event_type = str(dict1["eventType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            systemId = get_SystemId(self, OnboardingType, chipsetType)
            event_type = 3106

        # Call api reusable module
        response_body = telemetry_Curr_eventType(self, event_type, systemId, testCaseName)

        # Validate response status code
        assert (response_body.status_code == 200), "Status code is not 200. Rather found : " + str(
            response_body.status_code)

        # Parse API response into JSON
        response_body = response_body.json()

        if response_body["responseCode"] == str(1200):
            message = response_body["responseData"]["message"]
            print('Message : ', message)
            if len(response_body["responseData"]["dataList"]) >= 1:
                print("ID : ", response_body["responseData"]["dataList"][0]["id"])
                print("Name : ", response_body["responseData"]["dataList"][0]["name"])
                print("Unit : ", response_body["responseData"]["dataList"][0]["unit"])
                print("Value : ", response_body["responseData"]["dataList"][0]["value"])
                testResult(self, "passed", "Should fetch the data/values for event type successfully",
                           "Successfully fetched the values/data for desired event type ")
            else:
                print(" => datalist is empty")
                testResult(self, "passed", "Should fetch the data/values for event type successfully",
                       "End point is working fine, but there is no data in DB for this event type, thus marking test case as pass")

        elif response_body["responseCode"] != str(1200):
            # print(response_body["responseData"]["message"])
            testResult(self, "failed", "Should fetch the data/values for event type successfully ",
                       "Failed to fetch the data/values " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            print("Something went wrong")

        print("----------------------------------------------------------")

    # telemetry_curr
    @ pytest.mark.Smoke
    def test1_positive_telmetry_curr_byVIN(self):
        print("----------------------------------------------------------")
        testCaseName = "valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Telemetry", "Telemetry_Curr_byVIN")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            vin = str(dict1["vin"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            vin = getVIN(self, OnboardingType, chipsetType)

        # Call api reusable module
        response_body = telemetry_Curr_byVIN(self, vin, testCaseName)

        # Validate response status code
        assert (response_body.status_code == 200), "Status code is not 200. Rather found : " + str(
            response_body.status_code)

        # Parse API response into JSON
        response_body = response_body.json()

        if response_body["responseCode"] == str(1200):
            message = response_body["responseData"]["message"]
            print('Message : ', message)
            if len(response_body["responseData"]["dataList"]) >= 1:
                print("ID : ", response_body["responseData"]["dataList"][0]["id"])
                print("Name : ", response_body["responseData"]["dataList"][0]["name"])
                print("Unit : ", response_body["responseData"]["dataList"][0]["unit"])
                print("Value : ", response_body["responseData"]["dataList"][0]["value"])
                testResult(self, "passed", "Should fetch the data/values for vin successfully",
                           "Successfully fetched the values/data for desired vin ")
            else:
                print(" => datalist is empty")
                testResult(self, "passed", "Should fetch the data/values for vin successfully",
                           "End point is working fine, but there is no data in DB for this vin, thus marking test case as pass")

        elif response_body["responseCode"] != str(1200):
            # print(response_body["responseData"]["message"])
            testResult(self, "failed", "Should fetch the data/values for vin successfully ",
                       "Failed to fetch the data/values " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            print("Something went wrong")

        print("----------------------------------------------------------")

    # telemetry_curr
    @pytest.mark.Smoke
    def test1_positive_telmetry_curr_vinANDeventType(self):
        print("----------------------------------------------------------")
        testCaseName = "valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "Telemetry", "Telemetry_Curr_byVINandEventType")
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            vin = str(dict1["vin"])
            event_type = str(dict1["eventType"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            vin = getVIN(self, OnboardingType, chipsetType)
            event_type = 3106

        # Call api reusable module
        response_body = telemetry_Curr_byVIN_eventType(self, event_type, vin, testCaseName)

        # Validate response status code

        assert (response_body.status_code == 200), "Status code is not 200. Rather found : " + str(
            response_body.status_code)

        # Parse API response into JSON
        response_body = response_body.json()

        if response_body["responseCode"] == str(1200):
            message = response_body["responseData"]["message"]
            print('Message : ', message)
            if len(response_body["responseData"]["dataList"]) >= 1:
                print("ID : ", response_body["responseData"]["dataList"][0]["id"])
                print("Name : ", response_body["responseData"]["dataList"][0]["name"])
                print("Unit : ", response_body["responseData"]["dataList"][0]["unit"])
                print("Value : ", response_body["responseData"]["dataList"][0]["value"])
                testResult(self, "passed", "Should fetch the data/values for vin & event type successfully",
                           "Successfully fetched the values/data for desired vin & event type ")
            else:
                print(" => datalist is empty")
                testResult(self, "passed", "Should fetch the data/values for vin & event type successfully",
                           "End point is working fine, but there is no data in DB for this vin & event type, thus marking test case as pass")

        elif response_body["responseCode"] != str(1200):
            # print(response_body["responseData"]["message"])
            testResult(self, "failed", "Should fetch the data/values for vin & event type successfully ",
                       "Failed to fetch the data/values " + " Reason for failure is : " +
                       response_body["responseData"]["message"])
        else:
            print("Something went wrong")

        print("----------------------------------------------------------")