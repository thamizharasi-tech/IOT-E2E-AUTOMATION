import random
import time

import pytest

from C2CModules.commandControl_modules import commandControl_Request, commandControl_Tracking, \
    get_commandCtrl_trackingId, CommandControl_Request_addTemplate, CommandControl_Request_getTemplateInfo, \
    CommandControl_Request_updateTemplate, CommandControl_Request_getTemplateInfo_baseTemplateId, \
    CommandControl_Request_addModelTemplate, CommandControl_Request_getModelTemplate, \
    CommandControl_Request_updateModelTemplate, CommandControl_Request_addOEM, CommandControl_Request_getOEM, \
    CommandControl_Request_updateOEM
from C2CModules.e2e_testData import deviceType_IVI, drimaes_ivi_chipset
from C2CModules.primary_IVI_device_modules import getVIN
from C2CModules.testResults import testResult
from utils.XLUtils import read_api_data_from_excel

OnboardingType = deviceType = deviceType_IVI
chipsetType = drimaes_ivi_chipset


class Test_CommandControl:

    # CommandControl Request & Tracking
    @pytest.mark.Smoke
    def test1_positive_CommandControl_Request_Tracking(self):
        print("----------------------------------------------------------")
        # Read api test data resp from excel sheet
        testCaseName = "valid"
        dict1 = read_api_data_from_excel(self, "CommandControl", "CommandControl_Request")
        appid = str(dict1["appid"])
        name = str(dict1["name"])
        area = int(dict1["area"])
        value = int(dict1["value"])
        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            vin = str(dict1["vin"])

            print("App Id :", appid)
            print("Name :", name)
            print("Area :", area)
            print("Value :", value)
            print("VIN :", vin)

            # Call command & control reusable module
            response = commandControl_Request(self, appid, name, area, value, vin)
            time.sleep(180)

            # read tracking id
            trackingId = get_commandCtrl_trackingId(self, response)

            # Verify command & control resp
            response = commandControl_Tracking(self, trackingId)

        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            vin = getVIN(self, OnboardingType, chipsetType)

            print("App Id :", appid)
            print("Name :", name)
            print("Area :", area)
            print("Value :", value)
            print("VIN :", vin)

            response = commandControl_Request(self, appid, name, area, value, vin)
            time.sleep(180)

            # read tracking id
            trackingId = get_commandCtrl_trackingId(self, response)

            # Verify command & control resp
            response = commandControl_Tracking(self, trackingId)

        print("----------------------------------------------------------")

    # CommandControl_Request_addTemplate
    @pytest.mark.Smoke
    def test1_positive_CommandControl_Request_addTemplate(self):
        print("----------------------------------------------------------")
        testCaseName = "valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "CommandControl", "CommandControl_Request_addTemplate")

        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            baseTemplateId = str(dict1["baseTemplateId"])
            name = str(dict1["name"])
            description = str(dict1["description"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            baseTemplateId = 13
            name = 'bmw'
            description = "testingAPI"

        response = CommandControl_Request_addTemplate(self, baseTemplateId, name, description,testCaseName)

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        print("Validations : ")
        if response_body["responseCode"] == str(1200) or response_body["responseCode"] == 1200:
            print("Response message : ", response_body['responseData']['message'])

            response = CommandControl_Request_getTemplateInfo_baseTemplateId(self, baseTemplateId, testCaseName)
            # Validate response status code
            assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

            # Parse API response into JSON
            response_body = response.json()
            data_len = len(response_body["responseData"]["data"])
            if data_len >= 1:
                i = 0
                for i in range(data_len):
                    if response_body["responseData"]["data"][i]["description"] == description:
                        print("Template details : ")
                        print("Base Template Id :", response_body["responseData"]["data"][i]["baseTemplateId"])
                        print("Name :", response_body["responseData"]["data"][i]["name"])
                        print("Description :", response_body["responseData"]["data"][i]["description"])
                        print("Template Id :", response_body["responseData"]["data"][i]["templateId"])
                        print("Version :", response_body["responseData"]["data"][i]["version"])
                        testResult(self, "passed",
                                   "Should add template successfully",
                                   "Successfully added template")
            else:
                print("datalist is empty")
                testResult(self, "verificationFailed",
                           "Should fetch template details successfully",
                           "Data List is empty")
        elif response_body["responseCode"] != str(1200):
            print("response Code is not 1200. Rather found : " + str(response_body["message"]))
            testResult(self, "failed",
                       "Should add template successfully",
                       "Failed to add template")
        else:
            print("Something went wrong")
            assert False

        print("----------------------------------------------------------")

    # CommandControl_Request_getTemplateInfo
    @pytest.mark.Smoke
    def test1_positive_CommandControl_Request_getTemplateInfo(self):
        print("----------------------------------------------------------")
        testCaseName = "valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "CommandControl", "CommandControl_Request_getTemplateInfo")

        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            baseTemplateId = str(dict1["baseTemplateId"])
            name = str(dict1["name"])
            templateId = str(dict1["templateId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            baseTemplateId = 13
            name = 'bmw'
            templateId = 17

        response = CommandControl_Request_getTemplateInfo(self, baseTemplateId, templateId, name,testCaseName)

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        if response_body["responseCode"] == str(1200) or response_body["responseCode"] == 1200:
            print("Response message : ", response_body['responseData']['message'])
            data_len = len(response_body["responseData"]["data"])
            if data_len >= 1:
                assert (response_body["responseData"]["data"][0]["baseTemplateId"] == baseTemplateId)
                assert (response_body["responseData"]["data"][0]["name"] == name)
                assert (response_body["responseData"]["data"][0]["templateId"] == templateId)
                testResult(self, "passed",
                           "Should fetch template details successfully",
                           "Successfully fetched template details")
            else:
                print("datalist is empty")
                testResult(self, "verificationFailed",
                           "Should fetch template details successfully",
                           "Data List is empty")
        elif response_body["responseCode"] != str(1200):
            print("response Code is not 1200. Rather found : " + str(response_body["message"]))
            testResult(self, "failed",
                       "Should fetch template details successfully",
                       "Failed to fetch template details")
        else:
            print("Something went wrong")
            assert False

        print("----------------------------------------------------------")

    # CommandControl_Request_updateTemplate
    @pytest.mark.Smoke
    def test1_positive_CommandControl_Request_updateTemplate(self):
        print("----------------------------------------------------------")
        testCaseName = "valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "CommandControl", "CommandControl_Request_updateTemplate")

        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            baseTemplateId = str(dict1["baseTemplateId"])
            name = str(dict1["name"])
            description = str(dict1["description"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            baseTemplateId = 13
            name = 'bmw_update'
            description = "testing_update"

        response = CommandControl_Request_updateTemplate(self, baseTemplateId, name, description,testCaseName)

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        print("Validations : ")
        if response_body["responseCode"] == str(1200) or response_body["responseCode"] == 1200:
            print("Response message : ", response_body['responseData']['message'])

            response = CommandControl_Request_getTemplateInfo_baseTemplateId(self, baseTemplateId,testCaseName)
            # Validate response status code
            assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

            # Parse API response into JSON
            response_body = response.json()
            data_len = len(response_body["responseData"]["data"])
            if data_len >= 1:
                i = 0
                for i in range(data_len):
                    if response_body["responseData"]["data"][i]["description"] == description:
                        print("Below is the updated template details : ")
                        print("Base Template Id :", response_body["responseData"]["data"][i]["baseTemplateId"])
                        print("Name :", response_body["responseData"]["data"][i]["name"])
                        print("Description :", response_body["responseData"]["data"][i]["description"])
                        print("Template Id :", response_body["responseData"]["data"][i]["templateId"])
                        print("Version :", response_body["responseData"]["data"][i]["version"])
                        testResult(self, "passed",
                                   "Should update template details successfully",
                                   "Successfully updated template details")
            else:
                print("datalist is empty")
                testResult(self, "verificationFailed",
                           "Should fetch template details successfully",
                           "Data List is empty")
        elif response_body["responseCode"] != str(1200):
            print("response Code is not 1200. Rather found : " + str(response_body["message"]))
            testResult(self, "failed",
                       "Should update template details successfully",
                       "Failed to update template details")
        else:
            print("Something went wrong")
            assert False
        print("----------------------------------------------------------")

    # CommandControl_Request_addModelTemplate
    @pytest.mark.Smoke
    def test1_positive_CommandControl_Request_addModelTemplate(self):
        print("----------------------------------------------------------")
        testCaseName = "valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "CommandControl", "CommandControl_Request_addModelTemplate")

        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            appId = str(dict1["appid"])
            model = str(dict1["model"])
            modelYear = str(dict1["modelYear"])
            class1 = str(dict1["class"])
            style = str(dict1["style"])
            templateId = str(dict1["templateId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            appId = 'c6078'
            msg_id = ' '.join([str(random.randint(10, 9999)).zfill(2) for _ in range(1)])
            print("Initiated message Id : ", msg_id)
            model = 'BMW_' + str(msg_id)
            modelYear = '2021'
            class1 = 'F'
            style = 'Sedan'
            templateId = '1'

        response = CommandControl_Request_addModelTemplate(self, appId, model, modelYear, class1, style, templateId,testCaseName)

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        print("Validations : ")
        if response_body["responseCode"] == str(1200) or response_body["responseCode"] == 1200:
            print("Response message : ", response_body['responseData']['message'])

            response = CommandControl_Request_getModelTemplate(self,testCaseName)
            # Validate response status code
            assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

            # Parse API response into JSON
            response_body = response.json()
            data_len = len(response_body["responseData"]["data"])
            if data_len >= 1:
                i = 0
                for i in range(data_len):
                    if response_body["responseData"]["data"][i]["model"] == model:
                        print("Model Template details : ")
                        print("Id :", response_body["responseData"]["data"][i]["id"])
                        print("Oem Id :", response_body["responseData"]["data"][i]["oemId"])
                        print("Model :", response_body["responseData"]["data"][i]["model"])
                        print("Model Year :", response_body["responseData"]["data"][i]["modelYear"])
                        print("Class :", response_body["responseData"]["data"][i]["class"])
                        print("Style :", response_body["responseData"]["data"][i]["style"])
                        print("Template Id :", response_body["responseData"]["data"][i]["templateId"])
                        testResult(self, "passed",
                                   "Should add to Model Template successfully",
                                   "Successfully added to Model Template")
            else:
                print("datalist is empty")
                testResult(self, "verificationFailed",
                           "Should fetch model template details successfully",
                           "Data List is empty")
        elif response_body["responseCode"] != str(1200):
            print("response Code is not 1200. Rather found : " + str(response_body["message"]))
            testResult(self, "failed",
                       "Should add to Model Template successfully",
                       "Failed to add to Model Template")
        else:
            print("Something went wrong")
            assert False

        print("----------------------------------------------------------")

    # CommandControl_Request_updateModelTemplate
    @pytest.mark.Smoke
    def test1_positive_CommandControl_Request_updateModelTemplate(self):
        print("----------------------------------------------------------")
        testCaseName ="valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "CommandControl", "CommandControl_Request_updateModelTemplate")

        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            appId = str(dict1["appid"])
            model = str(dict1["model"])
            modelYear = str(dict1["modelYear"])
            class1 = str(dict1["class"])
            style = str(dict1["style"])
            templateId = str(dict1["templateId"])
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            appId = 'c6078'
            model = 'BMW9'
            modelYear = '2021'
            class1 = 'F'
            style = 'Sedan'
            templateId = '1'

        response = CommandControl_Request_updateModelTemplate(self, appId, model, modelYear, class1, style, templateId,testCaseName)

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        print("Validations : ")
        if response_body["responseCode"] == str(1200) or response_body["responseCode"] == 1200:
            print("Response message : ", response_body['responseData']['message'])

            response = CommandControl_Request_getModelTemplate(self, testCaseName)
            # Validate response status code
            assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

            # Parse API response into JSON
            response_body = response.json()
            data_len = len(response_body["responseData"]["data"])
            if data_len >= 1:
                i = 0
                for i in range(data_len):
                    if response_body["responseData"]["data"][i]["model"] == model:
                        print("Model Template details : ")
                        print("Id :", response_body["responseData"]["data"][i]["id"])
                        print("Oem Id :", response_body["responseData"]["data"][i]["oemId"])
                        print("Model :", response_body["responseData"]["data"][i]["model"])
                        print("Model Year :", response_body["responseData"]["data"][i]["modelYear"])
                        print("Class :", response_body["responseData"]["data"][i]["class"])
                        print("Style :", response_body["responseData"]["data"][i]["style"])
                        print("Template Id :", response_body["responseData"]["data"][i]["templateId"])
                        testResult(self, "passed",
                                   "Should update to Model Template successfully",
                                   "Successfully updated to Model Template")
            else:
                print("datalist is empty")
                testResult(self, "verificationFailed",
                           "Should fetch model template details successfully",
                           "Data List is empty")
        elif response_body["responseCode"] != str(1200):
            print("response Code is not 1200. Rather found : " + str(response_body["message"]))
            testResult(self, "failed",
                       "Should update to Model Template successfully",
                       "Failed to update to Model Template")
        else:
            print("Something went wrong")
            assert False

        print("----------------------------------------------------------")

    # CommandControl_Request_getModelTemplate
    @pytest.mark.Smoke
    def test1_positive_CommandControl_Request_getModelTemplate(self):
        print("----------------------------------------------------------")
        testCaseName = "valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "CommandControl", "CommandControl_Request_getModelTemplate")

        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            print("No input required")
        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            print("No input required")

        response = CommandControl_Request_getModelTemplate(self,testCaseName)

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        print("Validations :")
        if response_body["responseCode"] == str(1200) or response_body["responseCode"] == 1200:
            print("Response message : ", response_body['responseData']['message'])
            data_len = len(response_body["responseData"]["data"])
            if data_len >= 1:
                print("Model Template details : ")
                print("Id :", response_body["responseData"]["data"][0]["id"])
                print("Oem Id :", response_body["responseData"]["data"][0]["oemId"])
                print("Model :", response_body["responseData"]["data"][0]["model"])
                print("Model Year :", response_body["responseData"]["data"][0]["modelYear"])
                print("Class :", response_body["responseData"]["data"][0]["class"])
                print("Style :", response_body["responseData"]["data"][0]["style"])
                print("Template Id :", response_body["responseData"]["data"][0]["templateId"])

                testResult(self, "passed",
                           "Should fetch model template list successfully",
                           "Successfully fetched model template list")
            else:
                print("datalist is empty")
                testResult(self, "verificationFailed",
                           "Should fetch model template list successfully",
                           "Data List is empty")
        elif response_body["responseCode"] != str(1200):
            print("response Code is not 1200. Rather found : " + str(response_body["message"]))
            testResult(self, "failed",
                       "Should fetch model template list successfully",
                       "Failed to fetch model template list")
        else:
            print("Something went wrong")
            assert False

        print("----------------------------------------------------------")

    # CommandControl_Request_addOEM
    @pytest.mark.Smoke
    def test1_positive_CommandControl_Request_addOEM(self):
        print("----------------------------------------------------------")
        testCaseName ="valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "CommandControl", "CommandControl_Request_addOEM")

        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            appId = str(dict1["appid"])
            name = str(dict1["name"])
            description = str(dict1["description"])
            defaultTemplateId = str(dict1["templateId"])

        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")

            msg_id = ' '.join([str(random.randint(10, 9999)).zfill(2) for _ in range(1)])
            print("Initiated message Id : ", msg_id)
            appId = "appId_" + str(msg_id)
            name = 'Maruti'
            description = "New OEM"
            defaultTemplateId = '1'

        response = CommandControl_Request_addOEM(self, appId, name, description, defaultTemplateId,testCaseName)

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        print("Validations : ")
        if response_body["responseCode"] == str(1200) or response_body["responseCode"] == 1200:
            print("Response message : ", response_body['responseData']['message'])

            testResult(self, "passed",
                       "Should add to OEM successfully",
                       "Successfully added to OEM")
        elif response_body["responseCode"] != str(1200):
            print("response Code is not 1200. Rather found : " + str(response_body["message"]))
            testResult(self, "failed",
                       "Should add to OEM successfully",
                       "Failed to add to OEM")
        else:
            print("Something went wrong")
            assert False

        print("----------------------------------------------------------")

    # CommandControl_Request_updateOEM
    @pytest.mark.Smoke
    def test1_positive_CommandControl_Request_updateOEM(self):
        print("----------------------------------------------------------")
        testCaseName ="valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "CommandControl", "CommandControl_Request_addOEM")

        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            oemId = str(dict1["oemId"])
            appId = str(dict1["appid"])
            name = str(dict1["name"])
            description = str(dict1["description"])
            defaultTemplateId = str(dict1["templateId"])

        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")

            msg_id = ' '.join([str(random.randint(10, 9999)).zfill(2) for _ in range(1)])
            print("Initiated message Id : ", msg_id)
            appId = "appId_" + str(msg_id)
            oemId = "32"
            name = "Tesla"
            description = "update_OEM"
            defaultTemplateId = "6"

        response = CommandControl_Request_updateOEM(self, oemId,appId, name, description,defaultTemplateId,testCaseName)

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        print("Validations : ")
        if response_body["responseCode"] == str(1200) or response_body["responseCode"] == 1200:
            print("Response message : ", response_body['responseData']['message'])

            testResult(self, "passed",
                       "Should update to OEM successfully",
                       "Successfully updated to OEM")
        elif response_body["responseCode"] != str(1200):
            print("response Code is not 1200. Rather found : " + str(response_body["message"]))
            testResult(self, "failed",
                       "Should update to OEM successfully",
                       "Failed to update to OEM")
        else:
            print("Something went wrong")
            assert False

        print("----------------------------------------------------------")

    # CommandControl_Request_getOEM
    @pytest.mark.Smoke
    def test1_positive_CommandControl_Request_getOEM(self):
        print("----------------------------------------------------------")
        testCaseName = "valid"
        # Read api test data resp from excel sheet
        dict1 = read_api_data_from_excel(self, "CommandControl", "CommandControl_Request_getOEM")

        if dict1['Flag'] == "Yes":
            print("Flag is set to Yes, hence running with excel data :")
            oemId = str(dict1["oemId"])

        else:
            print("Flag is not set to Yes, hence running with generic/actual device data")
            oemId = '3'

        response = CommandControl_Request_getOEM(self, oemId,testCaseName)

        # Validate response status code
        assert (response.status_code == 200), "Status code is not 200. Rather found : " + str(response.status_code)

        # Parse API response into JSON
        response_body = response.json()

        print("Validations : ")
        if response_body["responseCode"] == str(1200) or response_body["responseCode"] == 1200:
            print("Response message : ", response_body['responseData']['message'])
            if response_body['responseData']['dataList'][0]['oemId'] == int(oemId):
                print("OEM Id : ", response_body['responseData']['dataList'][0]['oemId'])
                print("Name : ", response_body['responseData']['dataList'][0]['name'])
                print("Default Template Id : ", response_body['responseData']['dataList'][0]['defaultTemplateId'])
                print("description : ", response_body['responseData']['dataList'][0]['description'])

                testResult(self, "passed",
                           "Should fetch OEM details successfully",
                           "Successfully fetched OEM details")
            else:
                print("oemId mismatch or data list is empty")
                testResult(self, "failed",
                           "Should fetch OEM details successfully",
                           "oemId mismatch or data list is empty")
        elif response_body["responseCode"] != str(1200):
            print("response Code is not 1200. Rather found : " + str(response_body["message"]))
            testResult(self, "failed",
                       "Should fetch OEM details successfully",
                       "Failed to fetch OEM details")
        else:
            print("Something went wrong")
            assert False

        print("----------------------------------------------------------")
