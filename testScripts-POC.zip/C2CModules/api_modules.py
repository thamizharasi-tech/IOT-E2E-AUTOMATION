

# --------------------------
# API reusable Modules
# --------------------------

def pageNo_pageSize_update(complete_url, tc):
    if "page" in tc:
        if "pageNo" in complete_url and "pageSize" in complete_url:
            print("page No and PageSize parameters are present in the endpoint")
        else:
            print("Adding page no & page size parameters in the endpoint")
            complete_url = complete_url + "?pageNo=1&pageSize=10"

        if tc == "pageSize_0":
            complete_url = complete_url.replace("?pageNo=1&pageSize=10", "?pageNo=1&pageSize=0")
        elif tc == "pageSize_1001":
            complete_url = complete_url.replace("?pageNo=1&pageSize=10", "?pageNo=1&pageSize=1001")
        elif tc == "pageNo_0":
            complete_url = complete_url.replace("?pageNo=1&pageSize=10", "?pageNo=0&pageSize=10")
        elif tc == "pageNo_1001":
            complete_url = complete_url.replace("?pageNo=1&pageSize=10", "?pageNo=1001&pageSize=10")

    print(complete_url)
    return complete_url


def header_update(header_x, tc):
    if "invalid_apiKey" == tc:
        header_x["api-key"] = 'xyz'
    elif "null_apiKey" == tc:
        header_x["api-key"] = 'NULL'
    elif "empty_apiKey" in tc:
        header_x["api-key"] = ''
    elif "no_apiKey" in tc:
        del header_x["api-key"]
    elif "invalid_x-requestor" in tc:
        header_x["x-requestor"] = '@#$'
    elif "empty_x-requestor" in tc:
        header_x["x-requestor"] = ''
    elif "no_x-requestor" in tc:
        del header_x["x-requestor"]
    return header_x
